﻿using BVG.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Exceptions
{
    public class OtpException : Exception
    {
        public BVGStatusCode StatusCode { get; }
        public BVGErrorCode ErrorCode { get; }

        public OtpException(BVGStatusCode statusCode, BVGErrorCode errorCode) : base(errorCode.ToString())
        {
            StatusCode = statusCode;
            ErrorCode = errorCode;
        }
    }
}
