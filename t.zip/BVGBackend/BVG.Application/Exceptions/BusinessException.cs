﻿using BVG.Domain.Enums;

namespace BVG.Application.Exceptions
{
    public class BusinessException : Exception
    {
        public string ErrorCode { get; set; } 

        public int StatusCode { get; set; }

        public BusinessException(string errorCode,  BVGStatusCode statusCode)
        {
            ErrorCode = errorCode;
            StatusCode = (int)statusCode;
        }
    }
}
