﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Configuration
{
    public class GlobalExceptions
    {
        public float Budget { get; set; }
    }
}
