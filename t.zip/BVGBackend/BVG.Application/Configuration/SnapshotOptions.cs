﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Configuration
{
    public class SnapshotOptions
    {
        public int MaxRetryAttempts { get; set; } = 3;
        public int RetryDelaySeconds { get; set; } = 10;
    }
}
