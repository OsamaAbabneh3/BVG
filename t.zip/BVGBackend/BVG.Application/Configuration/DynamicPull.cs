﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Configuration
{
    public class DynamicPull
    {
        public bool Enable { get; set; } = true;
        public int Year { get; set; } = 2026;
        public int Month { get; set; } = 9;
    }
}
