﻿using Helper.InvoiceExeption;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Strategy.Layer
{
    public class LayerStrategy : ILayerStrategy
    {
        public Task ExecuteAsync(AuditContext auditContext, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}
