﻿using Helper.InvoiceExeption;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Strategy.Layer
{
    public interface ILayerStrategy
    {
        Task ExecuteAsync(AuditContext auditContext,CancellationToken cancellationToken);
    }
}
