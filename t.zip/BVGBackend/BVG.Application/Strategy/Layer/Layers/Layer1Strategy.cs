﻿using BVG.Application.Strategy.LayerRule;
using BVG.Domain.Enums;
using Helper.InvoiceExeption;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Strategy.Layer.Layers
{
    public sealed class Layer1Strategy:ILayerStrategy
    {
        private readonly ILayerRuleRunner _runner;
        public Layer1Strategy(ILayerRuleRunner runner)
        {
            _runner = runner;
        }

        public async Task ExecuteAsync(AuditContext auditContext, CancellationToken cancellationToken)
        {
            await _runner.ExecuteLayerAsync(AuditLayer.Layer1,auditContext, cancellationToken);
        }
    }
}
