﻿using BVG.Application.Strategy.LayerRule;
using BVG.Domain.Enums;
using Helper.InvoiceExeption;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Strategy.Layer.Layers
{
    public sealed class Layer2Strategy : ILayerStrategy
    {
        private readonly ILayerRuleRunner _runner;
        public Layer2Strategy(ILayerRuleRunner runner)
        {
            _runner = runner;
        }

        public async Task ExecuteAsync(AuditContext auditContext, CancellationToken cancellationToken)
        {
            await _runner.ExecuteLayerAsync(AuditLayer.Layer2, auditContext, cancellationToken);
        }
    }
}
