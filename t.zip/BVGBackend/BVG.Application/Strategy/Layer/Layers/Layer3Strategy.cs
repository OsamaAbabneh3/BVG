﻿using BVG.Application.Strategy.LayerRule;
using BVG.Domain.Enums;
using Helper.InvoiceExeption;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Strategy.Layer.Layers
{
    public sealed class Layer3Strategy : ILayerStrategy
    {
        private readonly ILayerRuleRunner _runner;
        public Layer3Strategy(ILayerRuleRunner runner)
        {
            _runner = runner;
        }

        public async Task ExecuteAsync(AuditContext auditContext, CancellationToken cancellationToken)
        {
            await _runner.ExecuteLayerAsync(AuditLayer.Layer3, auditContext, cancellationToken);
        }
    }
}
