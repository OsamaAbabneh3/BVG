﻿using BVG.Application.Strategy.Layer.Layers;
using Helper.InvoiceExeption;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Strategy
{
    public class AuditStrategy
    {
        private readonly Layer1Strategy _layer1;
        private readonly Layer2Strategy _layer2;
        private readonly Layer3Strategy _layer3;

        public AuditStrategy(Layer1Strategy layer1, Layer2Strategy layer2, Layer3Strategy layer3)
        {
            _layer1 = layer1;
            _layer2 = layer2;
            _layer3 = layer3;
        
        }

        public async Task ExecuteAsync(AuditContext auditContext,CancellationToken cancellationToken)
        {
            await _layer1.ExecuteAsync(auditContext, cancellationToken);
            await _layer2.ExecuteAsync(auditContext,cancellationToken);
            await _layer3.ExecuteAsync(auditContext,cancellationToken);
        }
    }
}
