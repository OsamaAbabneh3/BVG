﻿using BVG.Domain.Enums;
using Helper.InvoiceExeption;

namespace BVG.Application.Strategy.LayerRule
{
    public interface ILayerRuleRunner
    {
        Task ExecuteLayerAsync(AuditLayer auditLayer, AuditContext auditContext, CancellationToken cancellationToken);
    }
}
