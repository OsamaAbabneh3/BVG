﻿using BVG.Application.Services;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Helper.InvoiceExeption;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Strategy.LayerRule
{
    public sealed class LayerRuleRunner : ILayerRuleRunner
    {
        private readonly IRuleCatalogRepository _ruleCatalogRepository;
        private readonly IGeneralRepository _generalRepository;
        private readonly ICycleInfoRuningStatusService _cycleInfoRuningStatusService;

        public LayerRuleRunner(
            IRuleCatalogRepository ruleCatalogRepository,
            IGeneralRepository generalRepository,
            ICycleInfoRuningStatusService cycleInfoRuningStatusService)
        {
            _ruleCatalogRepository = ruleCatalogRepository;
            _generalRepository = generalRepository;
            _cycleInfoRuningStatusService = cycleInfoRuningStatusService;
        }
        public async Task ExecuteLayerAsync(AuditLayer auditLayer, AuditContext auditContext, CancellationToken cancellationToken)
        {
            await _cycleInfoRuningStatusService.CreateCycleInfoRuningStatus(auditContext.BulkId, CycleInfoRuningStatusActionEnum.StartLayer, cancellationToken, auditContext.StartId, auditContext.EndId, (int)auditLayer);
            var rules = await _ruleCatalogRepository.GetRuleByLayer((byte)auditLayer,cancellationToken);
            foreach (var rule in rules)
            {
                if (rule.QuerySql != null && rule.IsActive)
                {
                    var exceptions = await _generalRepository.ExceuteAsync(auditContext.StartId, auditContext.EndId, rule.QuerySql, cancellationToken);
                    auditContext.ExceptionBatch.AddRange(exceptions, auditContext.BulkId, rule.Id);
                }
            }
            await _cycleInfoRuningStatusService.CreateCycleInfoRuningStatus(auditContext.BulkId, CycleInfoRuningStatusActionEnum.EndLayer, cancellationToken, auditContext.StartId, auditContext.EndId, (int)auditLayer);
        }
    }
}
