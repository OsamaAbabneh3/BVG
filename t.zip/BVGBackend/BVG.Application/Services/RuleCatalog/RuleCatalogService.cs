﻿using BVG.Application.Common;
using BVG.Application.Services.Paginator;
using BVG.Application.Services.UnitOfWork;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
namespace BVG.Application.Services
{
    public class RuleCatalogService : IRuleCatalogService
    {
        private readonly IRuleCatalogRepository _ruleCatalogRepository;
        private readonly IPaginatorService _paginatorService;
        private readonly IUnitOfWorkService _unitOfWorkService;
        private readonly ILogger<RuleFamilyService> _logger;
        private readonly IStringLocalizer<Messages> _localizer;
        private readonly IAuditLogService _auditLogService;
        private readonly IRuleFamilyRepository _ruleFamilyRepository;

        public RuleCatalogService(
            IRuleCatalogRepository ruleCatalogRepository,
            IPaginatorService paginatorService,
            IAuditLogService auditLogService,
            ILogger<RuleFamilyService> logger,
            IUnitOfWorkService unitOfWorkService,
            IStringLocalizer<Messages> localizer,
            IRuleFamilyRepository ruleFamilyRepository
            )
        {
            _ruleCatalogRepository = ruleCatalogRepository;
            _paginatorService = paginatorService;
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
            _localizer = localizer;
            _auditLogService = auditLogService;
            _ruleFamilyRepository = ruleFamilyRepository;
        }
        public async Task<BVGResponse<PaginationResponseDto>> GetAllRuleCatalog(DynamicPaginationDto dto, CancellationToken cancellationToken)
        {
            var query = _ruleCatalogRepository.Query(dto.FilterOptions);

            bool columnExists = typeof(RuleCatalog).GetProperties().Any(p => p.Name.Equals(dto.OrderBy, StringComparison.OrdinalIgnoreCase));

            if (!columnExists)
            {
                return BVGResponse<PaginationResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidColumnNameInOrderBy);
            }

            bool isDescending = dto.OrderDirection == OrderDirectionEnum.DESC;
            query = query.OrderByProperty(dto.OrderBy, isDescending);

            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);

            var data = await result.Query
                .Select(rule => new GetRuleCatalogDto
                {
                    Id = rule.Id,
                    RuleCode = rule.RuleCode,
                    RuleName = rule.RuleName,
                    Description = rule.Description,
                    Severity = (SeverityEnum)rule.Severity,
                    QuerySql = rule.QuerySql,
                    AlertBudget = rule.AlertBudget,
                    Mode = (ModeEnum)rule.Mode,
                    Layer = rule.Layer,
                    Version = rule.Version,
                    IsActive = rule.IsActive,
                    CreatedAt = rule.CreatedAt,
                    UpdatedAt = rule.UpdatedAt,
                    FamilyId = rule.FamilyId,
                }).ToListAsync();

            return BVGResponse<PaginationResponseDto>.Success( new PaginationResponseDto
                {
                    Data = data,
                    PageNumber = dto.PageNumber,
                    PageSize = dto.PageSize,
                    TotalCount = result.TotalCount
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }

        public async Task<BVGResponse<GetByIdRuleCatalogDto>> GetByIdRuleCatalog(long id, CancellationToken cancellationToken)
        {
            var rule = await _ruleCatalogRepository.GetByIdRuleCatalog(id, cancellationToken);
            if (rule == null)
            {
                return BVGResponse<GetByIdRuleCatalogDto>.Fail(BVGStatusCode.NotFound, BVGErrorCode.RuleCatalogNotFound);
            }

            var data = new GetByIdRuleCatalogDto
            {
                Id = rule.Id,
                RuleCode = rule.RuleCode,
                RuleName = rule.RuleName,
                Description = rule.Description,
                Severity = (SeverityEnum)rule.Severity,
                QuerySql = rule.QuerySql,
                AlertBudget = rule.AlertBudget,
                Mode = (ModeEnum)rule.Mode,
                Layer = rule.Layer,
                Version = rule.Version,
                IsActive = rule.IsActive,
                CreatedAt = rule.CreatedAt,
                UpdatedAt = rule.UpdatedAt,
                FamilyId = (int)rule.FamilyId,
            };

            return BVGResponse<GetByIdRuleCatalogDto>.Success(data, BVGMessage.ReturnSuccessfully, BVGStatusCode.Ok);
        }

        public async Task<BVGResponse<object>> CreateRuleCatalog(CreateRuleCatalogDto dto, CancellationToken cancellationToken)
        {
            var ruleFamily = await _ruleFamilyRepository.getByIdRuleFamily(dto.FamilyId, cancellationToken);

            if (ruleFamily == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.RuleFamilyNotFound);
            }
            var ruleName = dto.RuleName.Trim();
            var ruleCode = dto.RuleCode.Trim();

            var ruleEntity = new RuleCatalog
            {
                RuleCode = dto.RuleCode.Trim(),
                RuleName = dto.RuleName.Trim(),
                Description = dto.Description,
                Severity = (byte)dto.Severity,
                QuerySql = dto.QuerySql,
                AlertBudget = dto.AlertBudget,
                Mode = (byte)ModeEnum.Monitor,
                Layer = (byte)dto.Layer,
                Version = "1",
                IsActive = dto.IsActive,
                CreatedAt = DateTime.UtcNow,
                FamilyId = dto.FamilyId
            };
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                var versions = await _ruleCatalogRepository.GetRuleVersionsAsync(ruleEntity, cancellationToken);
                ruleEntity.Version = (
                    versions.Select(v => int.Parse(v))
                            .DefaultIfEmpty(0)
                            .Max() + 1
                ).ToString();

                if (ruleEntity.IsActive)
                {
                    await _ruleCatalogRepository.DeactivateOtherVersionsAsync(ruleEntity,cancellationToken);
                }
                await _ruleCatalogRepository.CreateRuleCatalog(ruleEntity, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.CreateRuleCatalog, EntityTypeEnum.RuleCatalog, ruleEntity.Id.ToString(),cancellationToken, ruleEntity.RuleName);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }


            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }


        public async Task<BVGResponse<object>> UpdateRuleCatalog(UpdateRuleCatalogDto updateDto,CancellationToken cancellationToken)
        {
            var existingRule = await _ruleCatalogRepository.GetByIdRuleCatalog(updateDto.Id, cancellationToken);

            if (existingRule == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound,BVGErrorCode.RuleCatalogNotFound);
            }

            existingRule.RuleName = updateDto.RuleName.Trim();
            existingRule.Description = updateDto.Description;
            existingRule.Severity = (byte)updateDto.Severity;
            existingRule.QuerySql = updateDto.QuerySql;
            existingRule.AlertBudget = updateDto.AlertBudget;
            existingRule.Layer = existingRule.Layer == 0 ? (byte)0 : (byte)updateDto.Layer;
            existingRule.IsActive = updateDto.IsActive;
            existingRule.UpdatedAt = DateTime.UtcNow;

            try
            {
                await _unitOfWorkService.BeginTransactionAsync();

                if (existingRule.IsActive)
                {
                    await _ruleCatalogRepository.DeactivateOtherVersionsAsync(existingRule,cancellationToken);
                }
                await _ruleCatalogRepository.UpdateRuleCatalog(existingRule,cancellationToken);
                await _auditLogService.CreateAuditLog(null,SystemActionEnum.UpdateRuleCatalog,EntityTypeEnum.RuleCatalog,existingRule.Id.ToString(),cancellationToken,existingRule.RuleName);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex, ex.Message);
                throw;
            }

            return BVGResponse<object>.Success(null,BVGMessage.ReturnSuccessfully,BVGStatusCode.Ok);
        }


        public async Task<BVGResponse<DeleteRuleCatalogDto>> DeleteRuleCatalog(DeleteRuleCatalogDto deleteDto, CancellationToken cancellationToken)
        {
            var ruleCatalog = await _ruleCatalogRepository.GetByIdRuleCatalog(deleteDto.Id, cancellationToken);
            if (ruleCatalog == null) 
            {
                return BVGResponse<DeleteRuleCatalogDto>.Fail(BVGStatusCode.NotFound, BVGErrorCode.RuleCatalogNotFound);
            }

            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _ruleCatalogRepository.DeleteRuleCatalog(deleteDto.Id, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.DeleteRuleCatalog, EntityTypeEnum.RuleCatalog, deleteDto.Id.ToString(), cancellationToken);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }
            return BVGResponse<DeleteRuleCatalogDto>.Success(new DeleteRuleCatalogDto { Id = deleteDto.Id }, BVGMessage.DeletedSuccessfully, BVGStatusCode.Ok);
        }
    }


}


