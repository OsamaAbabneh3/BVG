﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public interface IRuleCatalogService
    {
        Task<BVGResponse<GetByIdRuleCatalogDto>> GetByIdRuleCatalog(long id, CancellationToken cancellationToken);
        Task<BVGResponse<object>> CreateRuleCatalog(CreateRuleCatalogDto createRuleCatalogDto, CancellationToken cancellationToken);
        Task<BVGResponse<object>> UpdateRuleCatalog(UpdateRuleCatalogDto updateDto, CancellationToken cancellationToken);
        Task<BVGResponse<DeleteRuleCatalogDto>> DeleteRuleCatalog(DeleteRuleCatalogDto deleteDto, CancellationToken cancellationToken);
        Task<BVGResponse<PaginationResponseDto>> GetAllRuleCatalog(DynamicPaginationDto dto, CancellationToken cancellationToken);
        
    }
}
