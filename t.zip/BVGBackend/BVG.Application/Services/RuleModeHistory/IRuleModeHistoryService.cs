﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public interface IRuleModeHistoryService
    {
        Task<BVGResponse<PaginationResponseDto>> GetAllRuleModeHistory(DynamicPaginationDto dto, CancellationToken cancellationToken);
        Task<BVGResponse<GetRuleModeHistoryDto>> GetByIdRuleModeHistory(long id, CancellationToken cancellationToken);
        Task<BVGResponse<object>> AddRuleModeHistory(AddRuleModeHistoryDto addRuleModeHistoryDto, CancellationToken cancellationToken);
    }
}
