﻿using BVG.Application.Common;
using BVG.Application.Services.Paginator;
using BVG.Application.Services.UnitOfWork;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Microsoft.Extensions.Localization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public class RuleModeHistoryService : IRuleModeHistoryService
    {
        private readonly IRuleModeHistoryRepository _ruleModeHistoryRepository;
        private readonly IPaginatorService _paginatorService;
        private readonly IUnitOfWorkService _unitOfWorkService;
        private readonly ILogger<RuleModeHistoryService> _logger;
        private readonly IStringLocalizer<Messages> _localizer;
        private IAuditLogRepository _auditLogRepository;
        private IAuditLogService _auditLogService;

        public RuleModeHistoryService(
            IRuleModeHistoryRepository ruleModeHistoryRepository,
            IPaginatorService paginatorService,
            IAuditLogRepository auditLogRepository,
            IAuditLogService auditLogService,
            ILogger<RuleModeHistoryService> logger,
            IUnitOfWorkService unitOfWorkService,
            IStringLocalizer<Messages> localizer


            )
        {
            _ruleModeHistoryRepository = ruleModeHistoryRepository;
            _paginatorService = paginatorService;
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
            _auditLogRepository = auditLogRepository;
            _auditLogService = auditLogService;
            _localizer = localizer;
        }
        public async Task<BVGResponse<PaginationResponseDto>> GetAllRuleModeHistory(DynamicPaginationDto dto, CancellationToken cancellationToken)
        {
            var query = _ruleModeHistoryRepository.Query(dto.FilterOptions);

            bool columnExists = typeof(RuleModeHistory).GetProperties().Any(p => p.Name.Equals(dto.OrderBy, StringComparison.OrdinalIgnoreCase));

            if (!columnExists)
            {
                return BVGResponse<PaginationResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidColumnNameInOrderBy);
            }

            bool isDescending = dto.OrderDirection == OrderDirectionEnum.DESC;
            query = query.OrderByProperty(dto.OrderBy, isDescending);

            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);

            var data = await result.Query
                .Select(rule => new GetRuleModeHistoryDto
                {
                    Id = rule.Id,
                    RuleId = rule.RuleId,
                    CycleId = rule.CycleId,
                    Mode = (ModeEnum)rule.Mode,
                    ExceededAlertCount = rule.ExceededAlertCount,
                    CreatedAt = rule.CreatedAt,
                    UpdatedAt = rule.UpdatedAt,
                  
                }).ToListAsync();

            return BVGResponse<PaginationResponseDto>.Success(
                new PaginationResponseDto
                {
                    Data = data,
                    PageNumber = dto.PageNumber,
                    PageSize = dto.PageSize,
                    TotalCount = result.TotalCount
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }

        public async Task<BVGResponse<GetRuleModeHistoryDto>> GetByIdRuleModeHistory(long id, CancellationToken cancellationToken)
        {
            var r = await _ruleModeHistoryRepository.GetByIdRuleModeHistory(id, cancellationToken);
            if (r == null)
                return BVGResponse<GetRuleModeHistoryDto>.Fail(BVGStatusCode.NotFound, BVGErrorCode.RuleModeHistoryNotFound);
            //exception
            return BVGResponse<GetRuleModeHistoryDto>.Success(new GetRuleModeHistoryDto
            {
                Id = r.Id,
                RuleId = r.RuleId,
                CycleId = r.CycleId,
                Mode = (ModeEnum)r.Mode,
                ExceededAlertCount = r.ExceededAlertCount,
                CreatedAt = r.CreatedAt,
                UpdatedAt = r.UpdatedAt,
            }, BVGMessage.ReturnSuccessfully, BVGStatusCode.Ok
            );

        }

        public async Task<BVGResponse<object>> AddRuleModeHistory(AddRuleModeHistoryDto addRuleModeHistoryDto, CancellationToken cancellationToken)
        {
            var ruleEntity = new RuleModeHistory
            {
                RuleId = addRuleModeHistoryDto.RuleId,
                CycleId = addRuleModeHistoryDto.CycleId,
                Mode = (byte)addRuleModeHistoryDto.Mode,
                ExceededAlertCount = addRuleModeHistoryDto.ExceededAlertCount,
                CreatedAt = addRuleModeHistoryDto.CreatedAt ?? DateTime.UtcNow
            };
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _ruleModeHistoryRepository.AddRuleModeHistory(ruleEntity, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.AddRuleModeHistory, EntityTypeEnum.RuleModeHistory, ruleEntity.Id.ToString(), cancellationToken);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }


            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }
    }
}
