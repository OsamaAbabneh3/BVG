﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public interface ICycleInfoService
    {
        Task<BVGResponse<PaginationResponseDto>> GetAllCycleInfo(DynamicPaginationDto dto, CancellationToken cancellationToken);
        Task<BVGResponse<GetCycleInfoDto>> GetByIdCycleInfo(long id, CancellationToken cancellationToken);
        Task<BVGResponse<object>> AddCycleInfo(AddCycleInfoDto addCycleInfoDto, CancellationToken cancellationToken);
        Task<BVGResponse<object>> UpdateCycleInfo(UpdateCycleInfoDto updateCycleInfoDto, CancellationToken cancellationToken);
    }
}
