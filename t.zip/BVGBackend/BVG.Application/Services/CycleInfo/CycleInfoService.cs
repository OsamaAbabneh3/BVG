﻿using BVG.Application.Common;
using BVG.Application.Services.Paginator;
using BVG.Application.Services.UnitOfWork;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public class CycleInfoService : ICycleInfoService
    {
        private readonly ICycleInfoRepository _cycleInfoRepository;
        private readonly IPaginatorService _paginatorService;
        private readonly ILogger<CycleInfoService> _logger;
        private readonly IStringLocalizer<Messages> _localizer;
        private readonly IUnitOfWorkService _unitOfWorkService;
        private IAuditLogRepository _auditLogRepository;
        private IAuditLogService _auditLogService;
        public CycleInfoService(
           ICycleInfoRepository cycleInfoRepository,
           IPaginatorService paginatorService,
           IAuditLogRepository auditLogRepository,
           IAuditLogService auditLogService,
            ILogger<CycleInfoService> logger,
           IUnitOfWorkService unitOfWorkService,
           IStringLocalizer<Messages> localizer


           )
        {
            _cycleInfoRepository = cycleInfoRepository;
            _paginatorService = paginatorService;
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
            _auditLogRepository = auditLogRepository;
            _auditLogService = auditLogService;
            _localizer = localizer;
        }
        public async Task<BVGResponse<object>> AddCycleInfo(AddCycleInfoDto addCycleInfoDto, CancellationToken cancellationToken)
        {
            var cycle = new CycleInfo
            {
                CycleDate = addCycleInfoDto.CycleDate,
                StartDate = addCycleInfoDto.StartDate,
                EndDate = addCycleInfoDto.EndDate,
                CreatedAt = DateTime.UtcNow
            };
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _cycleInfoRepository.AddCycleInfo(cycle, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.AddCycleInfo, EntityTypeEnum.CycleInfo, cycle.Id.ToString(), cancellationToken);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }


            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }

        public async Task<BVGResponse<PaginationResponseDto>> GetAllCycleInfo(DynamicPaginationDto dto, CancellationToken cancellationToken)
        {
            var query = _cycleInfoRepository.Query(dto.FilterOptions);

            bool columnExists = typeof(CycleInfo).GetProperties().Any(p => p.Name.Equals(dto.OrderBy, StringComparison.OrdinalIgnoreCase));

            if (!columnExists)
            {
                return BVGResponse<PaginationResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidColumnNameInOrderBy);
            }

            bool isDescending = dto.OrderDirection == OrderDirectionEnum.DESC;
            query = query.OrderByProperty(dto.OrderBy, isDescending);

            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);
            var data = await result.Query
                .Select(r => new GetCycleInfoDto
                {
                    Id = r.Id,
                    CycleDate = r.CycleDate,
                    StartDate = r.StartDate,
                    EndDate = r.EndDate,
                    CreatedAt = r.CreatedAt,
                    UpdatedAt = r.UpdatedAt,

                }).ToListAsync();

            return BVGResponse<PaginationResponseDto>.Success(
                new PaginationResponseDto
                {
                    Data = data,
                    PageNumber = dto.PageNumber,
                    PageSize = dto.PageSize,
                    TotalCount = result.TotalCount
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }

        public async Task<BVGResponse<GetCycleInfoDto>> GetByIdCycleInfo(long id, CancellationToken cancellationToken)
        {
            var r = await _cycleInfoRepository.GetByIdCycleInfo(id, cancellationToken);
            if (r == null)
                return BVGResponse<GetCycleInfoDto>.Fail(BVGStatusCode.NotFound, BVGErrorCode.CycleInfoNotFound);
            //exception
            return BVGResponse<GetCycleInfoDto>.Success(new GetCycleInfoDto
            {
                Id = r.Id,
                CycleDate = r.CycleDate,
                StartDate = r.StartDate,
                EndDate = r.EndDate,
                CreatedAt = r.CreatedAt,
                UpdatedAt = r.UpdatedAt,

            }, BVGMessage.ReturnSuccessfully, BVGStatusCode.Ok
            );


        }

        public async Task<BVGResponse<object>> UpdateCycleInfo(UpdateCycleInfoDto updateCycleInfoDto, CancellationToken cancellationToken)
        {

            var existingRule = await _cycleInfoRepository.GetByIdCycleInfo(updateCycleInfoDto.Id, cancellationToken);
            if (existingRule == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.CycleInfoNotFound);
            }
            existingRule.EndDate = updateCycleInfoDto.EndDate;
            existingRule.UpdatedAt = DateTime.UtcNow;
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _cycleInfoRepository.UpdateCycleInfo(existingRule, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.UpdateCycleInfo, EntityTypeEnum.CycleInfo, existingRule.Id.ToString(), cancellationToken);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }
            return BVGResponse<object>.Success(null, BVGMessage.ReturnSuccessfully, BVGStatusCode.Ok);
        }

    }
}
