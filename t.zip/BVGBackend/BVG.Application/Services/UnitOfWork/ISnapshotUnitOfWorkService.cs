﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace BVG.Application.Services.UnitOfWork
{
    public interface ISnapshotUnitOfWorkService
    {
        Task BeginTransactionAsync(IsolationLevel isolationLevel = IsolationLevel.ReadCommitted);

        Task CommitAsync();

        Task RollbackAsync();
    }
}
