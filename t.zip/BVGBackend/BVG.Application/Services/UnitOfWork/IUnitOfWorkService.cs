﻿using System.Data;

namespace BVG.Application.Services.UnitOfWork
{
    public interface IUnitOfWorkService
    {
        Task BeginTransactionAsync(IsolationLevel isolationLevel = IsolationLevel.ReadCommitted);

        Task CommitAsync();

        Task RollbackAsync();
    }
}
