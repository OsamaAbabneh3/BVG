﻿using BVG.Domain.Interfaces;
using System.Data;

namespace BVG.Application.Services.UnitOfWork
{
    public class SnapshotUnitOfWorkService : ISnapshotUnitOfWorkService
    {
        private readonly ISnapshotUnitOfWorkRepository _snapshotUnitOfWorkRepository;

        public SnapshotUnitOfWorkService(ISnapshotUnitOfWorkRepository snapshotUnitOfWorkRepository)
        {
            _snapshotUnitOfWorkRepository = snapshotUnitOfWorkRepository;
        }
        public async Task BeginTransactionAsync(IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
        {
            await _snapshotUnitOfWorkRepository.BeginTransactionAsync();
        }

        public async Task CommitAsync()
        {
            await _snapshotUnitOfWorkRepository.CommitAsync();
        }

        public async Task RollbackAsync()
        {
            await _snapshotUnitOfWorkRepository.RollbackAsync();
        }
    }
}
