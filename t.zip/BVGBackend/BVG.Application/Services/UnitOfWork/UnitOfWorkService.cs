﻿using BVG.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace BVG.Application.Services.UnitOfWork
{
    public class UnitOfWorkService : IUnitOfWorkService
    {
        private readonly IUnitOfWorkRepository _unitOfWorkRepository;

        public UnitOfWorkService(IUnitOfWorkRepository unitOfWorkRepository)
        {
            _unitOfWorkRepository = unitOfWorkRepository;
        }

        public async Task BeginTransactionAsync(IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
        {
            await _unitOfWorkRepository.BeginTransactionAsync();
        }

        public async Task CommitAsync()
        {
            await _unitOfWorkRepository.CommitAsync();
        }

        public async Task RollbackAsync()
        {
            await _unitOfWorkRepository.RollbackAsync();
        }
    }
}
