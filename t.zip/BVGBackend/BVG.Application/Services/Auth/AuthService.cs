﻿using BVG.Application.Common;
using BVG.Application.Exceptions;
using BVG.Application.Services.Otp;
using BVG.Application.Services.UnitOfWork;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Security;
using System.Security.Claims;
using System.Text;

namespace BVG.Application.Services.Jwt
{
    public class AuthService : IAuthService
    {
        #region DI AuthService
        private readonly IConfiguration _configuration;
        private readonly IUserRepository _userRepository;
        private readonly IUnitOfWorkService _unitOfWorkService;
        private readonly ILogger<UserService> _logger;
        private readonly IAuditLogService _auditLogService;
        private readonly IOtpService _otpService;
        #endregion

        #region AuthService
        public AuthService(
            IConfiguration configuration,
            IUserRepository userRepository,
            ILogger<UserService> logger,
            IUnitOfWorkService unitOfWorkService,
            IAuditLogRepository auditLogRepository,
            IStringLocalizer<Messages> localizer,
            IAuditLogService auditLogService,
            IOtpService otpService
         )
        {
            _configuration = configuration;
            _userRepository = userRepository;
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
            _auditLogService = auditLogService;
            _otpService = otpService;
        }
        #endregion

        #region Login
        /// <summary>
        /// Operation Login
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>

        public async Task<BVGResponse<RequestLoginResponseDto>> Login(LoginDto dto, CancellationToken cancellationToken)
        {
            //check the user name is exist or not
            var user = await _userRepository.GetByIdentifier(dto.Identifier, cancellationToken);
            var maxAttempt =int.Parse(_configuration["Login:MaxAttempt"]??"3");
            if (user == null)
            {
                return BVGResponse<RequestLoginResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidCredential);
            }

            // check password hash IMPLEMENT WITH REDIS
            var hasher = new PasswordHasher<BvgUser>();
            var pass = hasher.VerifyHashedPassword(null!, user.PasswordHash, dto.Password.Trim());

            if (pass == PasswordVerificationResult.Failed)
            {
                if (user.LastTryAttempt.HasValue)
                {
                    TimeSpan timePassedSinceLastAttempt = DateTime.UtcNow - user.LastTryAttempt.Value;

                    if (timePassedSinceLastAttempt.TotalMinutes >= double.Parse(_configuration["Login:LastTryAttempt"] ?? "1"))
                    {

                        user.LoginTryAttempt = 0;
                        user.LockedUntil = null;
                        user.LastTryAttempt = null;
                       
                    }
                }
                if (user.LoginTryAttempt <= maxAttempt)
                {
                    user.LoginTryAttempt += 1;
                    user.LastTryAttempt = DateTime.UtcNow;
                    if (user.LoginTryAttempt > maxAttempt)
                    {
                        user.LockedUntil = DateTime.UtcNow.AddMinutes(double.Parse(_configuration["Login:LockedUntil"] ??"15"));
                        
                    }
                    
                }
                await _userRepository.UpdateAsync(user, cancellationToken);
                return BVGResponse<RequestLoginResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidCredential);
            }
            // check the use is blocked or not
            if (user.IsBlocked)
            {
                return BVGResponse<RequestLoginResponseDto>.Fail(BVGStatusCode.Forbidden, BVGErrorCode.UserBlocked);
            }

            // check user ehn try enter password failed check the locked unitl the user IMPLEMENT WITH REDIS
            if (user.LockedUntil != null)
            {
                if (user.LockedUntil > DateTime.UtcNow)
                {
                    return BVGResponse<RequestLoginResponseDto>.Fail(BVGStatusCode.Forbidden, BVGErrorCode.UserLocked, null, user.LockedUntil.ToString()!);
                }
                else
                {
                    user.LoginTryAttempt = 0;
                    user.LockedUntil = null;
                    user.LastTryAttempt = null;
                    await _userRepository.UpdateAsync(user, cancellationToken);
                }
            }


            // get permission 
            var permissions = user.UserRoles
                .Select(ur => ur.Role)
                .Where(r => r != null)
                .SelectMany(r => r!.RolePermissions)
                .Select(rp => rp.Permission?.PermissionName)
                .Where(pName => pName != null)
                .ToList();

            //check permission with 

            if (permissions.Count == 0)
            {
                return BVGResponse<RequestLoginResponseDto>.Fail(BVGStatusCode.Conflict, BVGErrorCode.InvalidPermissions);
            }
            if (string.IsNullOrEmpty(user.PhoneNumber))
            {
                return BVGResponse<RequestLoginResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.PhoneNotConfigured);
            }
            try
            {
                var otp = await _otpService.SendAsync(user.UserName, user.PhoneNumber, OtpPurpose.Login);
              
                return BVGResponse<RequestLoginResponseDto>.Success(
                    new RequestLoginResponseDto
                    {
                        RequestToken = otp.RequestToken,
                        ExpireInSecond = otp.ExpiresInSeconds
                    },
                    BVGMessage.ExecuteSuccessfully,
                    BVGStatusCode.Ok
                    );
            }
            catch(OtpException ex)
            {
                return BVGResponse<RequestLoginResponseDto>.Fail(ex.StatusCode, ex.ErrorCode);
            }

            //try
            //{
            //    //Add audit log when login user and check transaction
            //    await _auditLogRepository.AddAsync(new AuditLog
            //    {
            //        ActionType = (int)SystemActionEnum.LoginSuccessfully,
            //        Details = $"\u202b {_localizer[SystemActionEnum.LoginSuccessfully.ToString(), user.UserName]} \u202c",
            //        CreatedAt = DateTime.UtcNow,
            //    });

            //    await _userRepository.AddAsync(user);
            //    await _unitOfWorkService.CommitAsync();
            //}
            //catch (Exception ex)
            //{
            //    await _unitOfWorkService.RollbackAsync();
            //    _logger.LogError(ex.Message);
            //    throw;
            //}
            //return BVGResponse<LoginResponseDto>.Success(
            //    new LoginResponseDto
            //    {
            //        AccessToken = GenerateToken(user.Id, user.UserName, permissions.ToHashSet()!)
            //    },
            //    BVGMessage.ExecuteSuccessfully,
            //    BVGStatusCode.Ok
            //);
        }

        public async Task<BVGResponse<LoginResponseDto>> VerfiyLoginOtp(VerifyLoginOtpDto dto, CancellationToken cancellationToken)
        {
            string username;
            try
            {
                username = await _otpService.VerifyAsync(dto.RequestToken, dto.Code.Trim(), OtpPurpose.Login);
            }
            catch(OtpException ex)
            {
                return BVGResponse<LoginResponseDto>.Fail(ex.StatusCode, ex.ErrorCode);
            }

            var user = await _userRepository.GetByUsername(username, cancellationToken);
            if (user == null || user.IsBlocked)
            {
                return BVGResponse<LoginResponseDto>.Fail(BVGStatusCode.Forbidden, BVGErrorCode.UserBlocked);
            }
            if (user.LockedUntil != null && user.LockedUntil > DateTime.UtcNow)
            {
                return BVGResponse<LoginResponseDto>.Fail(BVGStatusCode.Forbidden, BVGErrorCode.UserLocked);
            }

            var permissions = user.UserRoles
                .Select(ur => ur.Role)
                .Where(r => r != null)
                .SelectMany(r => r!.RolePermissions)
                .Select(rp => rp.Permission?.PermissionName)
                .Where(pName => pName != null)
                .ToList();
            if (permissions.Count == 0)
            {
                return BVGResponse<LoginResponseDto>.Fail(BVGStatusCode.Conflict, BVGErrorCode.InvalidPermissions);
            }
            try
            {
                //Add audit log when login user and check transaction
                await _unitOfWorkService.BeginTransactionAsync();
                await _auditLogService.CreateAuditLog(user.Id, SystemActionEnum.LoginSuccessfully, EntityTypeEnum.BvgUser, user.Id.ToString(), cancellationToken, user.UserName);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }

            var data = new LoginResponseDto
            {
                AccessToken = GenerateToken(user.Id, user.UserName, permissions.ToHashSet()!),
                MustChangePassword = user.MustChangePassword
            };

            return BVGResponse<LoginResponseDto>.Success(data, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);

        }

        public async Task<BVGResponse<object>> ResetPassword(ResetPasswordDto dto, CancellationToken cancellationToken)
        {
            var userId = BVGText.GetUserId();
            if (userId == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.Unauthorized, BVGErrorCode.Unauthorized);
            }
            var user = await _userRepository.GetById(userId.Value, cancellationToken);

            if (user == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.UserNotFound);
            }

            if (dto.OldPassword.Trim() == dto.NewPassword.Trim())
            {
                return BVGResponse<object>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.NewPasswordCannotBeSameAsOld);
            }

            var hasher = new PasswordHasher<BvgUser>();
            var pass = hasher.VerifyHashedPassword(null!, user.PasswordHash, dto.OldPassword.Trim());

            if (pass == PasswordVerificationResult.Failed)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidOldPassword);
            }
            user.PasswordHash = hasher.HashPassword(null!, dto.NewPassword.Trim());
            user.MustChangePassword = false;
            await _userRepository.UpdateAsync(user, cancellationToken);
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _auditLogService.CreateAuditLog(user.Id, SystemActionEnum.ResetPassword, EntityTypeEnum.BvgUser, user.Id.ToString(), cancellationToken, user.UserName);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }
            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }

        public async Task<BVGResponse<object>> SendOtp(SendOtpDto dto, CancellationToken cancellationToken)
        {
            var user = await _userRepository.GetByIdentifier(dto.Identifier.Trim(), cancellationToken);
            if (user == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.UserNotFound);
            }

            try
            {
                var otp = await _otpService.SendAsync(user.UserName, user.PhoneNumber, OtpPurpose.ForgetPassword);
                var data = new RequestLoginResponseDto
                {
                    RequestToken = otp.RequestToken,
                    ExpireInSecond = otp.ExpiresInSeconds
                };

                return BVGResponse<object>.Success(data, BVGMessage.ExecuteSuccessfully,BVGStatusCode.Ok);
            }
            catch (OtpException ex)
            {
                return BVGResponse<object>.Fail(ex.StatusCode, ex.ErrorCode);
            }

        }

        public async Task<BVGResponse<object>> ForgetPassword(ForgetPasswordDto dto, CancellationToken cancellationToken)
        {
            string username;
            try
            {
                username = await _otpService.VerifyAsync(dto.RequestToken, dto.Code.Trim(), OtpPurpose.ForgetPassword);
            }
            catch (OtpException ex)
            {
                return BVGResponse<object>.Fail(ex.StatusCode, ex.ErrorCode);
            }

            var user = await _userRepository.GetByUsername(username, cancellationToken  );
            if (user == null || user.IsBlocked)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.Forbidden, BVGErrorCode.UserBlocked);
            }

            if (user.LockedUntil != null && user.LockedUntil > DateTime.UtcNow)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.Forbidden, BVGErrorCode.UserLocked);
            }

            var hasher = new PasswordHasher<BvgUser>();
            var pass = hasher.VerifyHashedPassword(null!, user.PasswordHash, dto.NewPassword.Trim());
            if (pass == PasswordVerificationResult.Success)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.NewPasswordCannotBeSameAsOld);
            }

            var passwordHash = hasher.HashPassword(null!, dto.NewPassword.Trim());
            user.PasswordHash = passwordHash;
            user.MustChangePassword = false;
            await _userRepository.UpdateAsync(user, cancellationToken);
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _auditLogService.CreateAuditLog(user.Id, SystemActionEnum.ForgetPassword, EntityTypeEnum.BvgUser, user.Id.ToString(), cancellationToken, user.UserName);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);   
                throw;
            }

            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }

        #endregion

        #region Helper Functionality from Auth Service
        /// <summary>
        /// Generate Token When login User
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="username"></param>
        /// <param name="permissions"></param>
        /// <returns></returns>

        private string GenerateToken(Guid userId, string username, HashSet<string> permissions)
        {
            var parsed = permissions.Select(permission => (int)Enum.Parse<PermissionsEnum>(permission));

            //Add Claims
            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
                new Claim(ClaimTypes.Name, username),
                //new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim("permissions", string.Join(",", parsed))
            };

            //get key encryption 
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!));

            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            //generate token 
            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(double.Parse(_configuration["Jwt:Expires"] ??"30")),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
        #endregion

    }
}
