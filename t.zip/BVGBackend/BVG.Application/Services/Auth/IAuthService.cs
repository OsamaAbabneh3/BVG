﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.Jwt
{
    public interface IAuthService
    {
        Task<BVGResponse<RequestLoginResponseDto>> Login(LoginDto dto, CancellationToken cancellationToken);
        Task<BVGResponse<LoginResponseDto>> VerfiyLoginOtp(VerifyLoginOtpDto dto, CancellationToken cancellationToken);
        Task<BVGResponse<object>> ResetPassword(ResetPasswordDto dto, CancellationToken cancellationToken);
        Task<BVGResponse<object>> SendOtp(SendOtpDto dto, CancellationToken cancellationToken);
        Task<BVGResponse<object>> ForgetPassword(ForgetPasswordDto dto, CancellationToken cancellationToken);
    }
}
