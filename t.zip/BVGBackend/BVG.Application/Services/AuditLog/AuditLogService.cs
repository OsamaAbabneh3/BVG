﻿using BVG.Application.Common;
using BVG.Application.Services.Paginator;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Helper.AuditLog;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public class AuditLogService : IAuditLogService
    {
        #region DI AuditLog
        private readonly IAuditLogRepository _auditLogRepository;
        private readonly IStringLocalizer<Messages> _localizer;
        private readonly ILogger<AuditLogService> _logger;
        private readonly IPaginatorService _paginatorService;
        #endregion

        #region AuditLogService
        public AuditLogService(
            IAuditLogRepository auditLogRepository,
            IStringLocalizer<Messages> localizer,
            ILogger<AuditLogService> logger,
            IPaginatorService paginatorService)
        {
            _auditLogRepository = auditLogRepository;
            _localizer = localizer;
            _logger = logger;
            _paginatorService = paginatorService;
        }
        #endregion

        #region AuditLog Services

        /// <summary>
        /// When Create Audit Log from anothe Servies when Create Update Delet this use Register Log By User Action
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="systemActionEnum"></param>
        /// <param name="entityTypeEnum"></param>
        /// <param name="entityRowId"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public async Task CreateAuditLog(
            Guid? userId,
            SystemActionEnum systemActionEnum, 
            EntityTypeEnum entityTypeEnum, 
            string entityRowId, 
            CancellationToken cancellationToken,
            params object[] args)
        {
            try
            {
                //Add The Audit Log
                await _auditLogRepository.AddAsync(new AuditLog
                {
                    UserId = userId != null ? userId : BVGText.GetUserId(),
                    CreatedAt = DateTime.UtcNow,
                    ActionType = (int)systemActionEnum,
                    EntityType = (int)entityTypeEnum,
                    EntityRowId = entityRowId,
                    Details = AuditLogHelper.GenerateAuditLogDetails(_localizer, systemActionEnum, args),
                }, cancellationToken);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Get Audit Log by Type and RowID From User
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<BVGResponse<PaginationResponseDto>> GetAuditLogsByRowIdPagination(AuditLogsByRowIdRequestDto dto, CancellationToken cancellationToken)
        {
            var query = _auditLogRepository
                .Query(dto.FilterOptions)
                .Where(log => log.EntityType == (int)dto.EntityType && log.EntityRowId == dto.EntityRowId);

            // check the column when filter the column is exist or not
            bool columnExists = typeof(AuditLog).GetProperties().Any(p => p.Name.Equals(dto.OrderBy));

            if (!columnExists)
            {
                return BVGResponse<PaginationResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidColumnNameInOrderBy);
            }
            // Order Data Users with DESC
            bool isDescending = dto.OrderDirection == OrderDirectionEnum.DESC;
            query = query.OrderByProperty(dto.OrderBy, isDescending);

            //Returning Data users with pagenation by page number and size
            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);



            var data = new List<AuditLogsByRowIdResponseDto>();
            foreach (var log in result.Query)
            {
                data.Add(new AuditLogsByRowIdResponseDto
                {
                    UserDetails = log.UserId != null ? new UserDetailsDto
                    {
                        Id = log.User!.Id,
                        Username = log.User!.UserName,
                        FirstName = log.User!.FirstName,
                        LastName = log.User!.LastName,
                        Email = log.User!.Email,
                    } : null,
                    ActionType = log.ActionType != null ? (SystemActionEnum)log.ActionType : null,
                    Details = log.Details,
                    OccurredAt = log.CreatedAt
                });
            }

            return BVGResponse<PaginationResponseDto>.Success(
                new PaginationResponseDto
                {
                    Data = data,
                    PageNumber = dto.PageNumber,
                    PageSize = dto.PageSize,
                    TotalCount = result.TotalCount
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }


        /// <summary>
        /// get the all audit by user id
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<BVGResponse<PaginationResponseDto>> GetAuditLogsByUserPagination(AuditLogsByUserRequestDto dto, CancellationToken cancellationToken)
        {
            var query = _auditLogRepository
                .Query(dto.FilterOptions)
                .Where(log => log.UserId == dto.UserId);

            // check the column when filter the column is exist or not
            bool columnExists = typeof(AuditLog).GetProperties().Any(p => p.Name.Equals(dto.OrderBy));

            if (!columnExists)
            {
                return BVGResponse<PaginationResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidColumnNameInOrderBy);
            }
            // Order Data Users with DESC
            bool isDescending = dto.OrderDirection == OrderDirectionEnum.DESC;
            query = query.OrderByProperty(dto.OrderBy, isDescending);

            //Returning Data users with pagenation by page number and size
            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);



            var data = new List<AuditLogsByUserResponseDto>();
            // each the data sorted with set by array list
            foreach (var log in result.Query)
            {
                data.Add(new AuditLogsByUserResponseDto
                {
                    ActionType = log.ActionType != null ? (SystemActionEnum)log.ActionType : null,
                    Details = log.Details,
                    OccurredAt = log.CreatedAt
                });
            }

            return BVGResponse<PaginationResponseDto>.Success(
                new PaginationResponseDto
                {
                    Data = data,
                    PageNumber = dto.PageNumber,
                    PageSize = dto.PageSize,
                    TotalCount = result.TotalCount
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }

        #endregion
    }
}
