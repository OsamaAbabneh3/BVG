﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public interface IAuditLogService
    {
        Task CreateAuditLog(Guid? userId, SystemActionEnum systemActionEnum, EntityTypeEnum entityTypeEnum, string entityRowId ,CancellationToken cancellationToken, params object[] args);

        Task<BVGResponse<PaginationResponseDto>> GetAuditLogsByRowIdPagination(AuditLogsByRowIdRequestDto dto, CancellationToken cancellationToken);

        Task<BVGResponse<PaginationResponseDto>> GetAuditLogsByUserPagination(AuditLogsByUserRequestDto dto, CancellationToken cancellationToken);
    }
}
