﻿using BVG.Domain.DTOs;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.Paginator
{
    public class PaginatorService : IPaginatorService
    {
        public async Task<PaginatorResponseDto<T>> PaginateAsync<T>(IQueryable<T> query, int PageNumber, int PageSize)
        {
            var totalCount = await query.CountAsync();
            query = query
                .Skip((PageNumber -1) * PageSize)
                .Take(PageSize);

            return new PaginatorResponseDto<T>
            {
                Query = query,
                TotalCount = totalCount
            };
        }
    }
}
