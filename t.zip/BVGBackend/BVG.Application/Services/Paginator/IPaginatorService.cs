﻿using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.Paginator
{
    public interface IPaginatorService
    {
        Task<PaginatorResponseDto<T>> PaginateAsync<T>(IQueryable<T> query, int PageNumber, int PageSize);
    }
}
