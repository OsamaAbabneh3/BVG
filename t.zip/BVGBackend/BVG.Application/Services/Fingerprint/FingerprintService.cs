﻿using BVG.Application.Common;
using BVG.Application.Services.Paginator;
using BVG.Application.Services.UnitOfWork;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace BVG.Application.Services
{
    public class FingerprintService : IFingerprintService
    {
        private readonly ILogger<FingerprintService> _logger;
        private readonly IUnitOfWorkService _unitOfWorkService;
        private readonly IAuditLogService _auditLogService;
        private readonly IStringLocalizer<Messages> _localizer;
        private readonly ISnapshotBulkRepository _snapshotBulkRepository;
        private  readonly IFingerprintRepository _fingerprintRepository;
        private readonly IPaginatorService _paginatorService;
        public FingerprintService(
            ILogger<FingerprintService> logger,
            IUnitOfWorkService unitOfWorkService,
            IAuditLogService auditLogService,
            IStringLocalizer<Messages> localizer,
            ISnapshotBulkRepository snapshotBulkRepository,
            IFingerprintRepository fingerprintRepository,
            IPaginatorService paginatorService
            )
        {
            _logger = logger;
            _unitOfWorkService = unitOfWorkService;
            _auditLogService = auditLogService;
            _localizer = localizer;
            _snapshotBulkRepository = snapshotBulkRepository;
            _fingerprintRepository = fingerprintRepository;
            _paginatorService = paginatorService;
        }
        public async Task<BVGResponse<object>> AddFingerprint(AddFingerprintDto dto, CancellationToken cancellationToken)
        {
            var fingerprint = await _snapshotBulkRepository.GetByIdSnapshotBulk(dto.SnapshotBulkId, cancellationToken);
            if (fingerprint == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.FingerprintNotFound);
            }
            var finger = new Fingerprint
            {
                SnapshotBulkId = dto.SnapshotBulkId,
                RowCount = dto.RowCount,
                CreatedAt = DateTime.UtcNow,
              
            };
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _fingerprintRepository.AddFingerprint(finger, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.AddFingerprint, EntityTypeEnum.Fingerprint, fingerprint.Id.ToString(), cancellationToken);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }
            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }
        public async Task<BVGResponse<PaginationResponseDto>> GetAllFingerprint(DynamicPaginationDto dto, CancellationToken cancellationToken)
        {
            var query = _fingerprintRepository.Query(dto.FilterOptions);
            bool columnExists = typeof(Fingerprint).GetProperties().Any(p => p.Name.Equals(dto.OrderBy));
            if (!columnExists)
            {
                return BVGResponse<PaginationResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidColumnNameInOrderBy);
            }

            bool isDescending = dto.OrderDirection == OrderDirectionEnum.DESC;
            query = query.OrderByProperty(dto.OrderBy, isDescending);
            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);
            var data = await result.Query
                .Select(x => new FingerprintDto
                {
                    Id = x.Id,
                    SnapshotBulkId = x.SnapshotBulkId,
                    RowCount = x.RowCount,
                    CreatedAt = x.CreatedAt,
                    UpdatedAt = x.UpdatedAt
                })
                .ToListAsync();
            var paginationResponse = new PaginationResponseDto
            {
                Data = data,
                PageNumber = dto.PageNumber,
                PageSize = dto.PageSize,
                TotalCount = result.TotalCount
            };
            return BVGResponse<PaginationResponseDto>.Success(paginationResponse,
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }
        public async Task<BVGResponse<FingerprintDto>> GetByIdFingerprint(long id, CancellationToken cancellationToken)
        {
            var fingerprint = await _fingerprintRepository.GetByIdFingerprint(id, cancellationToken);
            if (fingerprint == null)
            {
                return BVGResponse<FingerprintDto>.Fail(BVGStatusCode.NotFound, BVGErrorCode.FingerprintNotFound);
            }
            var fingerprintDto = new FingerprintDto
            {
                Id = fingerprint.Id,
                SnapshotBulkId = fingerprint.SnapshotBulkId,
                RowCount = fingerprint.RowCount,
                CreatedAt = fingerprint.CreatedAt,
                UpdatedAt = fingerprint.UpdatedAt
            };
            return BVGResponse<FingerprintDto>.Success(fingerprintDto, BVGMessage.ReturnSuccessfully, BVGStatusCode.Ok);
        }
        public async Task<BVGResponse<object>> UpdateFingerprint(UpdateFingerprintDto dto, CancellationToken cancellationToken)
        {
            var fingerprint = await _fingerprintRepository.GetByIdFingerprint(dto.Id, cancellationToken);
            if (fingerprint == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.FingerprintNotFound);
            }
            fingerprint.SnapshotBulkId = dto.SnapshotBulkId;
            fingerprint.RowCount = dto.RowCount;
            fingerprint.UpdatedAt = DateTime.UtcNow;
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _fingerprintRepository.UpdateFingerprint(fingerprint, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.UpdateFingerprint, EntityTypeEnum.Fingerprint, fingerprint.Id.ToString(), cancellationToken);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }
            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }
    }
}
