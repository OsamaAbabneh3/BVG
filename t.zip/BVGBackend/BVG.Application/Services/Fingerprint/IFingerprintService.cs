﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public interface IFingerprintService
    {
        Task<BVGResponse<object>> AddFingerprint(AddFingerprintDto dto, CancellationToken cancellationToken);
        Task<BVGResponse<PaginationResponseDto>> GetAllFingerprint(DynamicPaginationDto dto, CancellationToken cancellationToken);
        Task<BVGResponse<FingerprintDto>> GetByIdFingerprint(long id, CancellationToken cancellationToken);
        Task<BVGResponse<object>> UpdateFingerprint(UpdateFingerprintDto updateFingerprintDto, CancellationToken cancellationToken);
    }
}
