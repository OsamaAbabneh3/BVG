﻿using BVG.Application.Common;
using BVG.Domain.DTOs;

namespace BVG.Application.Services.RoleService
{
    public interface IRoleService
    {
        Task<BVGResponse<CreateRoleResponseDto>> CreateRole(CreateRoleDto dto, CancellationToken cancellationToken);

        Task<BVGResponse<PaginationResponseDto>> GetAllRoles(DynamicPaginationDto dto, CancellationToken cancellationToken);

        Task<BVGResponse<object>> AssignPermissionsToRole(AssignPermissionsToRoleDto dto, CancellationToken cancellationToken);

        Task<BVGResponse<object>> DeleteRole(Guid id, CancellationToken cancellationToken);

        Task<BVGResponse<object>> UpdateDescription(ModifyDescriptionDto dto, CancellationToken cancellationToken);
    }
}
