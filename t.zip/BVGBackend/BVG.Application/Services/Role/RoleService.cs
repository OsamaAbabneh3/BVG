﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using BVG.Application.Exceptions;
using BVG.Application.Services.Paginator;
using BVG.Application.Services.UnitOfWork;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using CommonResources.GeneralClasses;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System.Data;

namespace BVG.Application.Services.RoleService
{
    public class RoleService : IRoleService
    {
        private readonly IRoleRepository _roleRepository;
        private readonly RequestHeadersModel _headers;
        private readonly IPaginatorService _paginatorService;
        private readonly IStringLocalizer<Messages> _localizer;
        private readonly ILogger<RoleService> _logger;
        private readonly IUnitOfWorkService _unitOfWorkService;
        private readonly IPermissionRepository _permissionRepository;
        private readonly IAuditLogService _auditLogService;

        public RoleService(
            IRoleRepository roleRepository,
            RequestHeadersModel headers,
            IPaginatorService paginatorService,
            IAuditLogService auditLogService,
            IStringLocalizer<Messages> localizer,
            ILogger<RoleService> logger,
            IUnitOfWorkService unitOfWorkService,
            IPermissionRepository permissionRepository)
        {
            _roleRepository = roleRepository;
            _headers = headers;
            _paginatorService = paginatorService;
            _localizer = localizer;
            _logger = logger;
            _unitOfWorkService = unitOfWorkService;
            _permissionRepository = permissionRepository;
            _auditLogService = auditLogService;
        }

        public async Task<BVGResponse<CreateRoleResponseDto>> CreateRole(CreateRoleDto dto, CancellationToken cancellationToken)
        {
            var roles = await _roleRepository.Where(r => r.RoleName == dto.NameEn.Trim() || r.NameAr == dto.NameAr.Trim(), cancellationToken);
            if (roles.Any())
            {
                return BVGResponse<CreateRoleResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.RoleAlreadyExists);
            }

            if (dto.PermissionIds.Count == 0)
            {
                return BVGResponse<CreateRoleResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.PermissionsRequired);
            }

            var count = await _permissionRepository.CountAsync(dto.PermissionIds, cancellationToken);
            if (count != dto.PermissionIds.Count) 
            { 
                return BVGResponse<CreateRoleResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidPermissionId);
            }
            

            var role = new Role
            {
                Id = Guid.NewGuid(),
                RoleName = dto.NameEn.ToUpper().Trim(),
                NameAr = dto.NameAr.ToUpper().Trim(),
                Description = dto.Description?.Trim(),
                CreatedAt = DateTime.UtcNow,
            };

            var rolePermissions = new List<RolePermission>();
            foreach (var permissionId in dto.PermissionIds)
            {
                rolePermissions.Add(new RolePermission
                {
                    RoleId = role.Id,
                    PermissionId = permissionId,
                    AssignedAt = DateTime.UtcNow,
                });
            }

            role.RolePermissions = rolePermissions;

            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _roleRepository.AddAsync(role, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.CreateRole, EntityTypeEnum.Role, role.Id.ToString(), cancellationToken, role.RoleName);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }

            return BVGResponse<CreateRoleResponseDto>.Success(
                 new CreateRoleResponseDto
                 {
                     Id = role.Id,
                     Name = role.RoleName,
                     Description = role.Description,
                     CreatedAt = role.CreatedAt,
                     UpdatedAt = role.UpdatedAt,
                 },
                 BVGMessage.ExecuteSuccessfully,
                 BVGStatusCode.Ok);
        }

        public async Task<BVGResponse<PaginationResponseDto>> GetAllRoles(DynamicPaginationDto dto, CancellationToken cancellationToken)
        {
            var query = _roleRepository.Query(dto.FilterOptions);

            bool columnExists = typeof(Role).GetProperties().Any(p => p.Name.Equals(dto.OrderBy, StringComparison.OrdinalIgnoreCase));

            if (!columnExists)
            {
                return BVGResponse<PaginationResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidColumnNameInOrderBy);
            }

            bool isDescending = dto.OrderDirection == OrderDirectionEnum.DESC;
            query = query.OrderByProperty(dto.OrderBy, isDescending);

            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);

            var data = await result.Query
                .Select(x => new GetAllRolesResponseDto
                {
                    Id = x.Id,
                    NameEn = x.RoleName,
                    NameAr = x.NameAr,
                    Description = x.Description,
                    Permissions = x.RolePermissions.Select(rp => rp.Permission == null ? new() : new PermissionDto
                    {
                        Id = rp.Permission.Id,
                        NameEn = rp.Permission.PermissionName,
                        NameAr = rp.Permission.NameAr

                    }).ToList()
                }).ToListAsync();

            return BVGResponse<PaginationResponseDto>.Success(
                new PaginationResponseDto
                {
                    Data = data,
                    PageNumber = dto.PageNumber,
                    PageSize = dto.PageSize,
                    TotalCount = result.TotalCount
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }
    
        public async Task<BVGResponse<object>> AssignPermissionsToRole(AssignPermissionsToRoleDto dto, CancellationToken cancellationToken)
        {
            var role = await _roleRepository.GetByIdWithRolePermissions(dto.RoleId, cancellationToken);

            if (role == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.RoleNotFound);
            }

            if (role.RoleName.Equals(RoleEnum.Admin.ToString(), StringComparison.OrdinalIgnoreCase))
            {
                return BVGResponse<object>.Fail(BVGStatusCode.Forbidden, BVGErrorCode.ThisRoleCannotBeReassigned);
            }

            var count = await _permissionRepository.CountAsync(dto.PermissionIds, cancellationToken);

            if (count != dto.PermissionIds.Count)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidPermissionId);
            }

            var currentPermissionIds = role.RolePermissions.Select(rp => rp.PermissionId).ToList();

            var rolePermissionsToRemove = role.RolePermissions.Where(rp => rp.PermissionId != null && !dto.PermissionIds.Contains(rp.PermissionId.Value)).ToList();

            await _roleRepository.RemoveRangeOfRolePermissions(rolePermissionsToRemove, cancellationToken);

            foreach (var permissionId in dto.PermissionIds)
            {
                if (!currentPermissionIds.Contains(permissionId))
                {
                    role.RolePermissions.Add(new RolePermission
                    {
                        RoleId = role.Id, 
                        PermissionId = permissionId,
                        AssignedAt = DateTime.UtcNow,
                    });
                }
            }

            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.AssignPermissionsToRole, EntityTypeEnum.Role, role.Id.ToString(), cancellationToken, role.RoleName);
                await _roleRepository.UpdateAsync(role, cancellationToken);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex) 
            {
                _logger.LogError(ex.Message);
                await _unitOfWorkService.RollbackAsync();
                throw;
            }

            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }
    
        public async Task<BVGResponse<object>> DeleteRole(Guid id, CancellationToken cancellationToken)
        {
            var role = await _roleRepository.GetByIdWithRelationsAsync(id, cancellationToken);

            if (role == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.RoleNotFound);
            }

            if (role.UserRoles.Any())
            {
                return BVGResponse<object>.Fail(BVGStatusCode.Conflict, BVGErrorCode.RoleHasAssignedUsers);
            }

            if (role.RoleName.Equals(RoleEnum.Admin.ToString(), StringComparison.OrdinalIgnoreCase))
            {
                return BVGResponse<object>.Fail(BVGStatusCode.Forbidden, BVGErrorCode.CannotDeleteThisRole);
            }

            
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _roleRepository.DeleteRoleAsync(role, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.DeleteRole, EntityTypeEnum.Role, role.Id.ToString(), cancellationToken, role.RoleName);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex) 
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }

            return BVGResponse<object>.Success(null,BVGMessage.DeletedSuccessfully, BVGStatusCode.Ok);
        }
    
        public async Task<BVGResponse<object>> UpdateDescription(ModifyDescriptionDto dto, CancellationToken cancellationToken)
        {
            var role = await _roleRepository.GetById(dto.Id, cancellationToken);
            if (role == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.RoleNotFound);
            }

            role.Description = dto.Description;
            await _roleRepository.UpdateAsync(role, cancellationToken);
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _roleRepository.UpdateAsync(role, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.UpdateDescription, EntityTypeEnum.Role, role.Id.ToString(), cancellationToken, role.RoleName);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }

            return BVGResponse<object>.Success(null, BVGMessage.UpdatedSuccessfully, BVGStatusCode.Ok);
        }
    }
}
