﻿using BVG.Application.Common;
using BVG.Application.Services.Paginator;
using BVG.Application.Services.UnitOfWork;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace BVG.Application.Services
{
    public class RuleFamilyService : IRuleFamilyService
    {
        private readonly IRuleFamilyRepository _ruleFamilyRepository;
        private readonly IPaginatorService _paginatorService;
        private readonly ILogger<RuleFamilyService> _logger;
        private readonly IStringLocalizer<Messages> _localizer;
        private readonly IAuditLogService _auditLogService;
        private readonly IUnitOfWorkService _unitOfWorkService;

        public RuleFamilyService(
            IRuleFamilyRepository ruleFamilyRepository,
            IPaginatorService paginatorService,
            IAuditLogService auditLogService,
             ILogger<RuleFamilyService> logger,
            IUnitOfWorkService unitOfWorkService,
            IStringLocalizer<Messages> localizer


            )
        {
            _ruleFamilyRepository = ruleFamilyRepository;
            _paginatorService = paginatorService;
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
            _localizer = localizer;
            _auditLogService = auditLogService;
        }
        public async Task<BVGResponse<PaginationResponseDto>> GetAllRuleFamily(DynamicPaginationDto dto, CancellationToken cancellationToken)
        {
            var query = _ruleFamilyRepository.Query(dto.FilterOptions);

            bool columnExists = typeof(RuleFamily).GetProperties().Any(p => p.Name.Equals(dto.OrderBy, StringComparison.OrdinalIgnoreCase));

            if (!columnExists)
            {
                return BVGResponse<PaginationResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidColumnNameInOrderBy);
            }

            bool isDescending = dto.OrderDirection == OrderDirectionEnum.DESC;
            query = query.OrderByProperty(dto.OrderBy, isDescending);

            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);

            var data = await result.Query
                .Select(r => new GetRuleFamilyDto
                {
                    Id = r.Id,
                    FamilyName = r.FamilyName,
                    CreatedAt = r.CreatedAt,
                    UpdatedAt = r.UpdatedAt,
                    RuleFamilyCode = r.RuleFamilyCode

                }).ToListAsync();

            return BVGResponse<PaginationResponseDto>.Success(
                new PaginationResponseDto
                {
                    Data = data,
                    PageNumber = dto.PageNumber,
                    PageSize = dto.PageSize,
                    TotalCount = result.TotalCount
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }
        public async Task<BVGResponse<GetRuleFamilyDto>> GetByIdRuleFamily(long id, CancellationToken cancellationToken)
        {
            var r = await _ruleFamilyRepository.getByIdRuleFamily(id, cancellationToken);
            if (r == null)
                return BVGResponse<GetRuleFamilyDto>.Fail(BVGStatusCode.NotFound, BVGErrorCode.RuleFamilyNotFound);
            //exception
            return BVGResponse<GetRuleFamilyDto>.Success(new GetRuleFamilyDto
            {
                Id = r.Id,
                FamilyName = r.FamilyName,
                CreatedAt = r.CreatedAt,
                UpdatedAt = r.UpdatedAt,
                RuleFamilyCode= r.RuleFamilyCode

            }, BVGMessage.ReturnSuccessfully, BVGStatusCode.Ok
            );
            

        }
        public async Task<BVGResponse<object>> CreateRuleFamily(CreateRuleFamilyDto createRuleFamilyDto, CancellationToken cancellationToken)
        {
            var isValidRuleNameAsync = await _ruleFamilyRepository.IsValidRuleNameAsync(createRuleFamilyDto.FamilyName, cancellationToken);
            if (isValidRuleNameAsync)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.RuleFamilyNameAlreadyExists);
            }
            var isValidRuleCodeAsync=await _ruleFamilyRepository.IsValidRuleCodeAsync(createRuleFamilyDto.RuleFamilyCode, cancellationToken);
            if (isValidRuleCodeAsync)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.BadRequest,BVGErrorCode.RuleFamilyCodeAlreadyExists);
            }
            
            var rule = new RuleFamily
            {
                FamilyName = createRuleFamilyDto.FamilyName,              
                CreatedAt =  DateTime.UtcNow,
                RuleFamilyCode= createRuleFamilyDto.RuleFamilyCode,
            };
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _ruleFamilyRepository.CreateRuleFamily(rule, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.CreateRuleFamily, EntityTypeEnum.RuleFamily, rule.Id.ToString(),cancellationToken, rule.FamilyName);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }

            
            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }
        public async Task<BVGResponse<UpdateRuleFamilyDto>> UpdateRuleFamily(UpdateRuleFamilyDto updateDto, CancellationToken cancellationToken)
        {

            var existingRule = await _ruleFamilyRepository.getByIdRuleFamily(updateDto.Id, cancellationToken);
            if (existingRule == null)
            {
                return BVGResponse<UpdateRuleFamilyDto>.Fail(BVGStatusCode.NotFound, BVGErrorCode.RuleFamilyNotFound);
            }
            if (existingRule.FamilyName.ToLower() != updateDto.FamilyName.ToLower())
            {
                var isValidRuleNameAsync = await _ruleFamilyRepository.IsValidRuleNameAsync(updateDto.FamilyName, cancellationToken);
                if (isValidRuleNameAsync)
                {
                    return BVGResponse<UpdateRuleFamilyDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.RuleFamilyNameAlreadyExists);
                }
            }
            if (existingRule.RuleFamilyCode.ToLower() != updateDto.RuleFamilyCode.ToLower()) 
            {
                var isValidRuleCodeAsync = await _ruleFamilyRepository.IsValidRuleCodeAsync(updateDto.RuleFamilyCode, cancellationToken);
                if (isValidRuleCodeAsync)
                {
                    return BVGResponse<UpdateRuleFamilyDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.RuleFamilyCodeAlreadyExists);
                }

            }
            
            existingRule.FamilyName = updateDto.FamilyName;
            existingRule.UpdatedAt = DateTime.UtcNow;
            existingRule.RuleFamilyCode = updateDto.RuleFamilyCode;
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _ruleFamilyRepository.UpdateRuleFamily(existingRule, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.UpdateRuleFamily, EntityTypeEnum.RuleFamily, existingRule.Id.ToString(), cancellationToken, existingRule.FamilyName);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }
           

            return BVGResponse<UpdateRuleFamilyDto>.Success(
                new UpdateRuleFamilyDto
                {
                    Id = existingRule.Id,
                    FamilyName = existingRule.FamilyName,
                    RuleFamilyCode = existingRule.RuleFamilyCode,
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }
        public async Task<BVGResponse<DeleteRuleFamilyDto>> DeleteRuleFamily(DeleteRuleFamilyDto deleteDto, CancellationToken cancellationToken)
        {
            var ruleFamily = await _ruleFamilyRepository.getByIdRuleFamily(deleteDto.Id, cancellationToken);
            if (ruleFamily == null)
            {
                return BVGResponse<DeleteRuleFamilyDto>.Fail(BVGStatusCode.NotFound, BVGErrorCode.RuleFamilyNotFound);
            }
            bool hasRelatedCatalogs = await _ruleFamilyRepository.IsRuleFamilyLinkedToRuleCatalog(deleteDto.Id, cancellationToken);
            if (hasRelatedCatalogs)
            {
                return BVGResponse<DeleteRuleFamilyDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.RuleFamilyIsRegisteredOrInUse);
            }

            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _ruleFamilyRepository.DeleteRuleFamily(deleteDto.Id, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.DeleteRuleFamily, EntityTypeEnum.RuleFamily, deleteDto.Id.ToString(), cancellationToken);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }

            return BVGResponse<DeleteRuleFamilyDto>.Success(
                new DeleteRuleFamilyDto { Id = deleteDto.Id }, BVGMessage.DeletedSuccessfully, BVGStatusCode.Ok
            );
        }

        public async Task<BVGResponse<object>> GetLastCodeRuleFamily(long id, CancellationToken cancellationToken)
        {

            var existingRule = await _ruleFamilyRepository.getByIdRuleFamily(id, cancellationToken);
            if (existingRule == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.RuleFamilyNotFound);
            }
            var ruleFamily = await _ruleFamilyRepository.GetCodyByruleFamilyId(id, cancellationToken);

            int lastCode = 0;

            if (!string.IsNullOrWhiteSpace(ruleFamily))
            {
                if (!int.TryParse(ruleFamily, out lastCode))
                {
                    return BVGResponse<object>.Fail(BVGStatusCode.BadRequest,BVGErrorCode.InvalidRuleFamilyCode);
                }
            }
            var nextCode = lastCode + 1;

            string code = nextCode.ToString("D2");

            return BVGResponse<object>.Success(
                new { RuleCode = code },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }
    }
}
