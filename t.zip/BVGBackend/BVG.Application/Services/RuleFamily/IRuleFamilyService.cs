﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public interface IRuleFamilyService
    {
        Task<BVGResponse<PaginationResponseDto>> GetAllRuleFamily(DynamicPaginationDto dto, CancellationToken cancellationToken);
        Task<BVGResponse<GetRuleFamilyDto>> GetByIdRuleFamily(long id, CancellationToken cancellationToken);
        Task<BVGResponse<object>> CreateRuleFamily(CreateRuleFamilyDto createRuleFamilyDto, CancellationToken cancellationToken);
        Task<BVGResponse<UpdateRuleFamilyDto>> UpdateRuleFamily(UpdateRuleFamilyDto updateDto, CancellationToken cancellationToken);
        Task<BVGResponse<DeleteRuleFamilyDto>> DeleteRuleFamily(DeleteRuleFamilyDto deleteDto, CancellationToken cancellationToken);
        Task<BVGResponse<object>> GetLastCodeRuleFamily(long id, CancellationToken cancellationToken);
    }
}
