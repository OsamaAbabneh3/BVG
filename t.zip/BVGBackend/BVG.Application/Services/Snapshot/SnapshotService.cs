﻿using BVG.Application.Common;
using BVG.Application.Configuration;
using BVG.Application.Services.HealthCheck;
using BVG.Application.Services.UnitOfWork;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore.ChangeTracking.Internal;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Transactions;

namespace BVG.Application.Services.Snapshot
{
    public class SnapshotService : ISnapshotService
    {
        private readonly ICycleInfoRepository _cycleInfoRepository;
        private readonly ISnapshotBulkRepository _snapshotBulkRepository;
        private readonly IUnitOfWorkService _unitOfWorkService;
        private readonly ILogger<SnapshotService> _logger;
        private readonly ISnapshotRepository _snapshotRepository;
        private readonly SnapshotOptions _options;
        private readonly IServiceScopeFactory _serviceScopeFactory;
        private readonly INotificationRepository _notification;
        private readonly IInvoiceExceptionRepository _invoiceExceptionRepository;
        private readonly IRuleCatalogRepository _ruleCatalogRepository;
        private readonly IRuleModeHistoryRepository _ruleModeHistoryRepository;
        private readonly IGeneralRepository _generalRepository;
        private readonly IFingerprintRepository _fingerprintRepository;
        private readonly DynamicPull _dynamicPullOptions;
        private readonly IHealthCkeckService _healthCheckService;

        public SnapshotService(
            ICycleInfoRepository cycleInfoRepository,
            ISnapshotBulkRepository snapshotBulkRepository,
            IUnitOfWorkService unitOfWorkService,
            ILogger<SnapshotService> logger,
            ISnapshotRepository snapshotRepository,
            IOptions<SnapshotOptions> options,
            IServiceScopeFactory serviceScopeFactory,
            INotificationRepository notification,
            IInvoiceExceptionRepository invoiceExceptionRepository,
            IRuleCatalogRepository ruleCatalogRepository,
            IRuleModeHistoryRepository ruleModeHistoryRepository,
            IGeneralRepository generalRepository,
            IFingerprintRepository fingerprintRepository,
            IOptions<DynamicPull> dynamicPullOptions,
            IHealthCkeckService healthCheckService)
        {
            _cycleInfoRepository = cycleInfoRepository;
            _snapshotBulkRepository = snapshotBulkRepository;
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
            _snapshotRepository = snapshotRepository;
            _options = options.Value;
            _serviceScopeFactory = serviceScopeFactory;
            _notification = notification;
            _invoiceExceptionRepository = invoiceExceptionRepository;
            _ruleCatalogRepository = ruleCatalogRepository;
            _ruleModeHistoryRepository = ruleModeHistoryRepository;
            _generalRepository = generalRepository;
            _fingerprintRepository = fingerprintRepository;
            _dynamicPullOptions = dynamicPullOptions.Value;
            _healthCheckService = healthCheckService;
        }

        public async Task<BVGResponse<object>> TakeSnapshot(CancellationToken cancellationToken)
        {
            var healthCheck = await _healthCheckService.HealthCheck();
            if (healthCheck.Data == null||
                healthCheck.Data.BvgConnection == false ||
                healthCheck.Data.SnapshotConnection == false ||
                healthCheck.Data.OracleConnection == false)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.Unavailable, BVGErrorCode.DatabaseConnectionFailed);
            }

            var cycleRecord = await _snapshotRepository.TakeActiveCycle();
            if (cycleRecord == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.FaildActiveCycle);
            }

            if (cycleRecord.CycleYM.ToString().Length != 6)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.FaildActiveCycle);
            }

            int year = 0;
            int month = 0;
            if (_dynamicPullOptions.Enable == true)
            {
                year = int.Parse(cycleRecord.CycleYM.ToString().Substring(0, 4));
                month = int.Parse(cycleRecord.CycleYM.ToString().Substring(4, 2));
            }
            else
            {
                year = _dynamicPullOptions.Year;
                month = _dynamicPullOptions.Month;
            }

            var anyPullInProgress = await _snapshotBulkRepository.AnyAsync(bulk =>
                bulk.PullStatus == (byte)PullStatusEnum.Pending ||
                bulk.PullStatus == (byte)PullStatusEnum.Processing);

            if (anyPullInProgress)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.Conflict, BVGErrorCode.AnotherPullInProgress);
            }

            var anyPullRequiredVerification = await _snapshotBulkRepository.AnyAsync(bulk =>
                bulk.CheckStatus == (byte)CheckStatusEnum.Pending &&
                bulk.PullStatus == (byte)PullStatusEnum.Completed);
            
            if (anyPullRequiredVerification)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.Conflict, BVGErrorCode.VerificationRequired);
            }

            var anyPullVerificationInProgress = await _snapshotBulkRepository.AnyAsync(bulk =>
                bulk.CheckStatus == (byte)CheckStatusEnum.Processing &&
                bulk.PullStatus == (byte)PullStatusEnum.Completed);

            if (anyPullVerificationInProgress)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.Conflict, BVGErrorCode.VerificationInProgress);
            }

            var cycle = await _cycleInfoRepository.GetFirstOrDefaultAsync(c => c.CycleDate.Year == year && c.CycleDate.Month == month);
            var isNewCycle = false;

            try
            {
                await _unitOfWorkService.BeginTransactionAsync();

                if (cycle == null)
                {
                    await ExecuteRuleModeHistory(cancellationToken);
                    cycle = new CycleInfo
                    {
                        CycleDate = new DateOnly(year, month, 1),
                        StartDate = DateTime.UtcNow,
                        EndDate = null,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = null
                    };
                    await _cycleInfoRepository.AddCycleInfo(cycle, cancellationToken);
                    isNewCycle = true;
                }

                var maxSequence = await _snapshotBulkRepository.GetMaxSequence(cycle.Id);
                var bulk = new SnapshotBulk
                {
                    CycleId = cycle.Id,
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = null,
                    CheckStatus = (byte)CheckStatusEnum.Pending,
                    ReferenceOk = null,
                    ReferenceReason = null,
                    Status = null,
                    PullStatus = (byte)PullStatusEnum.Pending,
                    AttemptCount = 0,
                    Sequence = ++maxSequence
                };

                await _snapshotBulkRepository.AddSnapshotBulk(bulk, cancellationToken);
                var cycleYM = $"{year}{month:D2}";

                _ = Task.Run(() => TakeSnapshotAsync(bulk.Id, cycleYM, isNewCycle, cycle.CycleDate), CancellationToken.None);

                await _unitOfWorkService.CommitAsync();

                return BVGResponse<object>.Success(null, BVGMessage.ProcessInProgress, BVGStatusCode.Accepted);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                await _unitOfWorkService.RollbackAsync();
                throw;
            }
        }

        private async Task TakeSnapshotAsync(long bulkId, string cycleYM, bool isNewCycle, DateOnly cycleDate)
        {
            using var scope = _serviceScopeFactory.CreateScope();
            var snapshotBulkRepo = scope.ServiceProvider.GetRequiredService<ISnapshotBulkRepository>();
            var snapshotRepository = scope.ServiceProvider.GetRequiredService<ISnapshotRepository>();
            var fingerprintRepository = scope.ServiceProvider.GetRequiredService<IFingerprintRepository>();
            var generalRepository = scope.ServiceProvider.GetRequiredService<IGeneralRepository>();

            var bulk = await snapshotBulkRepo.GetByIdSnapshotBulk(bulkId, CancellationToken.None);
            if (bulk == null) return;

            _ = Task.Run(() => SendUpdatesAsync(bulkId));

            for (int attempt = 1; attempt <= _options.MaxRetryAttempts; attempt++)
            {
                try
                {
                    bulk.PullStatus = (byte)PullStatusEnum.Processing;
                    bulk.AttemptCount = attempt;
                    bulk.UpdatedAt = DateTime.UtcNow;
                    bulk.ErrorMessage = null;
                    await snapshotBulkRepo.UpdateAsync(bulk, CancellationToken.None);

                    if (isNewCycle)
                    {
                        await generalRepository.ClearAllTablesAsync(CancellationToken.None);
                        await snapshotRepository.TakeReferencesSnapshotAsync(cycleDate);
                        await snapshotRepository.TakePricesSnapshotAsync(cycleDate);
                    }

                    var result = await snapshotRepository.TakeSnapshotAsync(cycleYM, bulk.Id);
                    if (result != null)
                    {
                        await fingerprintRepository.AddFingerprint(new Fingerprint
                        {
                            SnapshotBulkId = bulkId,
                            RowCount = (int)result.FullSnapshot,
                            CreatedAt = DateTime.UtcNow,
                            UpdatedAt = null,
                            FingerprintOk = null
                        }, CancellationToken.None);
                    }
                    bulk.PullStatus = (byte)PullStatusEnum.Completed;
                    bulk.UpdatedAt = DateTime.UtcNow;
                    bulk.ErrorMessage = null;
                    await snapshotBulkRepo.UpdateAsync(bulk, CancellationToken.None);
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Snapshot failed for BillingCycle {BillingCycle}. Attempt {Attempt}", cycleYM, attempt);

                    bulk.ErrorMessage = ex.Message;
                    bulk.UpdatedAt = DateTime.UtcNow;
                    bulk.PullStatus = attempt >= _options.MaxRetryAttempts
                        ? (byte)PullStatusEnum.Failed
                        : (byte)PullStatusEnum.Pending;
                    await _generalRepository.ClearByBulkAsync(bulkId, CancellationToken.None);
                    await snapshotBulkRepo.UpdateAsync(bulk, CancellationToken.None);

                    if (attempt < _options.MaxRetryAttempts)
                    {
                        await Task.Delay(TimeSpan.FromSeconds(_options.RetryDelaySeconds));
                    }
                }
            }
        }

        private async Task SendUpdatesAsync(long bulkId)
        {
            byte currentStatus = (byte)PullStatusEnum.Pending;

            while (currentStatus != (byte)PullStatusEnum.Completed && currentStatus != (byte)PullStatusEnum.Failed)
            {
                await _notification.SendToAllAsync<string>(EventNotifications.PullingData.ToString(), "InProgress");
                await Task.Delay(TimeSpan.FromSeconds(10));

                using var scope = _serviceScopeFactory.CreateScope();
                var snapshotBulkRepo = scope.ServiceProvider.GetRequiredService<ISnapshotBulkRepository>();

                var bulk = await snapshotBulkRepo.GetByIdSnapshotBulk(bulkId, CancellationToken.None);
                if (bulk == null) break;

                currentStatus = bulk.PullStatus;
            }

            var finalMessage = currentStatus == (byte)PullStatusEnum.Failed ? "Failed" : "Completed";
            await _notification.SendToAllAsync<string>(EventNotifications.PullingData.ToString(), finalMessage);
        }

        private async Task ExecuteRuleModeHistory(CancellationToken cancellationToken)
        {
            var activeCycle = await _cycleInfoRepository.GetFirstOrDefaultAsync(cycle => cycle.EndDate == null);
            if (activeCycle != null)
            {
                activeCycle.EndDate = DateTime.UtcNow;
                await _cycleInfoRepository.UpdateCycleInfo(activeCycle, cancellationToken);
                var bulkIds = activeCycle.SnapshotBulks.Select(bulk => bulk.Id).ToList();
                var invoiceExceptions = await _invoiceExceptionRepository.WhereAsync(ex => ex.SnapshotBulkId.HasValue && bulkIds.Contains(ex.SnapshotBulkId.Value));
                var groups = invoiceExceptions.GroupBy(ex => ex.RuleId);
                var totalCount = (await _fingerprintRepository
                    .WhereAsync(finger => finger.SnapshotBulkId.HasValue && bulkIds.Contains(finger.SnapshotBulkId.Value)))
                    .Sum(finger => finger.RowCount);
                foreach (var group in groups)
                {
                    var rule = await _ruleCatalogRepository.GetByIdAsync(group.Key!.Value);
                    if (rule != null)
                    {
                        var exceededAlertBudget = (group.Count() / totalCount) > rule.AlertBudget;
                        var lastRuleModeHistory = await _ruleModeHistoryRepository.LastRuleModeHistory(rule.Id);
                        var currentModeHistory = await _ruleModeHistoryRepository.AddRuleModeHistory(new RuleModeHistory
                        {
                            RuleId = rule.Id,
                            CycleId = activeCycle.Id,
                            Mode = rule.Mode,
                            ExceededAlertCount = exceededAlertBudget ? group.Count() : 0,
                            CreatedAt = DateTime.UtcNow
                        }, cancellationToken);

                        if (lastRuleModeHistory != null)
                        {
                            if (lastRuleModeHistory.ExceededAlertCount == 0 &&
                                currentModeHistory.ExceededAlertCount == 0 &&
                                currentModeHistory.Mode == (byte)ModeEnum.Monitor)
                            {
                                rule.Mode = (byte)ModeEnum.Enforce;
                                await _ruleCatalogRepository.UpdateRuleCatalog(rule, cancellationToken);
                            }

                            if (lastRuleModeHistory.ExceededAlertCount > 0 &&
                               currentModeHistory.ExceededAlertCount > 0 &&
                               currentModeHistory.Mode == (byte)ModeEnum.Enforce)
                            {
                                rule.Mode = (byte)ModeEnum.Monitor;
                                await _ruleCatalogRepository.UpdateRuleCatalog(rule, cancellationToken);
                            }
                        }
                    }
                }
            }
        }
    }
}
