﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.Snapshot
{
    public interface ISnapshotService
    {
        Task<BVGResponse<object>> TakeSnapshot(CancellationToken cancellationToken);
    }
}
