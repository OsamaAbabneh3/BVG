﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using Helper.EmailBody;
using System;
using System;
using System.Collections.Generic;
using System.Collections.Generic;
using System.Data.Common;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using A = DocumentFormat.OpenXml.Drawing;
using Xdr = DocumentFormat.OpenXml.Drawing.Spreadsheet;


namespace BVG.Application.Services
{
    public class ReportsService : IReportsService
    {
        private readonly IReportsRepository _reportsRepository;
        private readonly ICycleInfoRepository _cycleInfoRepository;
        public ReportsService(IReportsRepository reportsRepository, ICycleInfoRepository cycleInfoRepository)
        {
            _reportsRepository = reportsRepository;
            _cycleInfoRepository = cycleInfoRepository;
        }
        public async Task<BVGResponse<ExcelFileDto>> GetCycleSummaryAsync(CycleSummaryReportRequestDto dto,CancellationToken cancellationToken)
        {
            var cycle = await _cycleInfoRepository.GetByIdCycleInfo(dto.CycleId,cancellationToken);

            if (cycle == null)
            {
                return BVGResponse<ExcelFileDto>.Fail(BVGStatusCode.BadRequest,BVGErrorCode.CycleNotFound);
            }

            var rows = await _reportsRepository.GetCycleSummaryAsync(dto.CycleId,dto.SnapshotBulkId,cancellationToken);

            if (rows.Count == 0)
            {
                return BVGResponse<ExcelFileDto>.Fail(BVGStatusCode.BadRequest,dto.SnapshotBulkId.HasValue ? BVGErrorCode.SnapshotBulkNotFoundInCycle : BVGErrorCode.NoReportData);
            }

            return CreateCycleSummaryExcel(rows,cancellationToken);
        }

        private static BVGResponse<ExcelFileDto> CreateCycleSummaryExcel(
         List<CycleSummaryReportRowDto> rows,
         CancellationToken cancellationToken)
        {
             var logoBase64 = EmailBody.GetImage("bvg-logo.png");
            string idecoLogo = EmailBody.GetImage("ideco-mark.png");

            if (rows.Count == 0)
            {
                return BVGResponse<ExcelFileDto>.Fail(
                    BVGStatusCode.BadRequest,
                    BVGErrorCode.NoReportData);
            }

            if (!TryReadLogo(
                logoBase64,
                out var logoBytes,
                out var logoIsPng))
            {
                return BVGResponse<ExcelFileDto>.Fail(
                    BVGStatusCode.BadRequest,
                    BVGErrorCode.InvalidReportLogo);
            }

            cancellationToken.ThrowIfCancellationRequested();

            using var stream = new MemoryStream();

            using (var document = SpreadsheetDocument.Create(
                stream,
                SpreadsheetDocumentType.Workbook))
            {
                var workbookPart = document.AddWorkbookPart();
                workbookPart.Workbook = new Workbook();

                var stylesPart =
                    workbookPart.AddNewPart<WorkbookStylesPart>();

                stylesPart.Stylesheet = CreateReportStyles();
                stylesPart.Stylesheet.Save();

                var worksheetPart =
                    workbookPart.AddNewPart<WorksheetPart>();

                var sheetView = new SheetView
                {
                    WorkbookViewId = 0U,
                    RightToLeft = true,
                    ShowGridLines = false
                };

                sheetView.Append(new Pane
                {
                    VerticalSplit = 5D,
                    TopLeftCell = "A6",
                    ActivePane = PaneValues.BottomLeft,
                    State = PaneStateValues.Frozen
                });

                sheetView.Append(new Selection
                {
                    Pane = PaneValues.BottomLeft,
                    ActiveCell = "A6",
                    SequenceOfReferences =
                        new ListValue<StringValue>
                        {
                            InnerText = "A6"
                        }
                });

                var columns = CreateReportColumns();
                var sheetData = new SheetData();

               
                var titleRow = new Row
                {
                    RowIndex = 1U,
                    Height = 34D,
                    CustomHeight = true
                };

                titleRow.Append(ReportTextCell(
                    "A1",
                    "تقرير ملخّص نتائج الدورة والدفعات",
                    1U));

                sheetData.Append(titleRow);

                sheetData.Append(new Row
                {
                    RowIndex = 2U,
                    Height = 22D,
                    CustomHeight = true
                });

               
                var infoRow = new Row
                {
                    RowIndex = 3U,
                    Height = 25D,
                    CustomHeight = true
                };

                var cycleIdText = rows[0].CycleId.ToString(
                    CultureInfo.InvariantCulture);

                infoRow.Append(ReportTextCell(
                    "A3",
                    $"رقم الدورة: {cycleIdText} | " +
                    $"تاريخ الدورة: {rows[0].CycleDate}",
                    0U));

                sheetData.Append(infoRow);

                
                var generatedRow = new Row
                {
                    RowIndex = 4U,
                    Height = 24D,
                    CustomHeight = true
                };

                generatedRow.Append(ReportTextCell(
                    "A4",
                    "تاريخ استخراج التقرير (UTC): " +
                    DateTime.UtcNow.ToString(
                        "yyyy-MM-dd HH:mm",
                        CultureInfo.InvariantCulture),
                    0U));

                sheetData.Append(generatedRow);

                
                var headers = new[]
                {
                    "رقم الدورة",
                    "تاريخ الدورة",
                    "رقم الدفعة",
                    "تاريخ إنشاء الدفعة",
                    "عدد الفواتير",
                    "عدد الجاهز للنشر",
                    "عدد الحسابات عليها استثناءات",
                    "عدد الاستثناءات",
                    "عدد القواعد التي سجّلت استثناءات"
                };

                var headerRow = new Row
                {
                    RowIndex = 5U,
                    Height = 42D,
                    CustomHeight = true
                };

                for (var index = 0; index < headers.Length; index++)
                {
                    var column = ((char)('A' + index)).ToString();

                    headerRow.Append(ReportTextCell(
                        $"{column}5",
                        headers[index],
                        2U));
                }

                sheetData.Append(headerRow);

               
                uint rowIndex = 6U;

                foreach (var item in rows)
                {
                    cancellationToken.ThrowIfCancellationRequested();

                    var alternate = (rowIndex - 6U) % 2U == 1U;

                    uint textStyle = alternate ? 5U : 3U;
                    uint numberStyle = alternate ? 6U : 4U;

                    var row = new Row
                    {
                        RowIndex = rowIndex,
                        Height = 26D,
                        CustomHeight = true
                    };

                    row.Append(
                        ReportTextCell(
                            $"A{rowIndex}",
                            item.CycleId.ToString(
                                CultureInfo.InvariantCulture),
                            textStyle),

                        ReportTextCell(
                            $"B{rowIndex}",
                            item.CycleDate,
                            textStyle),

                        ReportTextCell(
                            $"C{rowIndex}",
                            item.SnapshotBulkId.ToString(
                                CultureInfo.InvariantCulture),
                            textStyle),

                        ReportTextCell(
                            $"D{rowIndex}",
                            item.BulkCreatedAt.ToString(
                                "yyyy-MM-dd HH:mm:ss",
                                CultureInfo.InvariantCulture),
                            textStyle),

                        ReportNumberCell(
                            $"E{rowIndex}",
                            item.TotalInvoices,
                            numberStyle),

                        ReportNumberCell(
                            $"F{rowIndex}",
                            item.ReadyToPublishCount,
                            numberStyle),

                        ReportNumberCell(
                            $"G{rowIndex}",
                            item.AccountsWithExceptionsCount,
                            numberStyle),

                        ReportNumberCell(
                            $"H{rowIndex}",
                            item.TotalExceptions,
                            numberStyle),

                        ReportNumberCell(
                            $"I{rowIndex}",
                            item.RulesWithExceptionsCount,
                            numberStyle)
                    );

                    sheetData.Append(row);
                    rowIndex++;
                }

                var worksheet = new Worksheet(
                    new SheetViews(sheetView),
                    columns,
                    sheetData);

                
                worksheet.Append(new AutoFilter
                {
                    Reference = $"A5:I{rowIndex - 1}"
                });

                worksheet.Append(new MergeCells(
                    new MergeCell
                    {
                        Reference = "A1:F2"
                    },
                    new MergeCell
                    {
                        Reference = "A3:F3"
                    },
                    new MergeCell
                    {
                        Reference = "A4:I4"
                    }
                ));

               
                worksheetPart.Worksheet = worksheet;

                if (logoBytes.Length > 0)
                {
                    AddReportLogo(
                        worksheetPart,
                        worksheet,
                        logoBytes,
                        logoIsPng);
                }

                var sheets = workbookPart.Workbook
                    .AppendChild(new Sheets());

                sheets.Append(new Sheet
                {
                    Id = workbookPart.GetIdOfPart(worksheetPart),
                    SheetId = 1U,
                    Name = "ملخص الدورة"
                });

                worksheet.Save();
                workbookPart.Workbook.Save();
            }

            var file = new ExcelFileDto
            {
                Content = stream.ToArray(),

                FileName =
                    $"CycleSummary_{rows[0].CycleId.ToString(
                        CultureInfo.InvariantCulture)}.xlsx",

                ContentType =
                    "application/vnd.openxmlformats-officedocument." +
                    "spreadsheetml.sheet"
            };

            return BVGResponse<ExcelFileDto>.Success(
                file,
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }

        private static Columns CreateReportColumns()
        {
            var columns = new Columns();

            var widths = new[]
            {
                16D, 18D, 16D, 25D, 20D,
                22D, 28D, 22D, 30D
            };

            for (var index = 0; index < widths.Length; index++)
            {
                columns.Append(new Column
                {
                    Min = (uint)(index + 1),
                    Max = (uint)(index + 1),
                    Width = widths[index] * 1.25,
                    CustomWidth = true
                });
            }

            return columns;
        }

        private static Stylesheet CreateReportStyles()
        {
            var fonts = new Fonts(
               
                new Font(
                    new FontSize { Val = 11D },
                    new Color { Rgb = "FF243746" },
                    new FontName { Val = "Arial" }),

                
                new Font(
                    new Bold(),
                    new FontSize { Val = 18D },
                    new Color { Rgb = "FF17365D" },
                    new FontName { Val = "Arial" }),

             
                new Font(
                    new Bold(),
                    new FontSize { Val = 11D },
                    new Color { Rgb = "FFFFFFFF" },
                    new FontName { Val = "Arial" })
            );

            var fills = new Fills(
                new Fill(new PatternFill
                {
                    PatternType = PatternValues.None
                }),

                new Fill(new PatternFill
                {
                    PatternType = PatternValues.Gray125
                }),

                ReportFill("FF17365D"),
                ReportFill("FFFFFFFF"),
                ReportFill("FFF0F5FA")
            );

            var borders = new Borders(
                new Border(),

                new Border(
                    new LeftBorder(
                        new Color { Rgb = "FFD9E2F3" })
                    {
                        Style = BorderStyleValues.Thin
                    },

                    new RightBorder(
                        new Color { Rgb = "FFD9E2F3" })
                    {
                        Style = BorderStyleValues.Thin
                    },

                    new TopBorder(
                        new Color { Rgb = "FFD9E2F3" })
                    {
                        Style = BorderStyleValues.Thin
                    },

                    new BottomBorder(
                        new Color { Rgb = "FFD9E2F3" })
                    {
                        Style = BorderStyleValues.Thin
                    },

                    new DiagonalBorder())
            );

            var formats = new CellFormats(
                ReportFormat(0U, 0U, 0U),     
                ReportFormat(1U, 0U, 0U),     
                ReportFormat(2U, 2U, 1U),     
                ReportFormat(0U, 3U, 1U),     
                ReportFormat(0U, 3U, 1U, 3U), 
                ReportFormat(0U, 4U, 1U),     
                ReportFormat(0U, 4U, 1U, 3U) 
            );

            return new Stylesheet(
                fonts,
                fills,
                borders,

                new CellStyleFormats(
                    new CellFormat
                    {
                        FontId = 0U,
                        FillId = 0U,
                        BorderId = 0U,
                        NumberFormatId = 0U
                    }),

                formats,

                new CellStyles(
                    new CellStyle
                    {
                        Name = "Normal",
                        FormatId = 0U,
                        BuiltinId = 0U
                    }));
        }

        private static Fill ReportFill(string color)
        {
            return new Fill(
                new PatternFill(
                    new ForegroundColor { Rgb = color },
                    new BackgroundColor { Indexed = 64U })
                {
                    PatternType = PatternValues.Solid
                });
        }

        private static CellFormat ReportFormat(
            uint fontId,
            uint fillId,
            uint borderId,
            uint numberFormatId = 0U)
        {
            return new CellFormat
            {
                FontId = fontId,
                FillId = fillId,
                BorderId = borderId,
                FormatId = 0U,
                NumberFormatId = numberFormatId,

                ApplyFont = true,
                ApplyFill = true,
                ApplyBorder = true,
                ApplyAlignment = true,
                ApplyNumberFormat = numberFormatId != 0U,

                Alignment = new Alignment
                {
                    Horizontal = HorizontalAlignmentValues.Center,
                    Vertical = VerticalAlignmentValues.Center,
                    WrapText = true,
                    ReadingOrder = 2U
                }
            };
        }

        private static Cell ReportTextCell(
            string reference,
            string value,
            uint styleIndex)
        {
            return new Cell
            {
                CellReference = reference,
                StyleIndex = styleIndex,
                DataType = CellValues.InlineString,

                InlineString = new InlineString(
                    new Text(value)
                    {
                        Space = SpaceProcessingModeValues.Preserve
                    })
            };
        }

        private static Cell ReportNumberCell(
            string reference,
            long? value,
            uint styleIndex)
        {
            var cell = new Cell
            {
                CellReference = reference,
                StyleIndex = styleIndex
            };

            if (value.HasValue)
            {
                cell.DataType = CellValues.Number;

                cell.CellValue = new CellValue(
                    value.Value.ToString(
                        CultureInfo.InvariantCulture));
            }

            return cell;
        }

        private static bool TryReadLogo(
            string logoBase64,
            out byte[] bytes,
            out bool isPng)
        {
            bytes = Array.Empty<byte>();
            isPng = false;

           
            if (string.IsNullOrWhiteSpace(logoBase64))
            {
                return true;
            }

            logoBase64 = logoBase64.Trim();

            
            if (logoBase64.StartsWith(
                "data:",
                StringComparison.OrdinalIgnoreCase))
            {
                var commaIndex = logoBase64.IndexOf(',');

                if (commaIndex < 0)
                {
                    return false;
                }

                logoBase64 = logoBase64
                    .Substring(commaIndex + 1)
                    .Trim();
            }

            if (string.IsNullOrWhiteSpace(logoBase64))
            {
                return false;
            }

            var buffer = new byte[logoBase64.Length];

            if (!Convert.TryFromBase64String(
                logoBase64,
                buffer,
                out var bytesWritten))
            {
                return false;
            }

            bytes = buffer.Take(bytesWritten).ToArray();

            isPng = bytes.Length >= 8 &&
                bytes.Take(8).SequenceEqual(
                    new byte[]
                    {
                        137, 80, 78, 71, 13, 10, 26, 10
                    });

            var isJpeg = bytes.Length >= 3 &&
                bytes[0] == 0xFF &&
                bytes[1] == 0xD8 &&
                bytes[2] == 0xFF;

            return isPng || isJpeg;
        }

        private static void AddReportLogo(
            WorksheetPart worksheetPart,
            Worksheet worksheet,
            byte[] logoBytes,
            bool isPng)
        {
            var drawingsPart =
                worksheetPart.AddNewPart<DrawingsPart>();

            drawingsPart.WorksheetDrawing =
                new Xdr.WorksheetDrawing();

            var imagePart = isPng
                ? drawingsPart.AddImagePart(ImagePartType.Png)
                : drawingsPart.AddImagePart(ImagePartType.Jpeg);

            using (var imageStream = new MemoryStream(logoBytes))
            {
                imagePart.FeedData(imageStream);
            }

            
            const long widthPixels = 150L;
            const long heightPixels = 125L;

            const long emusPerPixel = 9525L;
            const long width = widthPixels * emusPerPixel;
            const long height = heightPixels * emusPerPixel;

            var picture = new Xdr.Picture(
                new Xdr.NonVisualPictureProperties(
                    new Xdr.NonVisualDrawingProperties
                    {
                        Id = 1U,
                        Name = "Report Logo"
                    },

                    new Xdr.NonVisualPictureDrawingProperties(
                        new A.PictureLocks
                        {
                            NoChangeAspect = true
                        })),

                new Xdr.BlipFill(
                    new A.Blip
                    {
                        Embed = drawingsPart.GetIdOfPart(imagePart)
                    },

                    new A.Stretch(
                        new A.FillRectangle())),

                new Xdr.ShapeProperties(
                    new A.Transform2D(
                        new A.Offset
                        {
                            X = 0L,
                            Y = 0L
                        },

                        new A.Extents
                        {
                            Cx = width,
                            Cy = height
                        }),

                    new A.PresetGeometry(
                        new A.AdjustValueList())
                    {
                        Preset = A.ShapeTypeValues.Rectangle
                    })
            );

            var anchor = new Xdr.OneCellAnchor(
               
                new Xdr.FromMarker(
                    new Xdr.ColumnId("6"),
                    new Xdr.ColumnOffset("95250"),
                    new Xdr.RowId("0"),
                    new Xdr.RowOffset("47625")),

                new Xdr.Extent
                {
                    Cx = width,
                    Cy = height
                },

                picture,
                new Xdr.ClientData()
            );

            drawingsPart.WorksheetDrawing.Append(anchor);
            drawingsPart.WorksheetDrawing.Save();

          
            worksheet.Append(
                new DocumentFormat.OpenXml.Spreadsheet.Drawing
                {
                    Id = worksheetPart.GetIdOfPart(drawingsPart)
                });
        }
    }
}


