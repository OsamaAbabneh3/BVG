﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using System.Threading;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public interface IReportsService
    {
        Task<BVGResponse<ExcelFileDto>> GetCycleSummaryAsync(CycleSummaryReportRequestDto dto, CancellationToken cancellationToken);
    }
}
