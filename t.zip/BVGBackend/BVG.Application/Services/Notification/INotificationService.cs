﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.Notification
{
    public interface INotificationService
    {
        Task SendToAllAsync<T>(string eventName,T data,CancellationToken cancellationToken = default);
        Task SendToAllAsync(string eventName, CancellationToken cancellationToken = default);

        Task SendToUserAsync<T>(string userId,string eventName,T data,CancellationToken cancellationToken = default);
    }
}
