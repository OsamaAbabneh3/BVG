﻿using BVG.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BVG.Application.Services.Notification
{
    public class NotificationService : INotificationService
    {
        private readonly INotificationRepository _repository;
        public NotificationService(INotificationRepository repository)
        {
            _repository = repository;
        }

        public Task SendToAllAsync<T>(string eventName,T data,CancellationToken cancellationToken = default)
        {
            return _repository.SendToAllAsync(eventName, data, cancellationToken);
        }

        public Task SendToAllAsync(string eventName, CancellationToken cancellationToken = default)
        {
            return _repository.SendToAllAsync(eventName, cancellationToken);
        }

        public Task SendToUserAsync<T>(string userId,string eventName,T data,CancellationToken cancellationToken = default)
        {
            return _repository.SendToUserAsync(userId, eventName, data, cancellationToken);
        }
    }
}
