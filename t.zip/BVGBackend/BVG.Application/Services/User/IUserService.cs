﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public interface IUserService
    {
        Task<BVGResponse<object>> CreateUser(CreateUserDto dto, CancellationToken cancellationToken);

        Task<BVGResponse<UpdateUserDto>> UpdateUserAsync(Guid id, UpdateUserDto dto, CancellationToken cancellationToken);

        Task<BVGResponse<GetByIdResponseDto>> GetById(Guid id, CancellationToken cancellationToken);

        Task<BVGResponse<PaginationResponseDto>> GetAllUsers(DynamicPaginationDto dto, CancellationToken cancellationToken);

        Task<BVGResponse<object>> ToggleBlock(Guid id, CancellationToken cancellationToken);
        Task<BVGResponse<object>> Unlocked(Guid id, CancellationToken cancellationToken);

        Task<BVGResponse<object>> AssignRolesToUser(AssignRolesToUserDto dto, CancellationToken cancellationToken);
    }
}
