﻿using BVG.Application.Common;
using BVG.Application.Exceptions;
using BVG.Application.Services.Email.EmailSender;
using BVG.Application.Services.Jwt;
using BVG.Application.Services.Paginator;
using BVG.Application.Services.UnitOfWork;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Helper.AuditLog;
using Helper.EmailBody;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace BVG.Application.Services
{
    public class UserService : IUserService
    {
        #region DI UserService
        private readonly IUserRepository _userRepository;
        private readonly IRoleRepository _roleRepository;
        private readonly IAuditLogService _auditLogService;
        private readonly IUnitOfWorkService _unitOfWorkService;
        private readonly ILogger<UserService> _logger;
        private readonly IPaginatorService _paginatorService;
        private readonly IEmailSenderService _emailSenderService;
        #endregion

        #region UserService
        public UserService(
            IUserRepository userRepository,
            IRoleRepository roleRepository,
            IAuthService jwtService,
            IAuditLogService auditLogService,
            IUnitOfWorkService unitOfWorkService,
            ILogger<UserService> logger,
            IPaginatorService paginatorService,
            IEmailSenderService emailSenderService)
        {
            _userRepository = userRepository;
            _roleRepository = roleRepository;
            _auditLogService = auditLogService;
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
            _paginatorService = paginatorService;
            _emailSenderService = emailSenderService;
        }
        #endregion

        #region UserService (Create , Update , Get By ID , Get All Users , ToggleBlock)
        /// <summary>
        /// Crete New Account By Admin Role
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<BVGResponse<object>> CreateUser(CreateUserDto dto, CancellationToken cancellationToken)
        {
            // check the username is exist or not 
            var userExists = await _userRepository.IsUserExists(dto.Username.Trim().ToUpper(), cancellationToken);
            if (userExists) 
            {
                return BVGResponse<object>.Fail(BVGStatusCode.Conflict, BVGErrorCode.UserAlreadyExists);
            }
            // check the Email is exist or not
            var isEmailUsed = await _userRepository.IsEmailUsed(dto.Email.Trim().ToUpper(), cancellationToken);
            if (isEmailUsed)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.Conflict, BVGErrorCode.EmailExists);
            }
            var isPhoneUsed = await _userRepository.IsPhoneUsed(dto.PhoneNumber.Trim().ToUpper(), cancellationToken);
            if (isPhoneUsed)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.Conflict, BVGErrorCode.PhoneUsed);
            }

            //check the number of roles is found or not
            var count = await _roleRepository.CountAsync(dto.RoleIds, cancellationToken);
            if (count != dto.RoleIds.Count) 
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.RoleNotFound);
            }

            //generate the new password HASH

            
            var password = GeneratePassword(12);
            var hasher = new PasswordHasher<BvgUser>();
            var hashedPassword = hasher.HashPassword(null!, password);

            //set Data User on Entites
            var user = new BvgUser
            {
                Id = Guid.NewGuid(),
                UserName = dto.Username.Trim().ToUpper(),
                Email = dto.Email.Trim().ToUpper(),
                FirstName = dto.FirstName.Trim(),
                LastName = dto.LastName.Trim(),
                PasswordHash = hashedPassword,
                PhoneNumber = dto.PhoneNumber,
                MustChangePassword = true
            };

            //each for roles when select the roles in user and add the user with realtion Many to Many
            var userRoles = new List<UserRole>();
            foreach (var roleId in dto.RoleIds)
            {
                userRoles.Add(new UserRole
                {
                    UserId = user.Id,
                    RoleId = roleId,
                    AssignedAt = DateTime.UtcNow,
                });
            }

            user.UserRoles = userRoles;
            var accountCreate = new AccountCreatedSentDto()
            {
                FullName = dto.FirstName.Trim() + " " + dto.LastName.Trim(),
                Email = dto.Email.Trim().ToUpper(),
                UserName = dto.Username.Trim().ToUpper(),
                Password = password
            };
            var toEmail=new List<string>();
            toEmail.Add(accountCreate.Email);
            // apply transaction between create user and auditlog
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                //await _auditLogRepository.AddAsync(new AuditLog
                //{
                //    ActionType = (int)SystemActionEnum.CreateUser,
                //    Details = AuditLogHelper.GenerateAuditLogDetails(
                //        _localizer,
                //        SystemActionEnum.CreateUser,
                //        user.UserName
                //        ),
                //    CreatedAt = DateTime.UtcNow,
                //});


                await _userRepository.AddAsync(user, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.CreateUser, EntityTypeEnum.BvgUser, user.Id.ToString(),cancellationToken, user.UserName);
                await _unitOfWorkService.CommitAsync();
                await _emailSenderService.SendEmailAsync(toEmail, EmailBody.SubjectCreateAccount, EmailBody.GenerateEmailCreateAccount(accountCreate),TypeOfSend.CreateAccount, true,accountCreate);
                
            }
            catch (Exception ex) 
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }

            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }

        /// <summary>
        /// Update User From First Name and Last Name and PHone Number 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<BVGResponse<UpdateUserDto>> UpdateUserAsync(Guid id , UpdateUserDto dto, CancellationToken cancellationToken)
        {
            // retrieve user by id and check user found or not
            var user = await _userRepository.GetById(id, cancellationToken);
         
            if(user == null)
            {
                return BVGResponse<UpdateUserDto>.Fail(BVGStatusCode.NotFound, BVGErrorCode.UserNotFound);
            }
            var isPhoneUsed = await _userRepository.IsPhoneUsedExceptCurrent(id, dto.PhoneNumber.Trim().ToUpper(), cancellationToken);
            if (isPhoneUsed)
            {
                return BVGResponse<UpdateUserDto>.Fail(BVGStatusCode.Conflict, BVGErrorCode.PhoneUsed);
            }
            // apply transaction between update user and auditlog
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _auditLogService.CreateAuditLog(
                    null,
                    SystemActionEnum.UpdateUser, 
                    EntityTypeEnum.BvgUser, 
                    user.Id.ToString(), 
                    cancellationToken,
                    user.FirstName,
                    dto.FirstName.Trim(),
                    user.LastName,
                    dto.LastName.Trim(),
                    user.UserName);

                user.FirstName = dto.FirstName.Trim();
                user.LastName = dto.LastName.Trim();
                user.PhoneNumber = dto.PhoneNumber;
                await _userRepository.UpdateAsync(user, cancellationToken);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }


            return BVGResponse<UpdateUserDto>.Success(
                new UpdateUserDto
                {
                    FirstName = dto.FirstName.Trim(),
                    LastName = dto.LastName.Trim()
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }

        /// <summary>
        /// Get User By Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<BVGResponse<GetByIdResponseDto>> GetById(Guid id, CancellationToken cancellationToken)
        {
            //chek user by id is found or not
            var user = await _userRepository.GetByIdWithRoles(id, cancellationToken);
            if (user == null)
            {
                return BVGResponse<GetByIdResponseDto>.Fail(BVGStatusCode.NotFound, BVGErrorCode.UserNotFound);
            }

            return BVGResponse<GetByIdResponseDto>.Success(
                new GetByIdResponseDto
                {
                    Id = user.Id,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    CreatedAt = user.CreatedAt,
                    Roles = user.UserRoles.Where(x => x.Role != null).Select(x => x.Role!).Select(r => new GetAllRolesResponseDto  
                        { 
                            Id = r.Id, 
                            NameEn = r.RoleName,
                            NameAr = r.NameAr,
                            Description = r.Description
                        }).ToList(),
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }

        /// <summary>
        /// Get All Users Filtering by Order By and return Pagenation
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<BVGResponse<PaginationResponseDto>> GetAllUsers(DynamicPaginationDto dto, CancellationToken cancellationToken)
        {
            var query = _userRepository.Query(dto.FilterOptions);
            
            // check the column when filter the column is exist or not
            bool columnExists = typeof(BvgUser).GetProperties().Any(p => p.Name.Equals(dto.OrderBy, StringComparison.OrdinalIgnoreCase));

            if (!columnExists)
            {
                return BVGResponse<PaginationResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidColumnNameInOrderBy);
            }
            // Order Data Users with DESC
            bool isDescending = dto.OrderDirection == OrderDirectionEnum.DESC;
            query = query.OrderByProperty(dto.OrderBy, isDescending);

            //Returning Data users with pagenation by page number and size
            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);

            var data = await result.Query
                .Select(x => new GetUserDetailsDto
                {
                    Id = x.Id,
                    Username = x.UserName,
                    FirstName = x.FirstName,
                    LastName = x.LastName,
                    Email = x.Email,
                    PhoneNumber = x.PhoneNumber,
                    IsBlocked = x.IsBlocked,
                    IsLocked = x.LockedUntil != null && x.LockedUntil > DateTime.UtcNow ? true : false,
                    LockedUntil = x.LockedUntil,
                    CreatedAt = x.CreatedAt,
                    UpdatedAt = x.UpdatedAt,
                    MustChangePassword = x.MustChangePassword,
                    Roles = x.UserRoles.Select(x => x.Role == null ? new() : new GetAllRolesResponseDto
                    {
                        Id = x.Role.Id,
                        NameEn = x.Role.RoleName,
                        NameAr = x.Role.NameAr,
                        Description = x.Role.Description
                    }).ToList(),
                }).ToListAsync();

            return BVGResponse<PaginationResponseDto>.Success(
                new PaginationResponseDto
                {
                    Data = data,
                    PageNumber = dto.PageNumber,
                    PageSize = dto.PageSize,
                    TotalCount = result.TotalCount
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }
       
        /// <summary>
        /// Add Block from user when admin change block or not the user
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<BVGResponse<object>> ToggleBlock(Guid id, CancellationToken cancellationToken)
        {
            //Retrieve user by id
            var user = await _userRepository.GetById(id, cancellationToken);
            if (user == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.UserNotFound);
            }

            //change block 
            user.IsBlocked = !user.IsBlocked;
            
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _userRepository.UpdateAsync(user, cancellationToken);
                await _auditLogService.CreateAuditLog(null, user.IsBlocked ? SystemActionEnum.BlockUser : SystemActionEnum.UnblockUser, EntityTypeEnum.BvgUser, user.Id.ToString(), cancellationToken, user.UserName);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                await _unitOfWorkService.RollbackAsync();
                throw;
            }
            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully,BVGStatusCode.Ok);
        }
        public async Task<BVGResponse<object>> Unlocked(Guid id, CancellationToken cancellationToken)
        {
            //Retrieve user by id
            var user = await _userRepository.GetById(id, cancellationToken);
            if (user == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.UserNotFound);
            }
            user.LockedUntil = null;
            user.LoginTryAttempt = 0;

            try
            {
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.UserUnlocked, EntityTypeEnum.BvgUser, user.Id.ToString(), cancellationToken, user.UserName);
                await _unitOfWorkService.BeginTransactionAsync();
                await _userRepository.UpdateAsync(user, cancellationToken);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                await _unitOfWorkService.RollbackAsync();
                throw;
            }
            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }
       

        public async Task<BVGResponse<object>> AssignRolesToUser(AssignRolesToUserDto dto, CancellationToken cancellationToken)
        {
            var user = await _userRepository.GetByIdWithUserRoles(dto.UserId, cancellationToken);

            if (user == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.UserNotFound);
            }

            if (user.UserName.Equals("Admin", StringComparison.OrdinalIgnoreCase))
            {
                return BVGResponse<object>.Fail(BVGStatusCode.Forbidden, BVGErrorCode.ThisUserCannotBeReassigned);
            }

            var count = await _roleRepository.CountAsync(dto.RoleIds, cancellationToken);

            if (count != dto.RoleIds.Count)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidRole);
            }

            var currentRoleIds = user.UserRoles.Select(ur => ur.RoleId).ToList();

            var userRolesToRemove = user.UserRoles.Where(ur => ur.RoleId != null && !dto.RoleIds.Contains(ur.RoleId.Value)).ToList();

            await _userRepository.RemoveRangeOfUserRoles(userRolesToRemove, cancellationToken);

            foreach (var roleId in dto.RoleIds)
            {
                if (!currentRoleIds.Contains(roleId))
                {
                    user.UserRoles.Add(new UserRole
                    {
                        UserId = user.Id,
                        RoleId = roleId,
                        AssignedAt = DateTime.UtcNow,
                    });
                }
            }
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.AssignRolesToUser, EntityTypeEnum.BvgUser, user.Id.ToString(), cancellationToken, user.UserName);
                await _userRepository.UpdateAsync(user, cancellationToken);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                await _unitOfWorkService.RollbackAsync();
                throw;
            }

            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }
        #endregion

        #region Helper Functionality from User Services
        /// <summary>
        /// Hash password When Create new Account By Admin
        /// </summary>
        /// <param name="length"></param>
        /// <returns></returns>
        private string GeneratePassword(int length)
        {
            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%&*0123456789@#$%&*";
            var result = new char[length];
            for (var i = 0; i < length; i++)
            {
                var index = RandomNumberGenerator.GetInt32(chars.Length);
                result[i] = chars[index];
            }
            return new string(result);
        }

       
        #endregion
    }
}
