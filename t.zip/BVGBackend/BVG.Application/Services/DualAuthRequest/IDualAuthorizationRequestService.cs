﻿using System;
using System.Collections.Generic;
using System;
using System.Collections.Generic;
using System.Text;
using BVG.Application.Common;
using BVG.Domain.DTOs;

namespace BVG.Application.Services
{
    public interface IDualAuthorizationRequestService
    {
        Task<BVGResponse<PaginationResponseDto>> GetAllDualAuthorizationRequest(DynamicPaginationDto dto, CancellationToken cancellationToken);
        Task<BVGResponse<object>> AddDualAuthorizationRequest(AddDualAuthorizationRequestDto addDualAuthorizationRequestDto, CancellationToken cancellationToken);
        Task<BVGResponse<object>> UpdateDualAuthorizationRequest(UpdateDualAuthorizationRequestDto updateDualAuthorizationRequestDto, CancellationToken cancellationToken);
        Task<BVGResponse<DualAuthorizationRequestDto>> GetByIdDualAuthorizationRequest(long id, CancellationToken cancellationToken);
    }
}
