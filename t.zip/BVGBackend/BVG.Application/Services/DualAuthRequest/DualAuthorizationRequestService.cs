﻿using BVG.Application.Common;
using BVG.Application.Services.Paginator;
using BVG.Application.Services.UnitOfWork;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace BVG.Application.Services
{
    public class DualAuthorizationRequestService : IDualAuthorizationRequestService
    {
        private readonly IDualAuthorizationRequestRepository _dualAuthorizationRequestRepository;
        private readonly IDualAuthorizationApprovalRepository _dualAuthorizationApprovalRepository;
        private readonly IPaginatorService _paginatorService;
        private readonly IUnitOfWorkService _unitOfWorkService;
        private readonly ILogger<InvoiceExceptionService> _logger;
        private readonly IStringLocalizer<Messages> _localizer;
        private IAuditLogService _auditLogService;
        public DualAuthorizationRequestService(
            IDualAuthorizationRequestRepository dualAuthorizationRequestRepository,
            IDualAuthorizationApprovalRepository dualAuthorizationApprovalRepository,
            IPaginatorService paginatorService,
            IAuditLogRepository auditLogRepository,
            IAuditLogService auditLogService,
            ILogger<InvoiceExceptionService> logger,
            IUnitOfWorkService unitOfWorkService,
            IStringLocalizer<Messages> localizer
            )
        {
            _dualAuthorizationRequestRepository = dualAuthorizationRequestRepository;
            _paginatorService = paginatorService;
            _dualAuthorizationApprovalRepository = dualAuthorizationApprovalRepository;
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
            _auditLogService = auditLogService;
            _localizer = localizer;
        }
        public async Task<BVGResponse<PaginationResponseDto>> GetAllDualAuthorizationRequest(DynamicPaginationDto dto, CancellationToken cancellationToken)
        {
            var query = _dualAuthorizationRequestRepository.Query(dto.FilterOptions);

            bool columnExists = typeof(DualAuthorizationRequest).GetProperties().Any(p => p.Name.Equals(dto.OrderBy, StringComparison.OrdinalIgnoreCase));

            if (!columnExists)
            {
                return BVGResponse<PaginationResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidColumnNameInOrderBy);
            }

            bool isDescending = dto.OrderDirection == OrderDirectionEnum.DESC;
            query = query.OrderByProperty(dto.OrderBy, isDescending);

            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);

            var data = await result.Query
                .Select(dual => new DualAuthorizationRequestDto
                {
                    Id = dual.Id,
                    Description = dual.Description,
                    Status = dual.Status,
                    CreatedAt = dual.CreatedAt,
                    UpdatedAt = dual.UpdatedAt,
                }).ToListAsync();

            return BVGResponse<PaginationResponseDto>.Success(
                new PaginationResponseDto
                {
                    Data = data,
                    PageNumber = dto.PageNumber,
                    PageSize = dto.PageSize,
                    TotalCount = result.TotalCount
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }

        public async Task<BVGResponse<DualAuthorizationRequestDto>> GetByIdDualAuthorizationRequest(long id, CancellationToken cancellationToken)
        {
            var dualAuthRequest = await _dualAuthorizationRequestRepository.GetByIdDualAuthorizationRequest(id, cancellationToken);
            if (dualAuthRequest == null)
            {
                return BVGResponse<DualAuthorizationRequestDto>.Fail(BVGStatusCode.NotFound, BVGErrorCode.DualAuthorizationRequestNotFound);
            }
            var dualAuthRequestDto = new DualAuthorizationRequestDto
            {
                Id = dualAuthRequest.Id,
                Description = dualAuthRequest.Description,
                Status = dualAuthRequest.Status,
                CreatedAt = dualAuthRequest.CreatedAt,
                UpdatedAt = dualAuthRequest.UpdatedAt,
            };
            return BVGResponse<DualAuthorizationRequestDto>.Success(dualAuthRequestDto, BVGMessage.ReturnSuccessfully, BVGStatusCode.Ok);
        }
        public async Task<BVGResponse<object>> AddDualAuthorizationRequest(AddDualAuthorizationRequestDto dto, CancellationToken cancellationToken)
        {
            var approverUserIds = await _dualAuthorizationApprovalRepository.GetAuthorizedApproverUserIdsAsync(cancellationToken);

            if (approverUserIds.Count != 2)
            {
                return BVGResponse<object>.Fail(
                    BVGStatusCode.BadRequest,
                    BVGErrorCode.InvalidDualAuthorizationApprovers
                );
            }
            var dual = new DualAuthorizationRequest 
            {
                Status = dto.Status,
                Description = dto.Description,
                CreatedAt = DateTime.UtcNow
            };
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _dualAuthorizationRequestRepository.AddDualAuthorizationRequest(dual, cancellationToken);
                foreach (var approverUserId in approverUserIds)
                {
                    var approval = new DualAuthorizationApproval
                    {
                        DualAuthorizationRequestId = dual.Id,
                        ApproverUserId = approverUserId,
                        Decision = null,
                        ApprovalTime = null,
                        CreatedAt = DateTime.UtcNow
                    };

                    await _dualAuthorizationApprovalRepository
                        .AddDualAuthorizationApproval(approval, cancellationToken);
                }
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.AddDualAuthorizationRequest, EntityTypeEnum.DualAuthorizationRequest, dual.Id.ToString() , cancellationToken);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }


            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }
        public async Task<BVGResponse<object>> UpdateDualAuthorizationRequest(UpdateDualAuthorizationRequestDto dto, CancellationToken cancellationToken)
        {
            var dual = await _dualAuthorizationRequestRepository.GetByIdDualAuthorizationRequest(dto.Id, cancellationToken);
            if (dual == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.DualAuthorizationRequestNotFound);
            }
            dual.Description = dto.Description;
            dual.Status = true;
            dual.UpdatedAt = DateTime.UtcNow;
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _dualAuthorizationRequestRepository.UpdateDualAuthorizationRequest(dual, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.UpdateDualAuthorizationRequest, EntityTypeEnum.DualAuthorizationRequest, dual.Id.ToString(), cancellationToken);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }
            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }
    }
}
