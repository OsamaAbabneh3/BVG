﻿using BVG.Application.Common;
using BVG.Application.Services.Paginator;
using BVG.Application.Services.UnitOfWork;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BVG.Application.Services
{
    public class SnapshotBulkService : ISnapshotBulkService
    {
        private readonly ISnapshotBulkRepository _snapshotBulkRepository;
        private readonly IPaginatorService _paginatorService;
        private readonly IUnitOfWorkService _unitOfWorkService;
        private readonly ILogger<SnapshotBulkService> _logger;
        private readonly IStringLocalizer<Messages> _localizer;
        private readonly IAuditLogService _auditLogService;
        private readonly ICycleInfoRepository _cycleInfoRepository;
        public SnapshotBulkService(
            ISnapshotBulkRepository snapshotBulkRepository,
            IPaginatorService paginatorService,
            IAuditLogService auditLogService,
            ILogger<SnapshotBulkService> logger,
            IUnitOfWorkService unitOfWorkService,
            IStringLocalizer<Messages> localizer,
            ICycleInfoRepository cycleInfoRepository
            )
        {
            _snapshotBulkRepository = snapshotBulkRepository;
            _paginatorService = paginatorService;
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
            _localizer = localizer;
            _auditLogService = auditLogService;
            _cycleInfoRepository = cycleInfoRepository;
        }
        public async Task<BVGResponse<PaginationResponseDto>> GetAllSnapshotBulk(DynamicPaginationDto dto, CancellationToken cancellationToken)

        {
            var query = _snapshotBulkRepository.Query(dto.FilterOptions);

            bool columnExists = typeof(SnapshotBulk).GetProperties().Any(p => p.Name.Equals(dto.OrderBy));

            if (!columnExists)
            {

                return BVGResponse<PaginationResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidColumnNameInOrderBy);

            }

            bool isDescending = dto.OrderDirection == OrderDirectionEnum.DESC;
            query = query.OrderByProperty(dto.OrderBy, isDescending);

            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);

           var data = await result.Query
                .Select(x => new SnapshotBulkDto
           {
               Id = x.Id,
               CycleId = x.CycleId,
               CreatedAt = x.CreatedAt,
               UpdatedAt = x.UpdatedAt,
               ReferenceOk = x.ReferenceOk,
               ReferenceReason = x.ReferenceReason,
               Sequence = x.Sequence,
               Status = x.Status == null ? null : (VerdictEnum)x.Status,
               CheckStatus = (CheckStatusEnum)x.CheckStatus,
               PullStatus = (PullStatusEnum)x.PullStatus
           }).ToListAsync();
            return BVGResponse<PaginationResponseDto>.Success(new 
                PaginationResponseDto
            {
                Data = data,
                PageNumber = dto.PageNumber,
                PageSize = dto.PageSize,
                TotalCount = result.TotalCount
            },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }
        public async Task<BVGResponse<SnapshotBulkDto>> GetByIdSnapshotBulk(long id, CancellationToken cancellationToken)
        {
            var snapshotBulk = await _snapshotBulkRepository.GetByIdSnapshotBulk(id, cancellationToken);
            if (snapshotBulk == null)
            {
                return BVGResponse<SnapshotBulkDto>.Fail(BVGStatusCode.NotFound, BVGErrorCode.SnapshotBulkNotFound);
            }
            var snapshotBulkDto = new SnapshotBulkDto
            {
                Id = snapshotBulk.Id,
                CycleId = snapshotBulk.CycleId,
                CreatedAt = snapshotBulk.CreatedAt,
                UpdatedAt = snapshotBulk.UpdatedAt,
                ReferenceOk = snapshotBulk.ReferenceOk,
                ReferenceReason = snapshotBulk.ReferenceReason,
                Sequence = snapshotBulk.Sequence,
                Status = snapshotBulk.Status == null ? null : (VerdictEnum)snapshotBulk.Status,
                CheckStatus = (CheckStatusEnum)snapshotBulk.CheckStatus,
                PullStatus = (PullStatusEnum)snapshotBulk.PullStatus
            };
            return BVGResponse<SnapshotBulkDto>.Success(snapshotBulkDto, BVGMessage.ReturnSuccessfully, BVGStatusCode.Ok);
        }
        
        
        //public async Task<BVGResponse<object>> AddSnapshotBulk(AddSnapshotBulkDto dto, CancellationToken cancellationToken)
        //{
        //    var cycleInfo = await _cycleInfoRepository.GetByIdCycleInfo(dto.CycleId, cancellationToken);
        //    if (cycleInfo == null)
        //    {
        //        return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.SnapshotBulkNotFound);
        //    }
        //    var bulk = new SnapshotBulk
        //    {
        //        CycleId = dto.CycleId,
        //        ReferenceOk = dto.ReferenceOk,
        //        ReferenceReason = dto.ReferenceReason,
        //        Status = dto.Status,
        //        CreatedAt = DateTime.UtcNow,
        //        CheckStatus = (byte)CheckStatusEnum.Pending,
        //    };
        //    try
        //    {
        //        await _unitOfWorkService.BeginTransactionAsync();
        //        await _snapshotBulkRepository.AddSnapshotBulk(bulk, cancellationToken);
        //        await _auditLogService.CreateAuditLog(null, SystemActionEnum.AddSnapshotBulk, EntityTypeEnum.SnapshotBulk, bulk.Id.ToString(), cancellationToken);
        //        await _unitOfWorkService.CommitAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        await _unitOfWorkService.RollbackAsync();
        //        _logger.LogError(ex.Message);
        //        throw;
        //    }
        //    return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        //}
    }
}
