﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public interface ISnapshotBulkService
    {
        //Task<BVGResponse<object>> AddSnapshotBulk(AddSnapshotBulkDto dto, CancellationToken cancellationToken);
        Task<BVGResponse<PaginationResponseDto>> GetAllSnapshotBulk(DynamicPaginationDto dto, CancellationToken cancellationToken);
        Task<BVGResponse<SnapshotBulkDto>> GetByIdSnapshotBulk(long id, CancellationToken cancellationToken);
    }
}
