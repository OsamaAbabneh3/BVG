﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public interface IDualAuthorizationApprovalService
    {
        Task<BVGResponse<PaginationResponseDto>> GetAllDualAuthorizationApproval(DynamicPaginationDto dto, CancellationToken cancellationToken);
        Task<BVGResponse<DualAuthorizationApprovalDto>> GetByIdDualAuthorizationApproval(long id, CancellationToken cancellationToken);
        Task<BVGResponse<object>> DecisionDualAuthorizationApproval(DecisionDualAuthorizationApprovalDto dto, CancellationToken cancellationToken);
        Task<BVGResponse<PaginationResponseDto>> GetAllDualAuthorizationApprovalByUserId(DynamicPaginationDto dto, CancellationToken cancellationToken);
    }
}
