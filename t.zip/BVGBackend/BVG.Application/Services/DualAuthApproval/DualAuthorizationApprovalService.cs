﻿using BVG.Application.Common;
using BVG.Application.Services.Paginator;
using BVG.Application.Services.UnitOfWork;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;

namespace BVG.Application.Services
{
    public class DualAuthorizationApprovalService : IDualAuthorizationApprovalService
    {
        private readonly IDualAuthorizationApprovalRepository _dualAuthorizationApprovalRepository;
        private readonly IPaginatorService _paginatorService;
        private readonly IUnitOfWorkService _unitOfWorkService;
        private readonly ILogger<DualAuthorizationApprovalService> _logger;
        private readonly IStringLocalizer<Messages> _localizer;
        private IAuditLogService _auditLogService;
        public DualAuthorizationApprovalService(
            IDualAuthorizationApprovalRepository dualAuthorizationApprovalRepository,
            IPaginatorService paginatorService,
            IAuditLogService auditLogService,
            ILogger<DualAuthorizationApprovalService> logger,
            IUnitOfWorkService unitOfWorkService,
            IStringLocalizer<Messages> localizer
            )
        {
            _dualAuthorizationApprovalRepository = dualAuthorizationApprovalRepository;
            _paginatorService = paginatorService;
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
            _auditLogService = auditLogService;
            _localizer = localizer;
        }
        public async Task<BVGResponse<PaginationResponseDto>> GetAllDualAuthorizationApproval(DynamicPaginationDto dto, CancellationToken cancellationToken)
        {
            var query = _dualAuthorizationApprovalRepository.Query(dto.FilterOptions);

            bool columnExists = typeof(DualAuthorizationApproval).GetProperties().Any(p => p.Name.Equals(dto.OrderBy, StringComparison.OrdinalIgnoreCase));

            if (!columnExists)
            {
                return BVGResponse<PaginationResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidColumnNameInOrderBy);
            }

            bool isDescending = dto.OrderDirection == OrderDirectionEnum.DESC;
            query = query.OrderByProperty(dto.OrderBy, isDescending);

            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);

            var data = await result.Query
                .Select(dual => new DualAuthorizationApprovalDto
                {
                    //Id = dual.Id,
                    DualAuthorizationRequestId = dual.DualAuthorizationRequestId,
                    ApproverUserId = dual.ApproverUserId,
                    ApprovalTime = dual.ApprovalTime,
                    Justification = dual.Justification,
                    Decision = dual.Decision,
                    CreatedAt = dual.CreatedAt,
                    UpdatedAt = dual.UpdatedAt,

                }).ToListAsync();

            return BVGResponse<PaginationResponseDto>.Success(
                new PaginationResponseDto
                {
                    Data = data,
                    PageNumber = dto.PageNumber,
                    PageSize = dto.PageSize,
                    TotalCount = result.TotalCount
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }

        public async Task<BVGResponse<PaginationResponseDto>> GetAllDualAuthorizationApprovalByUserId(DynamicPaginationDto dto, CancellationToken cancellationToken)
        {
            JsonElement userId = JsonSerializer.SerializeToElement(BVGText.GetUserId());
            dto.FilterOptions.Groups.Add(new FilterGroupDto
            {
                InnerOperator = "AND",
                OuterOperator = "AND",
                Filters = new List<DynamicFilter>
                {
                    new DynamicFilter("ApproverUserId", "eq", userId)
                }
            });
            var query = _dualAuthorizationApprovalRepository.Query(dto.FilterOptions);

            bool columnExists = typeof(DualAuthorizationApproval).GetProperties().Any(p => p.Name.Equals(dto.OrderBy, StringComparison.OrdinalIgnoreCase));

            if (!columnExists)
            {
                return BVGResponse<PaginationResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidColumnNameInOrderBy);
            }

            bool isDescending = dto.OrderDirection == OrderDirectionEnum.DESC;
            query = query.OrderByProperty(dto.OrderBy, isDescending);

            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);

            var data = await result.Query
                .Select(dual => new DualAuthorizationApprovalDto
                {
                    //Id = dual.Id,
                    DualAuthorizationRequestId = dual.DualAuthorizationRequestId,
                    ApproverUserId = dual.ApproverUserId,
                    ApprovalTime = dual.ApprovalTime,
                    Justification = dual.Justification,
                    Decision = dual.Decision,
                    CreatedAt = dual.CreatedAt,
                    UpdatedAt = dual.UpdatedAt,

                }).ToListAsync();

            return BVGResponse<PaginationResponseDto>.Success(
                new PaginationResponseDto
                {
                    Data = data,
                    PageNumber = dto.PageNumber,
                    PageSize = dto.PageSize,
                    TotalCount = result.TotalCount
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }



        public async Task<BVGResponse<DualAuthorizationApprovalDto>> GetByIdDualAuthorizationApproval(long id, CancellationToken cancellationToken)
        {
            var r = await _dualAuthorizationApprovalRepository.GetByIdDualAuthorizationApproval(id, cancellationToken);
            if (r == null)
                return BVGResponse<DualAuthorizationApprovalDto>.Fail(BVGStatusCode.NotFound, BVGErrorCode.DualAuthorizationApprovalNotFound);
            //exception
            return BVGResponse<DualAuthorizationApprovalDto>.Success(new DualAuthorizationApprovalDto
            {
                Id = r.Id,
                DualAuthorizationRequestId = r.DualAuthorizationRequestId,
                ApproverUserId = r.ApproverUserId,
                ApprovalTime = r.ApprovalTime,
                Justification = r.Justification,
                Decision = r.Decision,
                CreatedAt = r.CreatedAt,
                UpdatedAt = r.UpdatedAt,
            }, BVGMessage.ReturnSuccessfully, BVGStatusCode.Ok
            );

        }
        public async Task<BVGResponse<object>> DecisionDualAuthorizationApproval(DecisionDualAuthorizationApprovalDto dto, CancellationToken cancellationToken)
        {
            var approval = await _dualAuthorizationApprovalRepository.GetByIdDualAuthorizationApproval(dto.Id, cancellationToken);

            if (approval == null)
            {
                return BVGResponse<object>.Fail(
                    BVGStatusCode.NotFound,
                    BVGErrorCode.DualAuthorizationApprovalNotFound
                );
            }

            var currentUserId = BVGText.GetUserId();
            if (approval.ApproverUserId != currentUserId)
            {
                return BVGResponse<object>.Fail(
                    BVGStatusCode.Forbidden,
                    BVGErrorCode.UserNotAuthorizedToApprove
                );
            }

            if (approval.Decision.HasValue)
            {
                return BVGResponse<object>.Fail(
                    BVGStatusCode.BadRequest,
                    BVGErrorCode.DualAuthorizationApprovalAlreadyDecided
                );
            }
            approval.Decision = dto.Decision;
            approval.Justification = dto.Justification;

            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _dualAuthorizationApprovalRepository.UpdateDualAuthorizationApproval(approval,cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.DecisionOfApproval, EntityTypeEnum.DualAuthorizationApproval, approval.Id.ToString(), cancellationToken);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }


            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }
    }
}
