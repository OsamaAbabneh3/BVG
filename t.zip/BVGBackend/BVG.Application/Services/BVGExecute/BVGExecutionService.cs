﻿using BVG.Application.Services.Notification;
using BVG.Application.Strategy;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using BVG.Domain.Models;
using Helper.InvoiceExeption;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.BVGExecute
{
    public class BVGExecutionService : IBVGExecuteService
    {
        private readonly AuditStrategy _auditStrategy;
        private readonly IInvoiceExceptionRepository _invoiceExceptionRepository;
        private readonly ISnapshotBulkRepository _snapshotBulkRepository;

        public BVGExecutionService(
            AuditStrategy auditStrategy, 
            IInvoiceExceptionRepository invoiceExceptionRepository,
            ISnapshotBulkRepository snapshotBulkRepository)
        {
            _auditStrategy = auditStrategy;
            _invoiceExceptionRepository = invoiceExceptionRepository;
            _snapshotBulkRepository = snapshotBulkRepository;
        }
        public async Task BVGExecute(ClaimedBackgroundJob job, long bulkId, long StartId, long EndId, CancellationToken cancellationToken)
        {
            throw new Exception();
            var context = new AuditContext 
            {
                Job = job,
                BulkId = bulkId,
                StartId = StartId,
                EndId = EndId,
            };
            await _auditStrategy.ExecuteAsync(context, cancellationToken);
            var exceptions = context.ExceptionBatch.GetAll();
            await _invoiceExceptionRepository.AddRangeInvoidExceptions(exceptions, cancellationToken);
        }
    }
}
