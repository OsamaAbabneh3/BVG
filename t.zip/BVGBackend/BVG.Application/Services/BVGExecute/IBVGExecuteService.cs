﻿using BVG.Domain.Models;

namespace BVG.Application.Services.BVGExecute
{
    public interface IBVGExecuteService
    {
        Task BVGExecute(ClaimedBackgroundJob Job, long BulkId, long StartId, long EndId, CancellationToken cancellationToken);
    }
}
