﻿using BVG.Application.Common;
using BVG.Application.Services.Paginator;
using BVG.Application.Services.UnitOfWork;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace BVG.Application.Services
{
    public class InvoiceExceptionService : IInvoiceExceptionService
    {
        private readonly IInvoiceExceptionRepository _invoiceExceptionRepository;
        private readonly IPaginatorService _paginatorService;
        private readonly IUnitOfWorkService _unitOfWorkService;
        private readonly ILogger<InvoiceExceptionService> _logger;
        private readonly IStringLocalizer<Messages> _localizer;
        private IAuditLogRepository _auditLogRepository;
        private IAuditLogService _auditLogService;

        public InvoiceExceptionService(
            IInvoiceExceptionRepository invoiceExceptionRepository,
            IPaginatorService paginatorService,
            IAuditLogRepository auditLogRepository,
            IAuditLogService auditLogService,
            ILogger<InvoiceExceptionService> logger,
            IUnitOfWorkService unitOfWorkService,
            IStringLocalizer<Messages> localizer


            )
        {
            _invoiceExceptionRepository = invoiceExceptionRepository;
            _paginatorService = paginatorService;
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
            _auditLogRepository = auditLogRepository;
            _auditLogService = auditLogService;
            _localizer = localizer;
        }
        public async Task<BVGResponse<PaginationResponseDto>> GetAllInvoiceException(DynamicPaginationDto dto, CancellationToken cancellationToken)
        {
            var query = _invoiceExceptionRepository.Query(dto.FilterOptions);

            bool columnExists = typeof(InvoiceException).GetProperties().Any(p => p.Name.Equals(dto.OrderBy, StringComparison.OrdinalIgnoreCase));

            if (!columnExists)
            {
                return BVGResponse<PaginationResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidColumnNameInOrderBy);
            }

            bool isDescending = dto.OrderDirection == OrderDirectionEnum.DESC;
            query = query.OrderByProperty(dto.OrderBy, isDescending);

            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);

            var data = await result.Query
                .Select(rule => new GetInvoiceExceptionDto
                {
                    Id = rule.Id,
                    RuleId = rule.RuleId, 
                    SnapshotBulkId = rule.SnapshotBulkId,
                    AccountNumber = rule.AccountNumber,
                    Description = rule.Description,
                    MonitoreStatus = rule.MonitoreStatus,
                    CreatedAt = rule.CreatedAt,
                    UpdatedAt = rule.UpdatedAt,

                }).ToListAsync();

            return BVGResponse<PaginationResponseDto>.Success(
                new PaginationResponseDto
                {
                    Data = data,
                    PageNumber = dto.PageNumber,
                    PageSize = dto.PageSize,
                    TotalCount = result.TotalCount
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }
        public async Task<BVGResponse<GetInvoiceExceptionDto>> GetByIdInvoiceException(long id, CancellationToken cancellationToken)
        {
            var r = await _invoiceExceptionRepository.GetByIdInvoiceException(id, cancellationToken);
            if (r == null)
                return BVGResponse<GetInvoiceExceptionDto>.Fail(BVGStatusCode.NotFound, BVGErrorCode.InvoiceExceptionNotFound);
            //exception
            return BVGResponse<GetInvoiceExceptionDto>.Success(new GetInvoiceExceptionDto
            {
                Id = r.Id,
                RuleId = r.RuleId,
                SnapshotBulkId = r.SnapshotBulkId,
                AccountNumber = r.AccountNumber,
                Description = r.Description,
                MonitoreStatus = r.MonitoreStatus,
                CreatedAt = r.CreatedAt,
                UpdatedAt = r.UpdatedAt,
            }, BVGMessage.ReturnSuccessfully, BVGStatusCode.Ok
            );

        }
        public async Task <BVGResponse<object>> UpdateInvoiceException(UpdateInvoiceExceptionDto updateInvoiceException, CancellationToken cancellationToken)
        {
            var invoice = await _invoiceExceptionRepository.GetByIdInvoiceException(updateInvoiceException.Id, cancellationToken);
            if (invoice == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.InvoiceExceptionNotFound);
            }

            invoice.MonitoreStatus = updateInvoiceException.MonitoreStatus;
            invoice.Description = updateInvoiceException.Description;
            invoice.UpdatedAt = DateTime.UtcNow;

            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _invoiceExceptionRepository.UpdateInvoiceException(invoice, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.UpdateInvoiceException, EntityTypeEnum.InvoiceException, invoice.Id.ToString(),cancellationToken, invoice.Id);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }


            return BVGResponse<object>.Success(null, BVGMessage.ReturnSuccessfully, BVGStatusCode.Ok);
        }
        public async Task<BVGResponse<object>> AddInvoiceException(AddInvoiceExceptionDto addInvoiceExceptionDto, CancellationToken cancellationToken)
        {
            bool isDuplicate = await _invoiceExceptionRepository.IsDuplicate(addInvoiceExceptionDto.SnapshotBulkId, addInvoiceExceptionDto.RuleId, addInvoiceExceptionDto.AccountNumber, cancellationToken);


            if (isDuplicate)
            {
                return BVGResponse<object>.Fail(
                    BVGStatusCode.BadRequest,
                    BVGErrorCode.DuplicateInvoiceException
                );
            }
            var invoice = new InvoiceException
            {
                RuleId = addInvoiceExceptionDto.RuleId, 
                SnapshotBulkId = addInvoiceExceptionDto.SnapshotBulkId, 
                AccountNumber = addInvoiceExceptionDto.AccountNumber,
                Description = addInvoiceExceptionDto.Description,
                MonitoreStatus = addInvoiceExceptionDto.MonitoreStatus,
                CreatedAt = DateTime.UtcNow
            };
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _invoiceExceptionRepository.AddInvoiceException(invoice, cancellationToken);
                await _auditLogService.CreateAuditLog(null, SystemActionEnum.AddInvoiceException, EntityTypeEnum.InvoiceException, invoice.Id.ToString(),cancellationToken);
                await _unitOfWorkService.CommitAsync();
            }
            catch (Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }


            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }
    }
}
