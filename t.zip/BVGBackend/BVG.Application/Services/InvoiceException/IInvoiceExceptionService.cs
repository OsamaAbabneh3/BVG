﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public interface IInvoiceExceptionService
    {
        Task<BVGResponse<PaginationResponseDto>> GetAllInvoiceException(DynamicPaginationDto dto, CancellationToken cancellationToken);
        Task<BVGResponse<GetInvoiceExceptionDto>> GetByIdInvoiceException(long id, CancellationToken cancellationToken);
        Task<BVGResponse<object>> UpdateInvoiceException(UpdateInvoiceExceptionDto updateInvoiceExceptionDto, CancellationToken cancellationToken);
        Task<BVGResponse<object>> AddInvoiceException(AddInvoiceExceptionDto addInvoiceExceptionDto, CancellationToken cancellationToken);

    }
}
