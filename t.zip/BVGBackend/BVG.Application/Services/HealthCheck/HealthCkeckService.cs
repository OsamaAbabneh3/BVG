﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.HealthCheck
{
    public class HealthCkeckService : IHealthCkeckService
    {
        private readonly IHealthCheckRepository _healthCheckRepository;

        public HealthCkeckService(IHealthCheckRepository healthCheckRepository)
        {
            _healthCheckRepository = healthCheckRepository;
        }

        public async Task<BVGResponse<HealthCheckResponse>> HealthCheck()
        {
            var bvgConnection = await _healthCheckRepository.CanConnectWithBVGDBAsync();
            var snapshotConnection = await _healthCheckRepository.CanConnectWithSnapshotDBAsync();
            var oracleConnection = await _healthCheckRepository.CanConnectWithOracleDBAsync();
            var data = new HealthCheckResponse
            {
                BvgConnection = bvgConnection,
                SnapshotConnection = snapshotConnection,
                OracleConnection = oracleConnection
            };

            return BVGResponse<HealthCheckResponse>.Success(data, BVGMessage.ReturnSuccessfully, BVGStatusCode.Ok);
        } 
    }
}
