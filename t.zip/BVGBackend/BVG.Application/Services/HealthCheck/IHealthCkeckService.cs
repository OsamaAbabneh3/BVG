﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.HealthCheck
{
    public interface IHealthCkeckService
    {
        Task<BVGResponse<HealthCheckResponse>> HealthCheck();
    }
}
