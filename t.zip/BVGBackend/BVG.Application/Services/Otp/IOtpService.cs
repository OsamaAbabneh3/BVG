﻿using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.Otp
{
    public interface IOtpService
    {
        Task<OtpResponseDto> SendAsync(string username, string phone, OtpPurpose purpose);
        Task<string> VerifyAsync(string requestToken, string code, OtpPurpose purpose);
    }
}
