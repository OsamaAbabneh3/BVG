﻿using BVG.Application.Common;
using BVG.Application.Exceptions;
using BVG.Application.Services.UnitOfWork;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace BVG.Application.Services.Otp
{
    public class OtpService : IOtpService
    {
        private readonly IOtpRepository _otpRepository;
        private readonly IUnitOfWorkService _unitOfWorkService;
        private readonly ISmsSender _smsSender;
        private readonly ILogger<OtpCode> _logger;
        private readonly IStringLocalizer<Messages> _localizer;
        private readonly OtpSettings _otpSettings;


        public OtpService(IOtpRepository otpRepository, IUnitOfWorkService unitOfWorkService, ISmsSender smsSender, IStringLocalizer<Messages> localizer, IOptions<OtpSettings> otpSettings, ILogger<OtpCode> logger)
        {
            _otpRepository= otpRepository;
            _unitOfWorkService= unitOfWorkService;
            _smsSender= smsSender;
            _localizer= localizer;
            _otpSettings = otpSettings.Value;
            _logger = logger;
        }

        public async Task<OtpResponseDto> SendAsync(string username, string phone, OtpPurpose purpose)
        {
            var now = DateTime.UtcNow;
            var last = await _otpRepository.GetLastCreatedAtAsync(username, purpose);
            if (last.HasValue && now - last.Value < _otpSettings.ResendCooldown)
                throw new OtpException(BVGStatusCode.TooManyRequests, BVGErrorCode.OtpCooldown);

            if (await _otpRepository.CountSentSinceAsync(username, purpose, now - _otpSettings.SendWindow) >= _otpSettings.MaxSendsPerWindow)
                throw new OtpException(BVGStatusCode.TooManyRequests, BVGErrorCode.TooManyOtpRequests);

            //var code = RandomNumberGenerator.GetInt32(100_000, 1_000_000).ToString();
            var code = "123456";
            var token = Convert.ToHexString(RandomNumberGenerator.GetBytes(24)).ToLowerInvariant();

            var otp = new OtpCode
            {
                Id= Guid.NewGuid(),
                RequestToken = token,
                Username = username,
                Purpose = (int)purpose,
                CodeHash = Hash(token, code, purpose),
                CreatedAt = now,
                ExpiresAt = now.Add(_otpSettings.Ttl)
            };
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();
                await _otpRepository.AddAsync(otp);
                await _unitOfWorkService.CommitAsync();
            }
            catch(Exception ex)
            {
                await _unitOfWorkService.RollbackAsync();
                _logger.LogError(ex.Message);
                throw;
            }
            
            try
            {
                await _smsSender.SendAsync(phone, _localizer["OtpSmsMessage", code, (int)_otpSettings.Ttl.TotalMinutes]);
            }
            catch
            {
                await _otpRepository.RemoveAsync(otp.Id);
                throw new OtpException(BVGStatusCode.BadGateway, BVGErrorCode.OtpDeliveryFailed);
            }

            await _otpRepository.InvalidateOthersAsync(username, purpose, otp.Id);
            await _otpRepository.DeleteOlderThanAsync(now.AddDays(-1));

            return new OtpResponseDto { RequestToken = token, ExpiresInSeconds = (int)_otpSettings.Ttl.TotalSeconds };
        }

        public async Task<string> VerifyAsync(string requestToken, string code, OtpPurpose purpose)
        {
            var now = DateTime.UtcNow;

            var otp = await _otpRepository.GetByTokenAsync(requestToken);
            if (otp is null || otp.Purpose != (int)purpose || otp.IsUsed || otp.ExpiresAt <= now)
                throw new OtpException(BVGStatusCode.BadRequest, BVGErrorCode.OtpExpired);

            if (otp.Attempts >= _otpSettings.MaxAttempts)
                throw new OtpException(BVGStatusCode.TooManyRequests, BVGErrorCode.OtpTooManyAttempts);

            if (!await _otpRepository.TryIncrementAttemptAsync(otp.Id, _otpSettings.MaxAttempts, now))
                throw new OtpException(BVGStatusCode.TooManyRequests, BVGErrorCode.OtpTooManyAttempts);

            var expected = Encoding.UTF8.GetBytes(otp.CodeHash);
            var actual = Encoding.UTF8.GetBytes(Hash(requestToken, code, purpose));

            if (!CryptographicOperations.FixedTimeEquals(expected, actual))
            {
                if (otp.Attempts + 1 >= _otpSettings.MaxAttempts)
                    throw new OtpException(BVGStatusCode.TooManyRequests, BVGErrorCode.OtpTooManyAttempts);

                throw new OtpException(BVGStatusCode.BadRequest, BVGErrorCode.InvalidOtp);
            }

            if (!await _otpRepository.TryMarkUsedAsync(otp.Id, now))
                throw new OtpException(BVGStatusCode.BadRequest, BVGErrorCode.OtpExpired);

            return otp.Username;
        }

        private string Hash(string token, string code, OtpPurpose purpose)
        {
            using var h = new HMACSHA256(Encoding.UTF8.GetBytes(_otpSettings.Secret));
            return Convert.ToHexString(h.ComputeHash(Encoding.UTF8.GetBytes($"{purpose}:{token}:{code}")));
        }

    }
}
