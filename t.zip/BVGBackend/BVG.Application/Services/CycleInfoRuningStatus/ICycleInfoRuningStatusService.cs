﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public interface ICycleInfoRuningStatusService
    {
        Task CreateCycleInfoRuningStatus(long SnapShotBulkId, CycleInfoRuningStatusActionEnum cycleInfoRuningStatusActionEnum, CancellationToken cancellationToken, params object[] args);
        Task<BVGResponse<PaginationResponseDto>> GetCycleInfoRuningStatusBySnapShotBulkIdPagenation(CycleInfoRuningstatusBySnapShotBulkRequestDto dto);
        Task<BVGResponse<List<CycleInfoRuningstatusResponseDto>>> GetCycleInfoRuningStatusBySnapShotBulkId(long SnapShotBulkId);
        Task<BVGResponse<PaginationResponseDto>> GetCycleInfoRuningStatusByCycleInfoIdPagenation(CycleInfoRuningStatusByCycleInfoRequestDto dto);
        Task<BVGResponse<CycleInfoRuningStatusByCycleInfoResponseDto>> GetCycleInfoRuningStatusByCycleInfoId(long cycleInfoId);

    }
}
