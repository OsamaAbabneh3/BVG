﻿using BVG.Application.Common;
using BVG.Application.Services.Notification;
using BVG.Application.Services.Paginator;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Helper.AuditLog;
using Helper.CycleinfoRuningStatusLog;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services
{
    public class CycleInfoRuningStatusService : ICycleInfoRuningStatusService
    {
        private readonly ICycleInfoRuningStatusRepository _cycleInfoRuningStatusRepository;
        private readonly ISnapshotBulkRepository _snapshotBulkRepository;
        private readonly IStringLocalizer<Messages> _localizer;
        private readonly ILogger<AuditLogService> _logger;
        private readonly IPaginatorService _paginatorService;
        private readonly INotificationService _notificationService;

        public CycleInfoRuningStatusService(
            ICycleInfoRuningStatusRepository cycleInfoRuningStatusRepository,
            IStringLocalizer<Messages> localizer,
            ILogger<AuditLogService> logger,
            IPaginatorService paginatorService,
            INotificationService notificationService,
            ISnapshotBulkRepository snapshotBulkRepository)
        {
            _cycleInfoRuningStatusRepository = cycleInfoRuningStatusRepository;
            _localizer = localizer;
            _logger = logger;
            _paginatorService = paginatorService;
            _notificationService = notificationService;
            _snapshotBulkRepository = snapshotBulkRepository;
        }
        public async Task CreateCycleInfoRuningStatus(long SnapShotBulkId, CycleInfoRuningStatusActionEnum cycleInfoRuningStatusActionEnum, CancellationToken cancellationToken, params object[] args)
        {
            try
            {
                var value = await _cycleInfoRuningStatusRepository.AddAsync(new CycleInfoRuningStatus
                {
                    CreatedAt=DateTime.UtcNow,
                    ActionType= CycleinfoRuningStatusLogHelper.GenerateCycleInfoRuningStatusLogAction(_localizer,cycleInfoRuningStatusActionEnum,args),
                    SnapshotBulkId=SnapShotBulkId
                });
                await _notificationService.SendToAllAsync<string>(EventNotifications.AddCycleInfoRuningstatus.ToString(), value.ActionType, cancellationToken);

            }
            catch(Exception ex) 
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

        public async Task<BVGResponse<List<CycleInfoRuningstatusResponseDto>>> GetCycleInfoRuningStatusBySnapShotBulkId(long snapShotBulkId)
        {
            var entities = await _cycleInfoRuningStatusRepository
                .WhereAsync(c => c.SnapshotBulkId == snapShotBulkId);

            var data = entities
                .OrderBy(c => c.CreatedAt)
                .Select(c => new CycleInfoRuningstatusResponseDto
                {
                    Id = c.Id,
                    ActionType = c.ActionType,
                    CreatedAt = c.CreatedAt
                })
                .ToList();

            return BVGResponse<List<CycleInfoRuningstatusResponseDto>>.Success(
                data,
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }

        public async Task<BVGResponse<PaginationResponseDto>> GetCycleInfoRuningStatusBySnapShotBulkIdPagenation(CycleInfoRuningstatusBySnapShotBulkRequestDto dto)
        {
            bool columnExists = typeof(CycleInfoRuningStatus)
                .GetProperties()
                .Any(p => p.Name == dto.OrderBy);

            if (!columnExists)
                return BVGResponse<PaginationResponseDto>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidColumnNameInOrderBy);

            var query = _cycleInfoRuningStatusRepository
                .Query(dto.FilterOptions)
                .Where(c => c.SnapshotBulkId == dto.SnapShotBulkId)
                .OrderByProperty(dto.OrderBy, dto.OrderDirection == OrderDirectionEnum.DESC);

            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);

            var data = result.Query
                .Select(c => new CycleInfoRuningstatusResponseDto
                {
                    Id = c.Id,
                    ActionType = c.ActionType,
                    CreatedAt = c.CreatedAt
                })
                .ToList();

            return BVGResponse<PaginationResponseDto>.Success(
                new PaginationResponseDto
                {
                    Data = data,
                    PageNumber = dto.PageNumber,
                    PageSize = dto.PageSize,
                    TotalCount = result.TotalCount
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }

        public async Task<BVGResponse<PaginationResponseDto>> GetCycleInfoRuningStatusByCycleInfoIdPagenation(CycleInfoRuningStatusByCycleInfoRequestDto dto)
        {
            var query = _snapshotBulkRepository.QueryByCycleInfoIdWithRuningStatuses(dto.CycleInfoId);


            var result = await _paginatorService.PaginateAsync(query, dto.PageNumber, dto.PageSize);

            var data = new CycleInfoRuningStatusByCycleInfoResponseDto
            {
                CycleInfoId = dto.CycleInfoId,
                SnapshotBulks = result.Query
                    .Select(s => new SnapshotBulkRuningStatusResponseDto
                    {
                        SnapshotBulkId = s.Id,
                        RuningStatuses = s.CycleInfoRuningStatuses
                            .OrderBy(c => c.CreatedAt)
                            .Select(c => new CycleInfoRuningstatusResponseDto
                            {
                                Id = c.Id,
                                ActionType = c.ActionType,
                                CreatedAt = c.CreatedAt
                            })
                            .ToList()
                    })
                    .ToList()
            };

            return BVGResponse<PaginationResponseDto>.Success(
                new PaginationResponseDto
                {
                    Data = data,
                    PageNumber = dto.PageNumber,
                    PageSize = dto.PageSize,
                    TotalCount = result.TotalCount
                },
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }

        public async Task<BVGResponse<CycleInfoRuningStatusByCycleInfoResponseDto>> GetCycleInfoRuningStatusByCycleInfoId(long cycleInfoId)
        {
            var snapshotBulks = await _snapshotBulkRepository
                .QueryByCycleInfoIdWithRuningStatuses(cycleInfoId)
                .ToListAsync();

            var data = new CycleInfoRuningStatusByCycleInfoResponseDto
            {
                CycleInfoId = cycleInfoId,
                SnapshotBulks = snapshotBulks
                    .Select(s => new SnapshotBulkRuningStatusResponseDto
                    {
                        SnapshotBulkId = s.Id,
                        RuningStatuses = s.CycleInfoRuningStatuses
                            .OrderBy(c => c.CreatedAt)
                            .Select(c => new CycleInfoRuningstatusResponseDto
                            {
                                Id = c.Id,
                                ActionType = c.ActionType,
                                CreatedAt = c.CreatedAt
                            })
                            .ToList()
                    })
                    .ToList()
            };

            return BVGResponse<CycleInfoRuningStatusByCycleInfoResponseDto>.Success(
                data,
                BVGMessage.ReturnSuccessfully,
                BVGStatusCode.Ok);
        }
    }
}
