﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.Permission
{
    public class PermissionService : IPermissionService
    {
        #region DI Permission
        private readonly IPermissionRepository _permissionRepository;
        #endregion

        #region Permission 
        public PermissionService(IPermissionRepository permissionRepository)
        {
            _permissionRepository = permissionRepository;
        }
        #endregion

        #region Permission Services

        /// <summary>
        /// Get All Permissions from DB
        /// </summary>
        /// <returns></returns>
        public async Task<BVGResponse<List<PermissionDto>>> GetAllPermissions(CancellationToken cancellationToken)
        {
            //get all Permission
            var permissions = await _permissionRepository.GetAllPermissions(cancellationToken);

            var data = permissions.Select(p => new PermissionDto
            {
                Id = p.Id,
                NameEn = p.PermissionName,
                NameAr = p.NameAr
            }).ToList();

            return BVGResponse<List<PermissionDto>>.Success(data, BVGMessage.ReturnSuccessfully, BVGStatusCode.Ok);
        }
        #endregion
    }
}
