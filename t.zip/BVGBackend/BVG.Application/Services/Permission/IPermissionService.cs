﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.Permission
{
    public interface IPermissionService
    {
        Task<BVGResponse<List<PermissionDto>>> GetAllPermissions(CancellationToken cancellationToken);
    }
}
