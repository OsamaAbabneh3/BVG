﻿using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.Email
{
    public interface IEmailLogService
    {
        public Task AddEmailLog(EmailLog emailLog);
    }
}
