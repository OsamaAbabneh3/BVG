﻿using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.Email
{
    public class EmailLogService:IEmailLogService
    {
        private readonly IEmailLogRepository _emailLogRepository;
        public EmailLogService(IEmailLogRepository emailLogRepository)
        {
            _emailLogRepository = emailLogRepository;
        }

        public async Task AddEmailLog(EmailLog emailLog)
        {
            await _emailLogRepository.Add(emailLog);
        }
    }
}
