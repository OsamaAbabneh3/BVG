﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using Helper.EmailBody;
using Helper.Security;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace BVG.Application.Services.Email.EmailSender
{
    public class EmailSenderService : IEmailSenderService
    {
        private readonly SmtpSettings _smtpSettings;
        private readonly IEmailLogService _emailLogService;
        private readonly ILogger<EmailLogService> _logger;

        public EmailSenderService(IOptions<SmtpSettings> smtpSettings, IEmailLogService emailLogService , ILogger<EmailLogService> logger)
        {
            _smtpSettings = smtpSettings.Value;
            _emailLogService = emailLogService;
            _logger = logger;
        }
        public async Task SendEmailAsync(List<string> toEmails, string subject, string body,TypeOfSend typeOfSend, bool isHtml = true, AccountCreatedSentDto? accountCreatedSentDto = null)
        {
            var recipients = NormalizeRecipients(toEmails);

            var log = new EmailLog
            {
                ToEmail = string.Join(",", recipients),
                Subject = subject,
                Body = body,
                IsSent = false,
                CreatedAt = DateTime.UtcNow
            };

            MailMessage mail = null!;
            SmtpClient client = null!;

            try
            {
                mail = new MailMessage(_smtpSettings.SenderEmail, log.ToEmail);
                mail.From = new MailAddress(_smtpSettings.SenderEmail, _smtpSettings.SenderName);
                mail.Subject = subject;
                mail.Body = EmailBody.GenerateEmailBody(body);
                mail.IsBodyHtml = isHtml;

                client = new SmtpClient();
                client.Host = AutoCrypto.Process(_smtpSettings.Host);
                client.Port = _smtpSettings.Port;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Credentials = new NetworkCredential(_smtpSettings.UserName,AutoCrypto.Process(_smtpSettings.Password));

                await client.SendMailAsync(mail);

                log.IsSent = true;
                log.SentAt = DateTime.UtcNow;
                _logger.LogInformation("Email sent to {Recipients}", log.ToEmail);
            }
            catch (Exception ex)
            {
                log.ErrorMessage = ex.ToString();
                log.IsSent = false;
            }
            finally
            {
                mail?.Dispose();
                client?.Dispose();
            }

            try
            {
                if (typeOfSend == TypeOfSend.CreateAccount)
                {
                    accountCreatedSentDto?.Password = "***********";
                    log.Body = EmailBody.GenerateEmailCreateAccount(accountCreatedSentDto!);
                }
                await _emailLogService.AddEmailLog(log);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to save EmailLog");
            }

         
        }

        private static List<string> NormalizeRecipients(List<string> toEmails)
        {
            var recipients = (toEmails ?? new List<string>())
                .Where(e => !string.IsNullOrWhiteSpace(e))
                .Select(e => e.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            if (recipients.Count == 0)
                throw new ArgumentException("At least one recipient is required.", nameof(toEmails));

            return recipients;
        }
    }
}
