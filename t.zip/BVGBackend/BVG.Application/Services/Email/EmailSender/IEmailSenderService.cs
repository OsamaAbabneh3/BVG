﻿using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.Email.EmailSender
{
    public interface IEmailSenderService
    {
        Task SendEmailAsync(List<string> toEmails, string subject, string body, TypeOfSend typeOfSend, bool isHtml = true, AccountCreatedSentDto? accountCreatedSentDto = null);
    }
}
