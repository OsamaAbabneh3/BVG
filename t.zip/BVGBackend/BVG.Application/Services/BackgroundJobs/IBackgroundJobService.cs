﻿using BVG.Application.Common;
using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.BackgroundJobs
{
    public interface IBackgroundJobService
    {
        Task<BVGResponse<EnqueueBackgroundJobsResponse>> EnqueueAsync(CancellationToken cancellationToken = default);
        Task<BVGResponse<long>> GetRowCountAsync(long snapshotBulkId, string sqlText, CancellationToken cancellationToken = default);
    }
}
