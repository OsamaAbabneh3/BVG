﻿using BVG.Application.Common;
using BVG.Application.Configuration;
using BVG.Application.Services.HealthCheck;
using BVG.Application.Services.UnitOfWork;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Services.BackgroundJobs
{
    public class BackgroundJobService : IBackgroundJobService
    {
        private readonly IBackgroundJobRepository _backgroundJobRepository;
        private readonly BackgroundJobOptions _options;
        private readonly IFingerprintRepository _fingerprintRepository;
        private readonly IGeneralRepository _generalRepository;
        private readonly IRuleCatalogRepository _ruleCatalogRepository;
        private readonly ISnapshotBulkRepository _snapshotBulkRepository;
        private readonly IAuditLogService _auditLogService;
        private readonly IHealthCkeckService _healthCkeckService;
        private readonly IUnitOfWorkService _unitOfWorkService;
        private readonly ILogger<BackgroundJobService> _logger;

        public BackgroundJobService(
            IBackgroundJobRepository backgroundJobRepository,
            IGeneralRepository generalRepository,
            IFingerprintRepository fingerprintRepository,
            IRuleCatalogRepository ruleCatalogRepository,
            IOptions<BackgroundJobOptions> options,
            ISnapshotBulkRepository snapshotBulkRepository,
            IAuditLogService auditLogService,
            IHealthCkeckService healthCkeckService,
            IUnitOfWorkService unitOfWorkService,
            ILogger<BackgroundJobService> logger)
        {
            _backgroundJobRepository = backgroundJobRepository;
            _generalRepository = generalRepository;
            _fingerprintRepository = fingerprintRepository;
            _options = options.Value;
            _ruleCatalogRepository = ruleCatalogRepository;
            _snapshotBulkRepository = snapshotBulkRepository;
            _auditLogService = auditLogService;
            _healthCkeckService = healthCkeckService;
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
        }
        public async Task<BVGResponse<long>> GetRowCountAsync(long snapshotBulkId, string sqlText, CancellationToken cancellationToken = default)
        {
            var rowCount = await _generalRepository.GetRowCountAsync(snapshotBulkId, sqlText, cancellationToken);
            return BVGResponse<long>.Success(rowCount, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }
        private async Task<BVGResponse<object>> ValidateRowCountAsync(long snapshotBulkId, string sqlText, CancellationToken cancellationToken)
        {
            var fingerprint =
                await _fingerprintRepository.GetBySnapshotBulkIdAsync(snapshotBulkId, cancellationToken);

            if (fingerprint == null)
            {
                return BVGResponse<object>.Fail(
                    BVGStatusCode.NotFound,
                    BVGErrorCode.FingerprintNotFound);
            }

            if (!fingerprint.RowCount.HasValue)
            {
                return BVGResponse<object>.Fail(
                    BVGStatusCode.BadRequest,
                    BVGErrorCode.FingerprintRowCountMissing);
            }

            if (fingerprint.FingerprintOk == false)
            {
                return BVGResponse<object>.Fail(
                    BVGStatusCode.BadRequest,
                    BVGErrorCode.FingerprintRowCountMismatch);
            }

            var actualRowCount = await _generalRepository.GetRowCountAsync(
                snapshotBulkId,
                sqlText,
                cancellationToken);

            if (fingerprint.RowCount.Value != actualRowCount)
            {
                fingerprint.FingerprintOk = false;
                await _fingerprintRepository.UpdateFingerprint(fingerprint, cancellationToken);
                return BVGResponse<object>.Fail(
                    BVGStatusCode.BadRequest,
                    BVGErrorCode.FingerprintRowCountMismatch);
            }

            fingerprint.FingerprintOk = true;
            await _fingerprintRepository.UpdateFingerprint(fingerprint, cancellationToken);

            return BVGResponse<object>.Success(
                new
                {
                    SnapshotBulkId = snapshotBulkId,
                    ExpectedRowCount = fingerprint.RowCount.Value,
                    ActualRowCount = actualRowCount
                },
                BVGMessage.ExecuteSuccessfully,
                BVGStatusCode.Ok);
        }


        private async Task<BVGResponse<object>> ValidateReferenceAsync(long bulkId, CancellationToken cancellationToken)
        {
            var rule = (await _ruleCatalogRepository.WhereAsync(catalog => catalog.Layer == 0)).FirstOrDefault();

            if (rule == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.RuleCatalogNotFound);
            }

            if (string.IsNullOrWhiteSpace(rule.QuerySql))
            {
                return BVGResponse<object>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.RuleQuerySqlMissing);
            }

            var result = await _ruleCatalogRepository.ExecuteFXDAsync(rule.QuerySql);

            var bulk = await _snapshotBulkRepository.GetByIdSnapshotBulk(bulkId, cancellationToken);

            if (bulk == null)
            {
                return BVGResponse<object>.Fail(BVGStatusCode.NotFound, BVGErrorCode.SnapshotBulkNotFound);
            }

            if (result.Any())
            {
                bulk.ReferenceOk = false;
                bulk.ReferenceReason = string.Join(", ", result.Select(r => $"Reference table ({r.REF_TABLE}) + Bill kind({r.BillKindId})"));
                await _snapshotBulkRepository.UpdateAsync(bulk, cancellationToken);
                return BVGResponse<object>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.InvalidReferences);
            }
            bulk.ReferenceOk = true;
            await _snapshotBulkRepository.UpdateAsync(bulk, cancellationToken);
            return BVGResponse<object>.Success(null, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
        }

        public async Task<BVGResponse<EnqueueBackgroundJobsResponse>> EnqueueAsync(CancellationToken cancellationToken = default)
        {
            var healthCheck = await _healthCkeckService.HealthCheck();
            if (healthCheck.Data == null ||
                healthCheck.Data.BvgConnection == false ||
                healthCheck.Data.SnapshotConnection == false ||
                healthCheck.Data.OracleConnection == false)
            {
                return BVGResponse<EnqueueBackgroundJobsResponse>.Fail(BVGStatusCode.Unavailable, BVGErrorCode.DatabaseConnectionFailed);
            }

            var anyPullInProgress = await _snapshotBulkRepository.AnyAsync(bulk => bulk.PullStatus == (byte)PullStatusEnum.Pending || bulk.PullStatus == (byte)PullStatusEnum.Processing);
            if (anyPullInProgress)
            {
                return BVGResponse<EnqueueBackgroundJobsResponse>.Fail(BVGStatusCode.Conflict, BVGErrorCode.PullInProgress);
            }

            var batchRunId = Guid.NewGuid();

            var bulkId = await _backgroundJobRepository.GetUncheckedBulkId();
            if (bulkId == null)
            {
                return BVGResponse<EnqueueBackgroundJobsResponse>.Fail(BVGStatusCode.BadRequest, BVGErrorCode.NoBillReadyToCheck);
            }

            var exists = await _backgroundJobRepository.AnyAsync(job => job.SnapshotBulkId == bulkId);
            if (exists)
            {
                return BVGResponse<EnqueueBackgroundJobsResponse>.Fail(BVGStatusCode.Conflict, BVGErrorCode.ProcessAlreadyStarted);
            }

            var sqlText = "select count(*) from FullSnapshot where SnapshotBulkId = @snapshotBulkId";
            try
            {
                await _unitOfWorkService.BeginTransactionAsync();

                var validationResult = await ValidateRowCountAsync(bulkId.Value, sqlText, cancellationToken);
                if (validationResult.ErrorCode != null)
                {
                    return new BVGResponse<EnqueueBackgroundJobsResponse>
                    {
                        StatusCode = validationResult.StatusCode,
                        Message = validationResult.Message,
                        ErrorCode = validationResult.ErrorCode
                    };
                }
                var referenceResult = await ValidateReferenceAsync(bulkId.Value, cancellationToken);

                if (referenceResult.ErrorCode != null)
                {
                    return new BVGResponse<EnqueueBackgroundJobsResponse>
                    {
                        StatusCode = referenceResult.StatusCode,
                        Message = referenceResult.Message,
                        ErrorCode = referenceResult.ErrorCode
                    };
                }

                var invoiceRanges = await _backgroundJobRepository.GetInvoiceRangesAsync(_options.BulkSize, bulkId.Value, cancellationToken);

                var jobs = invoiceRanges
                    .Select(range => new BackgroundJob
                    {
                        BatchRunId = batchRunId,
                        StartInvoiceId = range.StartInvoiceId,
                        EndInvoiceId = range.EndInvoiceId,
                        Status = 0,
                        Priority = 0,
                        AttemptCount = 0,
                        CreatedAt = DateTime.UtcNow,
                        SnapshotBulkId = bulkId.Value
                    })
                    .ToList();

                await _backgroundJobRepository.AddRangeAsync(jobs, cancellationToken);

                var userId = BVGText.GetUserId();
                if (userId != null)
                {
                    await _auditLogService.CreateAuditLog(null, SystemActionEnum.StartBVG, EntityTypeEnum.SnapshotBulk, bulkId.Value.ToString(), cancellationToken);
                }

                var data = new EnqueueBackgroundJobsResponse
                {
                    BatchRunId = batchRunId,
                    JobsCreated = jobs.Count
                };

                await _unitOfWorkService.CommitAsync();
                return BVGResponse<EnqueueBackgroundJobsResponse>.Success(data, BVGMessage.ExecuteSuccessfully, BVGStatusCode.Ok);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                await _unitOfWorkService.RollbackAsync();
                throw;
            }
        }
    }
}
