﻿using BVG.Domain.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Localization;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Common
{
    public static class BVGText
    {
        private static readonly HttpContextAccessor httpContextAccessor = new();

        public static string Get(string key,params object[] args)
        {
            var localizer = httpContextAccessor.HttpContext?
                .RequestServices
                .GetService<IStringLocalizer<Messages>>();

         
            if (localizer is null) return key;

            var s = localizer[key, args];
            return s.ResourceNotFound?key:s.Value;
        }

        public static Guid? GetUserId()
        {
            var userIdText = httpContextAccessor?.HttpContext?.User.Claims
                        .FirstOrDefault(c => c.Type == System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (Guid.TryParse(userIdText, out Guid userId))
            {
                return userId;
            }
            return null;
        }


    }
}
