﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Common
{
    public class StatusCode
    {
        public static int BadRequest { get; set; } = 400;
        public static int UnAuthorized { get; set; } = 401;
        public static int Forbidden { get; set; } = 403;
        public static int NotFound { get; set; } = 404;
        public static int InternalServerError { get; set; } = 500;
    }
}
