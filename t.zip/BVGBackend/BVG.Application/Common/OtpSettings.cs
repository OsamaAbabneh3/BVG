﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Common
{
    public class OtpSettings
    {
        public string Secret { get; set; } = default!;
        public TimeSpan Ttl { get; set; } = TimeSpan.FromMinutes(5);
        public int MaxAttempts { get; set; } = 3;
        public int MaxSendsPerWindow { get; set; } = 3;
        public TimeSpan SendWindow { get; set; } = TimeSpan.FromMinutes(10);
        public TimeSpan ResendCooldown { get; set; } = TimeSpan.FromSeconds(60);
    }
}
