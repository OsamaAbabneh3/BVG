﻿using BVG.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Common
{
    public class BVGResponse<T>
    {
        public int StatusCode { get; set; }
        public T? Data { get; set; }
        public string? Message { get; set; }
        public string? ErrorCode { get; set; }

        public static BVGResponse<T> Success(
            T? data,
            BVGMessage message,
            BVGStatusCode status = BVGStatusCode.Ok,
            params object[] args) =>
            new()
            {
                StatusCode = (int)status,
                Data = data,
                Message = BVGText.Get(message.ToString(), args),
                ErrorCode = null
            };

        public static BVGResponse<T> Fail(
            BVGStatusCode status,
            BVGErrorCode errorCode,
            T? data = default,
            params object[] args) =>
            new()
            {
                StatusCode = (int)status,
                Data = data,
                Message = BVGText.Get(errorCode.ToString(), args),
                ErrorCode = errorCode.ToString()
            };
    }
}
