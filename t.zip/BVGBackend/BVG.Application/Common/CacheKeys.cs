﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Application.Common
{
    public static class CacheKeys
    {
        public static string UserPermissions (Guid userId)
        {
            return $"cache:perm{userId}";
        }
    }
}
