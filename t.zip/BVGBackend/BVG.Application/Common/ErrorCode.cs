﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace BVG.Application.Common
{
    public class ErrorCode
    {
        public static string InternalServerError { get; set; } = "InternalServerError";
        public static string RoleAlreadyExists { get; set; } = "RoleAlreadyExists";
        public static string RoleNotFound { get; set; } = "RoleNotFound";
        public static string UserAlreadyExists { get; set; } = "UserAlreadyExists";
        public static string InvalidCredential { get; set; } = "InvalidCredential";
        public static string UserNotFound { get; set; } = "UserNotFound";
        public static string InvalidColumnNameInOrderBy { get; set; } = "InvalidColumnNameInOrderBy";
        public static string EmailUsed { get; set; } = "EmailUsed";
        public static string PermissionsRequired { get; set; } = "PermissionsRequired";
        public static string InvalidPermissionId { get; set; } = "InvalidPermissionId";

    }
}
