﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Application.Common
{
    public static class QueryableExtensions
    {
        public static IQueryable<T> OrderByProperty<T>(this IQueryable<T> source, string propertyName, bool desc)
        {
            var type = typeof(T);
            var property = type.GetProperty(propertyName);
            if (property == null) return source;

            var parameter = Expression.Parameter(type, "p");
            var propertyAccess = Expression.MakeMemberAccess(parameter, property);
            var orderByExpression = Expression.Lambda(propertyAccess, parameter);

            string methodName = desc ? "OrderByDescending" : "OrderBy";
            var resultExpression = Expression.Call(
            typeof(Queryable),
            methodName,
            new Type[] { type, property.PropertyType },
            source.Expression,
            Expression.Quote(orderByExpression));

            return source.Provider.CreateQuery<T>(resultExpression);
        }
    }
}
