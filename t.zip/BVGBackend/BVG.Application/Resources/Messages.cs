﻿namespace BVG.Application
{
    public class Messages
    {
    }
}
