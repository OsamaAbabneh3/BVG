﻿using BVG.Application.Configuration;
using BVG.Application.Services.BVGExecute;
using BVG.Application.Services.Notification;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using BVG.Domain.Models;
using BVG.Infrastructure.Repositories;
using Microsoft.Extensions.Options;

namespace BVG.API.BackGround
{
    public class BackgroundJobProcessor
    {
        private readonly ILogger<BackgroundJobProcessor> _logger;
        private readonly BackgroundJobClaimer _claimer;
        private readonly BackgroundJobHeartbeat _heartbeat;
        private readonly IBVGExecuteService _bVGExecuteService;
        private readonly INotificationService _notificationService;
        private readonly IBackgroundJobRepository _backgroundJobRepository;
        private readonly IInvoiceExceptionRepository _invoiceExceptionRepository;
        private readonly ISnapshotBulkRepository _snapshotBulkRepository;
        private readonly IFingerprintRepository _fingerprintRepository;
        private readonly GlobalExceptions _globalExceptionsOptions;
        private readonly IGeneralRepository _generalRepository;
        private readonly BackgroundJobOptions _backgroundJobOptions;

        public BackgroundJobProcessor(
            ILogger<BackgroundJobProcessor> logger,
            BackgroundJobClaimer claimer,
            BackgroundJobHeartbeat heartbeat,
            IBVGExecuteService bVGExecuteService,
            INotificationService notificationService,
            IBackgroundJobRepository backgroundJobRepository,
            IInvoiceExceptionRepository invoiceExceptionRepository,
            ISnapshotBulkRepository snapshotBulkRepository,
            IFingerprintRepository fingerprintRepository,
            IOptions<GlobalExceptions> globalExceptionsOptions,
            IGeneralRepository generalRepository,
            IOptions<BackgroundJobOptions> backgroundJobOptions)
        {
            _logger = logger;
            _claimer = claimer;
            _heartbeat = heartbeat;
            _bVGExecuteService = bVGExecuteService;
            _notificationService = notificationService;
            _backgroundJobRepository = backgroundJobRepository;
            _invoiceExceptionRepository = invoiceExceptionRepository;
            _snapshotBulkRepository = snapshotBulkRepository;
            _fingerprintRepository = fingerprintRepository;
            _globalExceptionsOptions = globalExceptionsOptions.Value;
            _generalRepository = generalRepository;
            _backgroundJobOptions = backgroundJobOptions.Value;
        }


        public async Task ProcessAsync(
    ClaimedBackgroundJob job,
    CancellationToken cancellationToken = default)
        {
            using var processingCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);

            using var heartbeatCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);

            var heartbeatTask = RunHeartbeatAsync(
                job,
                heartbeatCts,
                processingCts);

            var heartbeatStopped = false;

            async Task StopHeartbeatAsync()
            {
                if (heartbeatStopped)
                    return;

                heartbeatCts.Cancel();

                try
                {
                    await heartbeatTask;
                }
                catch (OperationCanceledException)
                {

                }
                catch (Exception ex)
                {
                    _logger.LogError(
                        ex,
                        "Heartbeat stopped with an error. JobId: {JobId}",
                        job.Id);
                }

                heartbeatStopped = true;
            }

            try
            {
                _logger.LogInformation(
                    "Started processing JobId: {JobId}, StartInvoiceId: {StartInvoiceId}, EndInvoiceId: {EndInvoiceId}",
                    job.Id,
                    job.StartInvoiceId,
                    job.EndInvoiceId);
                
                var bulk = await _snapshotBulkRepository.GetByIdSnapshotBulk(job.BulkId, cancellationToken);
                if (bulk == null)
                {
                    return;
                }
                
                bulk.CheckStatus = (byte)CheckStatusEnum.Processing;
                await _snapshotBulkRepository.UpdateAsync(bulk, cancellationToken);
                await _bVGExecuteService.BVGExecute(job, job.BulkId, job.StartInvoiceId, job.EndInvoiceId, cancellationToken);

                processingCts.Token.ThrowIfCancellationRequested();

                await StopHeartbeatAsync();

                processingCts.Token.ThrowIfCancellationRequested();

                await _claimer.CompleteAsync(job.Id, job.WorkerId, cancellationToken);

                var progress = await _backgroundJobRepository.ProgressAsync(job.BulkId, cancellationToken);
                var count = await _backgroundJobRepository.CountComletedAsync(bulk.Id);

                await _notificationService.SendToAllAsync<string>(EventNotifications.Progress.ToString(), $"{(int)(progress * 100)}-{count}", cancellationToken);

                _logger.LogInformation(
                    "Job completed. JobId: {JobId}, StartInvoiceId: {StartInvoiceId}, EndInvoiceId: {EndInvoiceId}",
                    job.Id,
                    job.StartInvoiceId,
                    job.EndInvoiceId);

                var isBulkCompleted = await _backgroundJobRepository.IsCheckBulkCompletedAsync(job.BulkId);
                if (isBulkCompleted)
                {

                    var anyFaild = await _backgroundJobRepository.AnyAsync(job => job.Status == (byte)JobStatusEnum.Failed && job.SnapshotBulkId == bulk.Id);
                    if (anyFaild)
                    {
                        bulk.CheckStatus = (byte)JobStatusEnum.Failed;
                        bulk.ErrorMessage = (await _backgroundJobRepository.FirstOrDefaultAsync(job => job.Status == (byte)JobStatusEnum.Failed && job.SnapshotBulkId == bulk.Id))?.ErrorMessage;
                        await _snapshotBulkRepository.UpdateAsync(bulk, CancellationToken.None);
                        await _invoiceExceptionRepository.DeleteByBulkIdAsync(bulk.Id);
                        await _backgroundJobRepository.DeleteByBulkId(bulk.Id);
                        return;
                    }
                    bulk.CheckStatus = (byte)CheckStatusEnum.Completed;
                    await _snapshotBulkRepository.UpdateAsync(bulk, cancellationToken);

                    await ExecuateVerdictAsync(bulk, job, cancellationToken);
                }

            }
            catch (OperationCanceledException)
                when (processingCts.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(
                    ex,
                    "Job processing failed. JobId: {JobId}, StartInvoiceId: {StartInvoiceId}, EndInvoiceId: {EndInvoiceId}",
                    job.Id,
                    job.StartInvoiceId,
                    job.EndInvoiceId);

                await StopHeartbeatAsync();

                try
                {
                    await _claimer.FailAsync(
                        job.Id,
                        job.WorkerId,
                        ex.ToString(),
                        CancellationToken.None);
                }
                catch (Exception failException)
                {
                    _logger.LogError(
                        failException,
                        "Could not mark JobId: {JobId} as Failed.",
                        job.Id);
                }

                throw;
            }
            finally
            {
                await StopHeartbeatAsync();
            }
        }

        private async Task RunHeartbeatAsync(
            ClaimedBackgroundJob job,
            CancellationTokenSource heartbeatCts,
            CancellationTokenSource processingCts)
        {
            try
            {
                await _heartbeat.RunAsync(
                    job.Id,
                    job.WorkerId,
                    heartbeatCts.Token);
            }
            catch (OperationCanceledException)
                when (heartbeatCts.IsCancellationRequested)
            {
            }
            catch (Exception)
            {
                processingCts.Cancel();
                throw;
            }
        }

        private async Task ExecuateVerdictAsync(SnapshotBulk bulk, ClaimedBackgroundJob job, CancellationToken cancellationToken)
        {
            var exceptionCount = await _invoiceExceptionRepository.CountAsync(ex => ex.SnapshotBulkId == job.BulkId);
            var fingerprint = (await _fingerprintRepository.WhereAsync(invoice => invoice.SnapshotBulkId == job.BulkId)).FirstOrDefault();
            if (fingerprint != null)
            {
                var invoiceCount = fingerprint.RowCount;
                if (exceptionCount == 0)
                {
                    bulk.Status = (int)VerdictEnum.Release;
                    await _snapshotBulkRepository.UpdateAsync(bulk, cancellationToken);
                    return;
                }

                var exceededGlobalExceptions = (invoiceCount / invoiceCount) >= _globalExceptionsOptions.Budget;
                if (exceededGlobalExceptions)
                {
                    bulk.Status = (int)VerdictEnum.Hold;
                    await _snapshotBulkRepository.UpdateAsync(bulk, cancellationToken);
                    return;
                }
                else
                {
                    bulk.Status = (int)VerdictEnum.Hold;
                    await _snapshotBulkRepository.UpdateAsync(bulk, cancellationToken);
                    return;
                }
            }
        }
    }
}
