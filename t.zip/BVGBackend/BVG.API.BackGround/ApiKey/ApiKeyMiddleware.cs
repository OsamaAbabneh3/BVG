﻿using BVG.Application.Common;
using BVG.Domain.Enums;

namespace BVG.API.BackGround.ApiKey
{
    public class ApiKeyMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly string _apikey;
        public ApiKeyMiddleware(RequestDelegate next, IConfiguration configuration)
        {
            _next = next;
            _apikey = configuration["BVGBackground:ApiKey"]!;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            if(context.Request.Path.StartsWithSegments("/swagger"))
            {
                await _next(context);
                return;
            }
            if(!context.Request.Headers.TryGetValue("X-Api-Key",out var key) || string.IsNullOrWhiteSpace(key))
            {
                context.Response.StatusCode = 401;
                await context.Response.WriteAsJsonAsync(new BVGResponse<object>
                {
                    StatusCode = 401,
                    ErrorCode = BVGErrorCode.API_KEY_MISSING.ToString(),
                    Message = "API Key is missing"
                });
                return;
            }
            if (key != _apikey)
            {
                context.Response.StatusCode = 401;
                await context.Response.WriteAsJsonAsync(new BVGResponse<object>
                {
                    StatusCode = 401,
                    ErrorCode = BVGErrorCode.API_KEY_INVALID.ToString(),
                    Message = "API Key is invalid"

                });
                return;
            }
            await _next(context);
        }

    }
}
