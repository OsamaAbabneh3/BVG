﻿using BVG.Domain.Interfaces;
using Microsoft.AspNetCore.SignalR;
using Microsoft.AspNetCore.SignalR.Client;

namespace BVG.API.BackGround.Notifications
{
    public class RemoteNotification : INotificationRepository, IAsyncDisposable
    {
        private readonly HubConnection _connection;
        private readonly ILogger<RemoteNotification> _logger;
        private readonly SemaphoreSlim _lock = new(1, 1);

        public RemoteNotification(IConfiguration config, ILogger<RemoteNotification> logger)
        {
            _logger = logger;

            var hubUrl = config["MainApp:InternalHubUrl"];
            var key = Uri.EscapeDataString(config["MainApp:InternalKey"] ?? "");
            _logger.LogInformation("SignalR hub url: {Url}", hubUrl);

            _connection = new HubConnectionBuilder()
                .WithUrl($"{hubUrl}?key={key}")
                .WithAutomaticReconnect()
                .Build();

            _connection.Reconnecting += ex =>
            {
                _logger.LogWarning(ex, "SignalR connection lost, reconnecting...");
                return Task.CompletedTask;
            };
            _connection.Reconnected += id =>
            {
                _logger.LogInformation("SignalR reconnected");
                return Task.CompletedTask;
            };
            _connection.Closed += ex =>
            {
                _logger.LogError(ex, "SignalR connection closed");
                return Task.CompletedTask;
            };
        }

        private async Task<bool> EnsureConnectedAsync(CancellationToken ct)
        {
            if (_connection.State == HubConnectionState.Connected) return true;

            await _lock.WaitAsync(ct);
            try
            {
                if (_connection.State == HubConnectionState.Disconnected)
                    await _connection.StartAsync(ct);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                _logger.LogError(ex, "SignalR connection failed");
            }
            finally
            {
                _lock.Release();
            }

            return _connection.State == HubConnectionState.Connected;
        }

        private async Task SafeInvokeAsync(string method, object?[] args, CancellationToken ct)
        {
            try
            {
                if (!await EnsureConnectedAsync(ct))
                {
                    _logger.LogWarning("SignalR not connected ({State}); skipped {Method}",
                        _connection.State, method);
                    return;
                }
                await _connection.InvokeCoreAsync(method, args, ct);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                _logger.LogError(ex, "SignalR invoke {Method} failed", method);
            }
        }

        public Task SendToAllAsync<T>(string eventName, T data, CancellationToken cancellationToken = default)
            => SafeInvokeAsync("SendToAll", new object?[] { eventName, data }, cancellationToken);

        public Task SendToAllAsync(string eventName, CancellationToken cancellationToken = default)
            => SafeInvokeAsync("SendToAllNoData", new object?[] { eventName }, cancellationToken);

        public Task SendToUserAsync<T>(string userId, string eventName, T data, CancellationToken cancellationToken = default)
            => SafeInvokeAsync("SendToUser", new object?[] { userId, eventName, data }, cancellationToken);

        public async ValueTask DisposeAsync() => await _connection.DisposeAsync();
    }
}
