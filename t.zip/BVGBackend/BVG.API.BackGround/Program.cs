using BVG.API.BackGround.ApiKey;
using BVG.API.BackGround.Extensions;
using BVG.Infrastructure.Seeders;

var builder = WebApplication.CreateBuilder(args);
string configFolderPath = builder.Configuration["FolderConfigPath"] ?? AppContext.BaseDirectory;
string jsonFilePath = Path.Combine(configFolderPath);
builder.Configuration.AddJsonFile(path: jsonFilePath, optional: true, reloadOnChange: true);

builder.Services.AddDependencyInjection(builder.Configuration);

builder.Services.AddControllers();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
        var seeder = services.GetRequiredService<DatabaseSeeder>();
        await seeder.SeedAsync();
    }
    catch (Exception ex)
    {
        var logger = services.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex.Message);
    }
}

app.UseHttpsRedirection();

app.UseAuthorization();
app.UseMiddleware<ApiKeyMiddleware>();
app.MapControllers();

app.Run();
