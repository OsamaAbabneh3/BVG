﻿using BVG.API.BackGround.Notifications;
using BVG.Application.Common;
using BVG.Application.Configuration;
using BVG.Application.Services;
using BVG.Application.Services.BackgroundJobs;
using BVG.Application.Services.BVGExecute;
using BVG.Application.Services.Email;
using BVG.Application.Services.Email.EmailSender;
using BVG.Application.Services.HealthCheck;
using BVG.Application.Services.Jwt;
using BVG.Application.Services.Notification;
using BVG.Application.Services.Otp;
using BVG.Application.Services.Paginator;
using BVG.Application.Services.Permission;
using BVG.Application.Services.RoleService;
using BVG.Application.Services.Snapshot;
using BVG.Application.Services.UnitOfWork;
using BVG.Application.Strategy;
using BVG.Application.Strategy.Layer.Layers;
using BVG.Application.Strategy.LayerRule;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using BVG.Infrastructure;
using BVG.Infrastructure.Persistence;
using BVG.Infrastructure.Repositories;
using BVG.Infrastructure.Seeders;
using CommonResources.GeneralClasses;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BVG.API.BackGround.Extensions
{
    public static class DependencyInjectionConfiguration
    {
        public static IServiceCollection AddDependencyInjection(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<AppDbContext>(options =>
                options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));

            services.AddDbContext<SnapshotDbContext>(options =>
                options.UseSqlServer(configuration.GetConnectionString("SnapshotConnection")));

            services.AddScoped<IPaginatorService, PaginatorService>();

            services.AddScoped<IAuthService, AuthService>();

            services.AddScoped<IOtpService, OtpService>();
            services.AddScoped<IOtpRepository, OtpRepository>();


            services.AddScoped<IRoleRepository, RoleRepository>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IRuleModeHistoryRepository, RuleModeHistoryRepository>();
            services.AddScoped<ICycleInfoRepository, CycleInfoRepository>();
            services.AddScoped<IInvoiceExceptionRepository, InvoiceExceptionRepository>();
            services.AddScoped<IRuleCatalogRepository, RuleCatalogRepository>();
            services.AddScoped<IRuleFamilyRepository, RuleFamilyRepository>();
            services.AddScoped<IPermissionRepository, PermissionRepository>();
            services.AddScoped<IAuditLogRepository, AuditLogRepository>();

            services.AddScoped<IUnitOfWorkService, UnitOfWorkService>();
            services.AddScoped<IUnitOfWorkRepository, UnitOfWorkRepository>();
            services.AddScoped<ISnapshotBulkRepository, SnapshotBulkRepository>();
            services.AddScoped<ISnapshotBulkService, SnapshotBulkService>();
            services.AddScoped<IRoleService, RoleService>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IRuleModeHistoryService, RuleModeHistoryService>();
            services.AddScoped<ICycleInfoService, CycleInfoService>();
            services.AddScoped<IInvoiceExceptionService, InvoiceExceptionService>();
            services.AddScoped<IRuleCatalogService, RuleCatalogService>();
            services.AddScoped<IRuleFamilyService, RuleFamilyService>();
            services.AddScoped<IPermissionService, PermissionService>();
            services.AddScoped<IAuditLogService, AuditLogService>();
            services.AddScoped<IBVGExecuteService, BVGExecutionService>();

            services.AddScoped<IReportsService, ReportsService>();
            services.AddScoped<IReportsRepository, ReportsRepository>();
            services.AddScoped<AuditStrategy>();
            services.AddScoped<Layer1Strategy>();
            services.AddScoped<Layer2Strategy>();
            services.AddScoped<Layer3Strategy>();
            services.AddScoped<ILayerRuleRunner, LayerRuleRunner>();
            services.AddScoped<IGeneralRepository, GeneralRepository>();
            services.AddScoped<IEmailLogService, EmailLogService>();
            services.AddScoped<IEmailSenderService, EmailSenderService>();
            services.AddSingleton<INotificationRepository, RemoteNotification>();
            services.AddScoped<INotificationService, NotificationService>();
            services.AddScoped<ICycleInfoRuningStatusService, CycleInfoRuningStatusService>();
            services.AddScoped<ICycleInfoRuningStatusRepository, CycleInfoRuningStatusRepository>();
            services.AddScoped<IBackgroundJobRepository, BackgroundJobRepository>();
            services.AddScoped<ISnapshotService, SnapshotService>();
            services.AddScoped<ISnapshotRepository, SnapshotRepository>();
            services.AddScoped<IBackgroundJobService, BackgroundJobService>();
            services.AddScoped<IFingerprintRepository, FingerprintRepository>();
            services.AddScoped<IHealthCheckRepository, HealthCheckRepository>();
            services.AddScoped<IHealthCkeckService, HealthCkeckService>();
            services
                .AddOptions<BackgroundJobOptions>()
                .Bind(configuration.GetSection(BackgroundJobOptions.SectionName))
                .Validate(options => options.MaxAttempts > 0, "MaxAttempts must be greater than zero.")
                .Validate(options => options.LeaseSeconds > 0, "LeaseSeconds must be greater than zero.")
                .Validate(options => options.MaxConcurrentJobs > 0, "MaxConcurrentJobs must be greater than zero.")
                .Validate(options => options.BulkSize > 0, "BulkSize must be greater than zero.")
                .ValidateOnStart();

            services.AddScoped<BackgroundJobHeartbeat>();
            services.AddHostedService<Worker>();
            services.AddScoped<BackgroundJobClaimer>();
            services.AddScoped<BackgroundJobProcessor>();

            services.Configure<GlobalExceptions>(configuration.GetSection("GlobalExceptions"));

            services.AddControllers()
             .ConfigureApiBehaviorOptions(options =>
             {
                 options.InvalidModelStateResponseFactory = context =>
                 {
                     var errors = context.ModelState
                     .Where(x => x.Value?.Errors.Count > 0)
                     .ToDictionary(
                         x => x.Key,
                         x => x.Value!.Errors.Select(e => e.ErrorMessage).ToArray()
                     );
                     var response = BVGResponse<Dictionary<string, string[]>>.Fail(
                         BVGStatusCode.BadRequest,
                         BVGErrorCode.ValidationFaied, errors
                     );
                     return new ObjectResult(response)
                     {
                         StatusCode = response.StatusCode
                     };
                 };
             });

            services.AddHttpContextAccessor();
            services.AddLocalization();
            services.AddProblemDetails();
            services.AddSwaggerGen();
            services.AddScoped<RequestHeadersModel>();
            services.AddScoped<DatabaseSeeder>();
            services.AddHttpClient<ISmsSender, SmsSender>(c => c.Timeout = TimeSpan.FromSeconds(10));
            services.Configure<SnapshotOptions>(configuration.GetSection("SnapshotOptions"));
            services.AddScoped<IEmailLogService, EmailLogService>();
            services.AddScoped<IEmailLogRepository, EmailLogRepository>();
            services.Configure<DynamicPull>(configuration.GetSection("DynamicPull"));
            return services;
        }
    }
}
