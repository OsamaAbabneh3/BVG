﻿using BVG.Application.Services.HealthCheck;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace BVG.API.BackGround.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HealthCheckController : BaseApiController
    {
        private readonly IHealthCkeckService _healthCkeckService;

        public HealthCheckController(IHealthCkeckService healthCkeckService)
        {
            _healthCkeckService = healthCkeckService;
        }

        [HttpPost]
        public async Task<IActionResult> HealthCheck()
        {
            var result = await _healthCkeckService.HealthCheck();
            return Send(result);
        }
    }
}
