﻿using BVG.Application.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.BackGround.Controllers
{
    [ApiController]
    public class BaseApiController : ControllerBase
    {
        protected IActionResult Send<T>(BVGResponse<T> response)
        {
            return StatusCode(response.StatusCode, response);
        }
    }
}
