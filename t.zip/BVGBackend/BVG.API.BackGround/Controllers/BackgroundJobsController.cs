﻿using BVG.Application.Services.BackgroundJobs;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.BackGround.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BackgroundJobsController : BaseApiController
    {
        private readonly IBackgroundJobService _backgroundJobService;

        public BackgroundJobsController(IBackgroundJobService backgroundJobService)
        {
            _backgroundJobService = backgroundJobService;
        }

        [HttpPost("start-bvg")]
        public async Task<IActionResult> Enqueue(CancellationToken cancellationToken)
        {
            var result = await _backgroundJobService.EnqueueAsync(cancellationToken);
            return Send(result);
        }
    }
}
