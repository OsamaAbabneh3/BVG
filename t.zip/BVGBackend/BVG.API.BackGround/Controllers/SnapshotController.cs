﻿using BVG.Application.Services.Snapshot;
using BVG.Domain.DTOs;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.BackGround.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SnapshotController : BaseApiController
    {
        private readonly ISnapshotService _snapshotService;

        public SnapshotController(ISnapshotService snapshotService)
        {
            _snapshotService = snapshotService;
        }

        [HttpPost("pull")]
        public async Task<IActionResult> PullSnapshot(CancellationToken cancellationToken)
        {
            var result = await _snapshotService.TakeSnapshot(cancellationToken);
            return Send(result);
        }
    }
}
