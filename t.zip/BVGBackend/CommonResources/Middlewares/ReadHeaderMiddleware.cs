﻿using CommonResources.GeneralClasses;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace CommonResources.Middlewares
{
    public class ReadHeaderMiddleware
    {
        private readonly RequestDelegate _next;

        public ReadHeaderMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext httpContext, RequestHeadersModel headersModel)
        {
            headersModel.Authorization = httpContext.Request.Headers["Authorization"].ToString();
            headersModel.AcceptLanguage = httpContext.Request.Headers["Accept-Language"].ToString();
            headersModel.Cookie = httpContext.Request.Headers["Cookie"].ToString();
            headersModel.XForwardedFor = httpContext.Request.Headers["X-Forwarded-For"].ToString();
            headersModel.XForwardedProto = httpContext.Request.Headers["X-Forwarded-Proto"].ToString();
            await _next(httpContext);
        }
    }
}
