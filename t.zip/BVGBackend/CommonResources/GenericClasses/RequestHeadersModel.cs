﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonResources.GeneralClasses
{
    public class RequestHeadersModel
    {
        public string? Authorization { get; set; }
        public string? Cookie { get; set; }
        public string? AcceptLanguage { get; set; }
        public string? XForwardedFor { get; set; }
        public string? XForwardedProto { get; set; }
    }
}
