﻿using BVG.Application.Common;
using System;
using System.Collections.Generic;
using System.Net.Http.Json;
using System.Text;

namespace SDK
{
    public class BVGBackgroundClient
    {
        private readonly HttpClient _httpClient;

        public BVGBackgroundClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<BVGResponse<T>> PostAsync<T>(string url,object? body,CancellationToken cancellationToken = default)
        {
            var response = await _httpClient.PostAsJsonAsync(url,body,cancellationToken);

            var result = await response.Content.ReadFromJsonAsync<BVGResponse<T>>(cancellationToken: cancellationToken);

            if (result is null)
                throw new Exception("Invalid API response");

            if (result.Data is BVGResponse<T> nestedResponse)
                return nestedResponse;

            return result;
        }


    }
}
