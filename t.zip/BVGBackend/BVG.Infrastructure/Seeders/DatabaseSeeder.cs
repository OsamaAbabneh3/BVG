﻿using BVG.Application.Services.UnitOfWork;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Persistence;
using BVG.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
namespace BVG.Infrastructure.Seeders
{
    public class DatabaseSeeder
    {
        private readonly AppDbContext _dbContext;
        private readonly IUnitOfWorkRepository _unitOfWorkRepository;

        public DatabaseSeeder(AppDbContext dbContext, IUnitOfWorkRepository unitOfWorkRepository)
        {
            _dbContext = dbContext;
            _unitOfWorkRepository = unitOfWorkRepository;
        }

        public async Task SeedAsync()
        {
            try
            {
                await _dbContext.Database.EnsureCreatedAsync();

                await _unitOfWorkRepository.BeginTransactionAsync();

                if (!await _dbContext.Permissions.AnyAsync())
                {
                    await _dbContext.Permissions.AddRangeAsync(new List<Permission>
                {
                    new Permission
                    {
                        PermissionName = PermissionsEnum.CreateUser.ToString(),
                        NameAr = "إنشاء مستخدم جديد",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.UpdateUser.ToString(),
                        NameAr = "تعديل بيانات المستخدم",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.GetAllUsers.ToString(),
                        NameAr = "إسترجاع بيانات جميع المستخدمين",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.GetUser.ToString(),
                        NameAr = "إسترجاع بيانات مستخدم محدد",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.CreateRole.ToString(),
                        NameAr = "إنشاء دور جديد",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.GetAllRoles.ToString(),
                        NameAr = "إسترجاع جميع الأدوار",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.GetAllRuleCataloges.ToString(),
                        NameAr = "إسترجاع جميع قواعد التدقيق",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.GetRuleCatalog.ToString(),
                        NameAr = "إسترجاع قاعدة تدقيق محددة",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.CreateRuleCatalog.ToString(),
                        NameAr = "إنشاء قاعدة تدقيق محددة",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.UpdateRuleCatalog.ToString(),
                        NameAr = "تعديل قاعدة تدقيق",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.DeleteRuleCatalog.ToString(),
                        NameAr = "حذف قاعدة تدقيق",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.ToggleBlock.ToString(),
                        NameAr = "حظر / إلغاء حظر للمستخدمين",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.GetAllPermissions.ToString(),
                        NameAr = "إسترجاع جميع الصلاحيات",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.AssignPermissionsToRole.ToString(),
                        NameAr = "تعيين صلاحيات للدور",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.AssignRolesToUser.ToString(),
                        NameAr = "تعيين دور للمستخدم",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.GetAuditLog.ToString(),
                        NameAr = "إسترجاع سجل التدقيق",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.GetAllRuleFamily.ToString(),
                        NameAr = "إسترجاع جميع أنواع قواعد التدقيق",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.DeleteRuleFamily.ToString(),
                        NameAr = "حذف نوع قاعدة تدقيق",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.CreateRuleFamily.ToString(),
                        NameAr = "إنشاء نوع قاعدة تدقيق",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.DeleteRole.ToString(),
                        NameAr = "حذف دور",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.Unlocked.ToString(),
                        NameAr = "الغاء قفل المستخدم",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.GetRuleFamily.ToString(),
                        NameAr = "استرجاع نوع قاعدة تدقيق",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.UpdateRuleFamily.ToString(),
                        NameAr = "تعديل نوع قاعدة تدقيق",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.UpdateRole.ToString(),
                        NameAr = "تعديل دور",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.DecisionDualAuthorizationApproval.ToString(),
                        NameAr = "اضافة قرار",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.GetAllRuleModeHistory.ToString(),
                        NameAr = "استرجاع سجل كامل لأنماط القواعد",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                    {
                        PermissionName = PermissionsEnum.GetAllFingerprint.ToString(),
                        NameAr = "استرجاع جميع بصمات كامل لأنماط القواعد",
                        CreatedAt = DateTime.UtcNow,
                    },
                    new Permission
                         {
                        PermissionName = PermissionsEnum.AddRuleModeHistory.ToString(),
                        NameAr = "إضافة سجل تغيير نمط تشغيل قاعدة التدقيق",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.AddCycleInfo.ToString(),
                        NameAr = "إضافة دورة فوترة",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.GetByIdRuleModeHistory.ToString(),
                        NameAr = "استرجاع سجل تغيير نمط تشغيل قاعدة تدقيق محدد",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.AddDualAuthorizationRequestAndApproval.ToString(),
                        NameAr = "إنشاء طلب تفويض مزدوج وسجلات الموافقة المرتبطة به",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.GetAllDualAuthorizationRequest.ToString(),
                        NameAr = "استرجاع جميع طلبات التفويض المزدوج",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.UpdateDualAuthorizationRequest.ToString(),
                        NameAr = "تعديل طلب التفويض المزدوج",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.GetByIdSnapshotBulk.ToString(),
                        NameAr = "استرجاع دفعة محددة من بيانات لقطة الفواتير",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.UpdateCycleInfo.ToString(),
                        NameAr = "تعديل بيانات دورة الفوترة",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.GetByIdDualAuthorizationRequest.ToString(),
                        NameAr = "استرجاع طلب تفويض مزدوج محدد",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.GetAllCycleInfo.ToString(),
                        NameAr = "استرجاع جميع دورات الفوترة",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.GetAllDualAuthorizationApprovalByUserId.ToString(),
                        NameAr = "استرجاع جميع سجلات موافقة التفويض المزدوج الخاصة بمستخدم محدد",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.GetByIdDualAuthorizationApproval.ToString(),
                        NameAr = "استرجاع سجل موافقة تفويض مزدوج محدد",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.GetAllDualAuthorizationApproval.ToString(),
                        NameAr = "استرجاع جميع سجلات موافقة التفويض المزدوج",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.UpdateInvoiceException.ToString(),
                        NameAr = "تعديل استثناء تدقيق الفاتورة",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.GetByIdInvoiceException.ToString(),
                        NameAr = "استرجاع استثناء تدقيق فاتورة محدد",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.GetAllInvoiceException.ToString(),
                        NameAr = "استرجاع جميع استثناءات تدقيق الفواتير",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.AddInvoiceException.ToString(),
                        NameAr = "إضافة استثناء تدقيق فاتورة",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.GetByIdCycleInfo.ToString(),
                        NameAr = "استرجاع بيانات دورة فوترة محددة",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.UpdateSnapshotBulk.ToString(),
                        NameAr = "تعديل دفعة بيانات لقطة الفواتير",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.GetByIdFingerprint.ToString(),
                        NameAr = "استرجاع بصمة تحقق محددة لبيانات لقطة الفواتير",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.UpdateFingerprint.ToString(),
                        NameAr = "تعديل بصمة التحقق لبيانات لقطة الفواتير",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.AddFingerprint.ToString(),
                        NameAr = "إضافة بصمة تحقق لبيانات لقطة الفواتير",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.GetAllSnapshotBulk.ToString(),
                        NameAr = "استرجاع جميع دفعات بيانات لقطة الفواتير",
                        CreatedAt = DateTime.UtcNow,
                    },
                     new Permission
                         {
                        PermissionName = PermissionsEnum.ExportCycleSummaryReport.ToString(),
                        NameAr = "تصدير تقرير ملخص الدورة",
                        CreatedAt = DateTime.UtcNow,
                    },
                });
                    await _dbContext.SaveChangesAsync();
                }

                if (!await _dbContext.Roles.AnyAsync())
                {
                    await _dbContext.Roles.AddAsync(new Role
                    {
                        RoleName = RoleEnum.Admin.ToString().ToUpper(),
                        NameAr = "مسؤول النظام",
                        CreatedAt = DateTime.UtcNow
                    });
                    await _dbContext.SaveChangesAsync();
                }

                if (!await _dbContext.RolePermissions.AnyAsync())
                {
                    var permissins = await _dbContext.Permissions.ToListAsync();
                    var adminRole = await _dbContext.Roles.FirstOrDefaultAsync(r => r.RoleName.ToUpper() == RoleEnum.Admin.ToString().ToUpper());

                    if (adminRole != null && permissins.Any())
                    {
                        var rolePermissions = new List<RolePermission>();
                        foreach (var permission in permissins)
                        {
                            rolePermissions.Add(new RolePermission
                            {
                                RoleId = adminRole.Id,
                                PermissionId = permission.Id,
                                AssignedAt = DateTime.UtcNow,
                            });
                        }
                        await _dbContext.AddRangeAsync(rolePermissions);
                        await _dbContext.SaveChangesAsync();
                    }
                }

                if (!await _dbContext.BvgUsers.AnyAsync())
                {
                    await _dbContext.BvgUsers.AddAsync(new BvgUser
                    {
                        UserName = "ADMIN",
                        FirstName = "System",
                        LastName = "Administrator",
                        Email = "ADMIN@ADMIN.ADMIN",
                        CreatedAt = DateTime.UtcNow,
                        PasswordHash = "AQAAAAIAAYagAAAAECk/aDewSgX+cHFaCsm8OY78epGnoyrjlo/TSInurxMMVo8JwvYIps/unvoad2u/lA==",
                        PhoneNumber = "0799999999",
                        MustChangePassword = true,
                    });
                    await _dbContext.SaveChangesAsync();
                }

                if (!await _dbContext.UserRoles.AnyAsync())
                {
                    var adminUser = await _dbContext.BvgUsers.FirstOrDefaultAsync(u => u.UserName == "ADMIN");
                    var adminRole = await _dbContext.Roles.FirstOrDefaultAsync(r => r.RoleName == RoleEnum.Admin.ToString().ToUpper());
                    if (adminUser != null && adminRole != null)
                    {
                        await _dbContext.UserRoles.AddAsync(new UserRole
                        {
                            UserId = adminUser.Id,
                            RoleId = adminRole.Id,
                            AssignedAt = DateTime.UtcNow
                        });
                        await _dbContext.SaveChangesAsync();
                    }
                }

                await CreateStoredProcedureAsync();

                await SeedRuleCatalogAsync();

                await _unitOfWorkRepository.CommitAsync();
            }
            catch
            {
                await _unitOfWorkRepository.RollbackAsync();
            }
        }

        private async Task CreateStoredProcedureAsync()
        {
            var sqlText =
                """"
        CREATE OR ALTER PROCEDURE [dbo].[ClaimNextBackgroundJob]
            @WorkerId NVARCHAR(100),
            @LeaseSeconds INT = 300,
            @MaxAttempts INT = 3
        AS
        BEGIN
            SET ANSI_NULLS ON;
            SET QUOTED_IDENTIFIER ON;
            SET NOCOUNT ON;
            SET XACT_ABORT ON;

            IF @LeaseSeconds <= 0
                THROW 50001, 'LeaseSeconds must be greater than zero.', 1;

            IF @MaxAttempts <= 0
                THROW 50004, 'MaxAttempts must be greater than zero.', 1;

            DECLARE @Now DATETIME2 = SYSUTCDATETIME();

            ;WITH NextJob AS
            (
                SELECT TOP (1) *
                FROM dbo.BackgroundJobs WITH (UPDLOCK, READPAST, ROWLOCK)
                WHERE
                    (
                        Status = 0
                        OR
                        (
                            Status = 1
                            AND LockedUntil <= @Now
                        )
                    )
                    AND AttemptCount < @MaxAttempts
                ORDER BY Priority DESC, CreatedAt ASC, Id ASC
            )
            UPDATE NextJob
            SET
                Status = 1,
                WorkerId = @WorkerId,
                StartedAt = @Now,
                LockedUntil = DATEADD(SECOND, @LeaseSeconds, @Now),
                AttemptCount = AttemptCount + 1
            OUTPUT
                inserted.Id,
                inserted.BatchRunId,
                inserted.StartInvoiceId,
                inserted.EndInvoiceId,
                inserted.Status,
                inserted.AttemptCount,
                inserted.WorkerId,
                inserted.LockedUntil,
                inserted.SnapshotBulkId;
        END;
        ---END_OF_BATCH---
        CREATE OR ALTER PROCEDURE [dbo].[CompleteBackgroundJob]
            @JobId BIGINT,
            @WorkerId NVARCHAR(100)
        AS
        BEGIN
            SET ANSI_NULLS ON;
            SET QUOTED_IDENTIFIER ON;
            SET NOCOUNT ON;
            SET XACT_ABORT ON;

            UPDATE dbo.BackgroundJobs
            SET
                Status = 2,
                CompletedAt = SYSUTCDATETIME(),
                WorkerId = NULL,
                LockedUntil = NULL,
                ErrorMessage = NULL
            WHERE Id = @JobId
              AND Status = 1
              AND WorkerId = @WorkerId;

            IF @@ROWCOUNT = 0
                THROW 50002, 'Background job was not found or is not owned by this worker.', 1;
        END;
        ---END_OF_BATCH---
        CREATE OR ALTER PROCEDURE [dbo].[FailBackgroundJob]
            @JobId BIGINT,
            @WorkerId NVARCHAR(100),
            @ErrorMessage NVARCHAR(MAX),
            @MaxAttempts INT
        AS
        BEGIN
            SET ANSI_NULLS ON;
            SET QUOTED_IDENTIFIER ON;
            SET NOCOUNT ON;
            SET XACT_ABORT ON;

            IF @MaxAttempts <= 0
                THROW 50006, 'MaxAttempts must be greater than zero.', 1;

            UPDATE dbo.BackgroundJobs
            SET
                Status = CASE
                    WHEN AttemptCount >= @MaxAttempts THEN 3
                    ELSE 0
                END,
                ErrorMessage = @ErrorMessage,
                LockedUntil = NULL,
                WorkerId = NULL
            WHERE Id = @JobId
              AND Status = 1
              AND WorkerId = @WorkerId;

            IF @@ROWCOUNT = 0
                THROW 50003, 'Background job was not found or is not owned by this worker.', 1;
        END;
        ---END_OF_BATCH---
        CREATE OR ALTER PROCEDURE [dbo].[FailExpiredBackgroundJobs]
            @MaxAttempts INT
        AS
        BEGIN
            SET ANSI_NULLS ON;
            SET QUOTED_IDENTIFIER ON;
            SET NOCOUNT ON;
            SET XACT_ABORT ON;

            IF @MaxAttempts <= 0
                THROW 50005, 'MaxAttempts must be greater than zero.', 1;

            DECLARE @Now DATETIME2 = SYSUTCDATETIME();

            UPDATE dbo.BackgroundJobs
            SET
                Status = 3,
                LockedUntil = NULL,
                ErrorMessage = N'Maximum attempts exceeded after lease expiration.'
            WHERE Status = 1
              AND LockedUntil <= @Now
              AND AttemptCount >= @MaxAttempts;
        END;
        ---END_OF_BATCH---
        CREATE OR ALTER PROCEDURE [dbo].[RenewBackgroundJobLease]
            @JobId BIGINT,
            @WorkerId NVARCHAR(100),
            @LeaseSeconds INT
        AS
        BEGIN
            SET ANSI_NULLS ON;
            SET QUOTED_IDENTIFIER ON;
            SET NOCOUNT ON;
            SET XACT_ABORT ON;

            IF @LeaseSeconds <= 0
                THROW 50007, 'LeaseSeconds must be greater than zero.', 1;

            UPDATE dbo.BackgroundJobs
            SET
                LockedUntil = DATEADD(
                    SECOND,
                    @LeaseSeconds,
                    SYSUTCDATETIME()
                )
            WHERE Id = @JobId
              AND Status = 1
              AND WorkerId = @WorkerId
              AND LockedUntil > SYSUTCDATETIME();

            IF @@ROWCOUNT = 0
                THROW 50008, 'Cannot renew lease. Job is not owned or lease has expired.', 1;
        END;
        """";

            var batches = sqlText.Split(new[] { "---END_OF_BATCH---" }, StringSplitOptions.RemoveEmptyEntries);

            foreach (var batch in batches)
            {
                if (!string.IsNullOrWhiteSpace(batch))
                {
                    await _dbContext.Database.ExecuteSqlRawAsync(batch);
                }
            }
        }

        private async Task SeedRuleCatalogAsync()
        {
            if (!await _dbContext.RuleFamilies.AnyAsync() && !await _dbContext.RuleCatalogs.AnyAsync())
            {
                var family = await _dbContext.RuleFamilies.AddAsync(new RuleFamily
                {
                    FamilyName = "Fixed and Derived Lines Family",
                    CreatedAt = DateTime.UtcNow,
                    RuleFamilyCode = "FXD"
                });

                await _dbContext.SaveChangesAsync();

                var sqlText = """
                                        WITH
                    -- 1) أنواع الاشتراكات الموجودة في الفواتير
                    bill_types AS (
                        SELECT DISTINCT
                            f.SubscriptionTypeId,
                            ISNULL(f.IsTimeOfUseTariffApplied, 0) AS TOU_FLAG
                        FROM dbo.FullSnapshot f
                        WHERE TRY_CONVERT(INT, f.InvoiceStatus) <= 3
                          AND f.SubscriptionTypeId IS NOT NULL
                    ),

                    -- 2) المراجع المطلوبة حسب أنواع الفواتير
                    required_refs AS (

                        -- التعرفة العادية
                        SELECT
                            'SubscriptionPricesVersion' AS REF_TABLE,
                            b.SubscriptionTypeId,
                            CAST('' AS NVARCHAR(10)) AS TARIFF_TYPE
                        FROM bill_types b
                        WHERE b.TOU_FLAG = 0

                        UNION

                        -- التعرفة الزمنية: أربع فترات لكل نوع
                        SELECT
                            'TouPriceVersions',
                            b.SubscriptionTypeId,
                            w.TariffType
                        FROM bill_types b
                        CROSS JOIN (
                            VALUES ('1'), ('2'), ('3'), ('4')
                        ) w(TariffType)
                        WHERE b.TOU_FLAG = 1

                        UNION

                        -- الرسوم
                        SELECT
                            'TaxVersions',
                            b.SubscriptionTypeId,
                            ''
                        FROM bill_types b

                        UNION

                        -- الدعم للأنواع 60 و61
                        SELECT
                            'GovernmentSupportVersions',
                            b.SubscriptionTypeId,
                            ''
                        FROM bill_types b
                        JOIN dbo.SubscriptionTypes st
                            ON st.Id = b.SubscriptionTypeId
                        WHERE st.BillKindId IN (60, 61)
                    ),

                    -- 3) المراجع الفعالة الموجودة في BVG
                    ref_rows AS (

                        SELECT
                            'SubscriptionPricesVersion' AS REF_TABLE,
                            SubscriptionTypeId,
                            CAST('' AS NVARCHAR(10)) AS TARIFF_TYPE,
                            CAST(VersionStartDate AS DATE) AS VALID_FROM,
                            CAST(VersionEndDate AS DATE) AS VALID_TO,
                            Id AS ROW_ID
                        FROM dbo.SubscriptionPricesVersion

                        UNION ALL

                        SELECT
                            'TouPriceVersions',
                            SubscriptionTypeId,
                            CAST(TariffType AS NVARCHAR(10)),
                            CAST(VersionStartDate AS DATE),
                            CAST(VersionEndDate AS DATE),
                            Id
                        FROM dbo.TouPriceVersions

                        UNION ALL

                        SELECT
                            'TaxVersions',
                            SubscriptionTypeId,
                            '',
                            CAST(VersionStartDate AS DATE),
                            CAST(VersionEndDate AS DATE),
                            Id
                        FROM dbo.TaxVersions

                        UNION ALL

                        SELECT
                            'GovernmentSupportVersions',
                            SubscriptionTypeId,
                            '',
                            CAST(VersionStartDate AS DATE),
                            CAST(VersionEndDate AS DATE),
                            Id
                        FROM dbo.GovernmentSupportVersions
                    ),

                    -- 4) المراجع المفقودة
                    missing_refs AS (
                        SELECT
                            q.REF_TABLE,
                            q.SubscriptionTypeId
                        FROM required_refs q
                        WHERE NOT EXISTS (
                            SELECT 1
                            FROM ref_rows r
                            WHERE r.REF_TABLE = q.REF_TABLE
                              AND r.SubscriptionTypeId = q.SubscriptionTypeId
                              AND r.TARIFF_TYPE = q.TARIFF_TYPE
                        )
                    ),

                    -- 5) الإصدارات المتداخلة
                    overlap_refs AS (
                        SELECT DISTINCT
                            a.REF_TABLE,
                            a.SubscriptionTypeId
                        FROM ref_rows a
                        JOIN ref_rows b
                            ON b.REF_TABLE = a.REF_TABLE
                           AND b.SubscriptionTypeId = a.SubscriptionTypeId
                           AND b.TARIFF_TYPE = a.TARIFF_TYPE
                           AND b.ROW_ID > a.ROW_ID
                           AND a.VALID_FROM <= b.VALID_TO
                           AND b.VALID_FROM <= a.VALID_TO

                        WHERE EXISTS (
                            SELECT 1
                            FROM required_refs q
                            WHERE q.REF_TABLE = a.REF_TABLE
                              AND q.SubscriptionTypeId = a.SubscriptionTypeId
                              AND q.TARIFF_TYPE = a.TARIFF_TYPE
                        )
                    ),

                    -- 6) تجميع الاستثناءات
                    issues AS (
                        SELECT
                            REF_TABLE,
                            SubscriptionTypeId
                        FROM missing_refs

                        UNION ALL

                        SELECT
                            REF_TABLE,
                            SubscriptionTypeId
                        FROM overlap_refs
                    )

                    -- 7) النتيجة النهائية: BillKindId
                    SELECT DISTINCT
                        i.REF_TABLE,
                        st.BillKindId
                    FROM issues i
                    LEFT JOIN dbo.SubscriptionTypes st
                        ON st.Id = i.SubscriptionTypeId



                    -- Temporary exclusions: BillKindId 25 from SubscriptionPricesVersion
                    -- and BillKindId 4 from TouPriceVersions, pending further review

                     where not( (i.REF_TABLE = 'SubscriptionPricesVersion' AND st.BillKindId = 25) or (i.REF_TABLE = 'TouPriceVersions'and st.BillKindId = 4) );
                    """;

                var ruleCatalog = await _dbContext.RuleCatalogs.AddAsync(new RuleCatalog
                {
                    RuleCode = "00",
                    RuleName = "Reference-version integrity",
                    Description = null,
                    FamilyId = family.Entity.Id,
                    Severity = (byte)SeverityEnum.Critical,
                    QuerySql = sqlText,
                    AlertBudget = 0,
                    Mode = (byte)ModeEnum.Enforce,
                    Layer = 0,
                    Version = "1",
                    IsActive = true,
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = null,
                });
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}
