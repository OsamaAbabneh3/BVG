﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Common;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class RuleFamilyRepository : IRuleFamilyRepository
    {
        private readonly AppDbContext _context;

        public RuleFamilyRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<RuleFamily?> GetByIdRuleFamily(long id, CancellationToken cancellationToken)
        {
            var ruleFamily = await _context.RuleFamilies.FindAsync(id, cancellationToken);
            return ruleFamily;
        }
        public async Task<RuleFamily> CreateRuleFamily(RuleFamily ruleFamily, CancellationToken cancellationToken)
        {
            await _context.RuleFamilies.AddAsync(ruleFamily, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);
            return ruleFamily;
        }
        public async Task UpdateRuleFamily(RuleFamily ruleFamily, CancellationToken cancellationToken)
        {
            _context.Update(ruleFamily);
            await _context.SaveChangesAsync(cancellationToken);
        }

        public IQueryable<RuleFamily> Query(FilterOptionsDto filterOptions)
        {
            return _context.RuleFamilies
                .AsNoTracking()
                .ApplyDynamicFilters(filterOptions)
                .AsQueryable();
        }

        public async Task DeleteRuleFamily(long id, CancellationToken cancellationToken)
        {
            var ruleFamily = await _context.RuleFamilies.FindAsync(id, cancellationToken);
            if (ruleFamily != null)
            {
                _context.RuleFamilies.Remove(ruleFamily);
                await _context.SaveChangesAsync(cancellationToken);
            }
        }

        public async Task<IEnumerable<RuleFamily>> GetAllRuleFamily(CancellationToken cancellationToken)
        {
            return await _context.RuleFamilies
                .Include(r => r.RuleCatalogs)
                .ToListAsync(cancellationToken);
        }

        public async Task<RuleFamily?> getByIdRuleFamily(long id, CancellationToken cancellationToken)
        {
            return await _context.RuleFamilies
                .Include(r => r.RuleCatalogs)
                .FirstOrDefaultAsync(r => r.Id == id, cancellationToken);


        }

        public async Task<bool> IsRuleFamilyLinkedToRuleCatalog(long ruleFamilyId, CancellationToken cancellationToken)
        {

            return await _context.RuleCatalogs.AnyAsync(rc => rc.Family.Id == ruleFamilyId, cancellationToken);
 
        }

        public async Task<bool> IsValidRuleNameAsync(string ruleName, CancellationToken cancellationToken)
        {
            return await _context.RuleFamilies.AnyAsync(r=>r.FamilyName.ToLower() == ruleName.ToLower(), cancellationToken);
        }

        public async Task<bool> IsValidRuleCodeAsync(string ruleCode,CancellationToken cancellationToken) 
        {
            return await _context.RuleFamilies.AnyAsync(r => r.RuleFamilyCode.ToLower() == ruleCode.ToLower(), cancellationToken);
        }

        public async Task<string> GetCodyByruleFamilyId(long ruleFamilyId, CancellationToken cancellationToken)
        {
            return await _context.RuleCatalogs
                .Where(r => r.FamilyId == ruleFamilyId)
                .OrderByDescending(r => r.Id)
                .Select(r => r.RuleCode)
                .FirstOrDefaultAsync() ?? "0";
        }
    }
}
