﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Common;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class FingerprintRepository : IFingerprintRepository
    {
        private readonly AppDbContext _context;
        public FingerprintRepository(AppDbContext context)
        {
            _context = context;
        }
        public async Task<Fingerprint> AddFingerprint(Fingerprint fingerprint, CancellationToken cancellationToken)
        {
            await _context.Fingerprints.AddAsync(fingerprint);
            await _context.SaveChangesAsync(cancellationToken);
            return fingerprint;
        }
        public async Task<Fingerprint?> GetByIdFingerprint(long id, CancellationToken cancellationToken)
        {
            var fingerprint = await _context.Fingerprints.FindAsync(id, cancellationToken);
            return fingerprint;
        }
        public async Task UpdateFingerprint(Fingerprint fingerprint, CancellationToken cancellationToken)
        {
            _context.Update(fingerprint);
            await _context.SaveChangesAsync(cancellationToken);
        }

        public async Task<IEnumerable<Fingerprint>> GetAllFingerprints(CancellationToken cancellationToken)
        {
            return await _context.Fingerprints
                .Include(r => r.SnapshotBulk)
                .ToListAsync(cancellationToken);

        
        }
        public IQueryable<Fingerprint> Query(FilterOptionsDto filterOptions)
        {
            return _context.Fingerprints
                .AsNoTracking()
                .ApplyDynamicFilters(filterOptions)
                .AsQueryable();
        }
        public async Task<Fingerprint?> GetBySnapshotBulkIdAsync(long snapshotBulkId, CancellationToken cancellationToken)
        {
            return await _context.Fingerprints
                .AsNoTracking()
                .SingleOrDefaultAsync(
                    x => x.SnapshotBulkId == snapshotBulkId, cancellationToken);
        }

        public async Task<long> CountAsync(Expression<Func<Fingerprint, bool>> expression)
        {
            return await _context.Fingerprints
                .Where(expression)
                .CountAsync();
        }

        public async Task<List<Fingerprint>> WhereAsync(Expression<Func<Fingerprint, bool>> expression)
        {
            return await _context.Fingerprints.Where(expression).ToListAsync();
        }
    }
}
