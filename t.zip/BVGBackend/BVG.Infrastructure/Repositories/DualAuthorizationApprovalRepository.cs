﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Common;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class DualAuthorizationApprovalRepository : IDualAuthorizationApprovalRepository
    {
        private readonly AppDbContext _context;
        public DualAuthorizationApprovalRepository(AppDbContext context)
        {
            _context = context;
        }
        public async Task <DualAuthorizationApproval> AddDualAuthorizationApproval(DualAuthorizationApproval dualAuthorizationApproval, CancellationToken cancellationToken)
        {
            await _context.DualAuthorizationApprovals.AddAsync(dualAuthorizationApproval);
            await _context.SaveChangesAsync(cancellationToken);
            return dualAuthorizationApproval;
        }
        public async Task<DualAuthorizationApproval?> GetByIdDualAuthorizationApproval(long id, CancellationToken cancellationToken)
        {
            var dualAuthorizationApproval = await _context.DualAuthorizationApprovals.FindAsync(id, cancellationToken);
            return dualAuthorizationApproval;
        }
        public async Task UpdateDualAuthorizationApproval(DualAuthorizationApproval dualAuthorizationApproval, CancellationToken cancellationToken)
        {
            _context.Update(dualAuthorizationApproval);
            await _context.SaveChangesAsync(cancellationToken);
        }
        public async Task<List<DualAuthorizationApproval>> GetAllDualAuthorizationApproval(CancellationToken cancellationToken)
        {
            return await _context.DualAuthorizationApprovals
                .Include(d => d.ApproverUser)
                .Include(i => i.DualAuthorizationRequest)
                .ToListAsync();


        }
        public IQueryable<DualAuthorizationApproval> Query(FilterOptionsDto filterOptions)
        {
            return _context.DualAuthorizationApprovals
                .AsNoTracking()
                .ApplyDynamicFilters(filterOptions)
                .AsQueryable();
        }
        public async Task<bool> IsDuplicate(long DualAuthorizationRequestId, Guid ApproverUserId, CancellationToken cancellationToken)
        {
            return await _context.DualAuthorizationApprovals.AnyAsync(i => i.DualAuthorizationRequestId == DualAuthorizationRequestId && i.ApproverUserId == ApproverUserId, cancellationToken);
        }
        public async Task<DualAuthorizationApproval?> GetByRequestAndApproverAsync(long dualAuthorizationRequestId,Guid approverUserId, CancellationToken cancellationToken)
        {
                 return await _context.DualAuthorizationApprovals
                .AsNoTracking()
                .FirstOrDefaultAsync(x =>
                                     x.DualAuthorizationRequestId == dualAuthorizationRequestId &&
                                     x.ApproverUserId == approverUserId, cancellationToken);
        }
        public async Task<List<Guid>> GetAuthorizedApproverUserIdsAsync(CancellationToken cancellationToken)
        {
            return await _context.UserRoles
                .Where(ur =>
                    ur.UserId.HasValue &&
                    ur.User != null &&
                    !ur.User.IsBlocked &&
                    ur.Role != null &&
                    ur.Role.RolePermissions.Any(rp =>
                        rp.Permission != null &&
                        rp.Permission.PermissionName == PermissionsEnum.DecisionDualAuthorizationApproval.ToString()))
                .Select(ur => ur.UserId!.Value)
                .Distinct()
                .ToListAsync();
        }
    }
}
