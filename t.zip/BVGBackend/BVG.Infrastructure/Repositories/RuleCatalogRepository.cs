﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Common;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Text.Json;

namespace BVG.Infrastructure.Repositories
{
    public class RuleCatalogRepository : IRuleCatalogRepository
    {
        private readonly AppDbContext _context;
        private readonly SnapshotDbContext _snapshotDbContext;

        public RuleCatalogRepository(AppDbContext context, SnapshotDbContext snapshotDbContext) 
        {
            _context = context;
            _snapshotDbContext = snapshotDbContext;
        }
        public async Task<IEnumerable<RuleCatalog>> GetAllRuleCatalog(CancellationToken cancellationToken)
        {
            return await _context.RuleCatalogs
                .Include(r => r.Family)
                .Include(r => r.InvoiceExceptions)
                .Include(r => r.RuleModeHistories)
                .ToListAsync();

        }

        public async Task<RuleCatalog?> GetByIdRuleCatalog(long id, CancellationToken cancellationToken)
        {
            return await _context.RuleCatalogs
                .Include(r => r.Family)
                 .Include(r => r.InvoiceExceptions)
                 .Include(r => r.RuleModeHistories)
                .FirstOrDefaultAsync(r => r.Id == id);

        }
        public async Task<RuleCatalog> CreateRuleCatalog(RuleCatalog ruleCatalog, CancellationToken cancellationToken)
        {
            await _context.RuleCatalogs.AddAsync(ruleCatalog, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);
            return ruleCatalog;
        }
        public async Task UpdateRuleCatalog(RuleCatalog ruleCatalog, CancellationToken cancellationToken)
        {
            _context.Update(ruleCatalog);
            await _context.SaveChangesAsync(cancellationToken);
        }
        public IQueryable<RuleCatalog> Query(FilterOptionsDto filterOptions)
        {
            return _context.RuleCatalogs
                .AsNoTracking()
                .Include(r => r.Family)
                .ApplyDynamicFilters(filterOptions)
                .AsQueryable();
        }
        public async Task DeleteRuleCatalog(long id, CancellationToken cancellationToken)
        {
            var ruleCatalog = await _context.RuleCatalogs.FindAsync(id, cancellationToken);
            if (ruleCatalog != null)
            {
                _context.RuleCatalogs.Remove(ruleCatalog);
                await _context.SaveChangesAsync(cancellationToken);
            }
        }
        public async Task<bool> IsDuplicate(string ruleCode, CancellationToken cancellationToken)
        {
            return await _context.RuleCatalogs.AnyAsync(i => i.RuleCode == ruleCode);
        }

        public async Task<IEnumerable<RuleCatalog>> GetRuleByLayer(byte layer, CancellationToken cancellationToken)
        {
            return await _context.RuleCatalogs.Where(i => i.Layer == layer).ToListAsync(cancellationToken);
        }

        public async Task<bool> ExistsRuleCatalog(string version, long familyId, string ruleCode, CancellationToken cancellationToken)
        {
            return await _context.RuleCatalogs.AnyAsync(r =>
                r.Version == version &&
                r.FamilyId == familyId &&
                r.RuleCode == ruleCode);
        }

        public async Task<bool> ExistsRuleCatalogWhenUpdate(string version, string ruleName, string ruleCode, CancellationToken cancellationToken, long? excludeId = null)
        {
            return await _context.RuleCatalogs
        .AnyAsync(r => r.Version == version
                    && (r.RuleName == ruleName || r.RuleCode == ruleCode)
                    && (excludeId == null || r.Id != excludeId));
        }
        public async Task<RuleCatalog?> GetByRuleCodeAsync(string ruleCode,byte layer,CancellationToken cancellationToken)
        {
            return await _context.RuleCatalogs
                .AsNoTracking()
                .FirstOrDefaultAsync(r =>
                    r.RuleCode == ruleCode &&
                    r.Layer == layer &&
                    r.IsActive,
                    cancellationToken);
        }
        public async Task<List<string>> GetRuleVersionsAsync(RuleCatalog rule,CancellationToken cancellationToken)
        {
            return await _context.RuleCatalogs
                .AsNoTracking()
                .Where(r =>
                    r.RuleCode == rule.RuleCode &&
                    r.FamilyId == rule.FamilyId)
                .Select(r => r.Version!)
                .ToListAsync(cancellationToken);
        }
        public async Task DeactivateOtherVersionsAsync(RuleCatalog rule,CancellationToken cancellationToken)
        {
            await _context.RuleCatalogs
                .Where(r =>
                    r.RuleCode == rule.RuleCode &&
                    r.FamilyId == rule.FamilyId &&
                    r.Id != rule.Id &&
                    r.IsActive == true)
                .ExecuteUpdateAsync(
                    s => s.SetProperty(r => r.IsActive, false),
                    cancellationToken);
        }

        public async Task<RuleCatalog?> GetByIdAsync(long id)
        {
            return await _context.RuleCatalogs.FindAsync(id);
        }

        public async Task<List<RuleCatalog>> WhereAsync(Expression<Func<RuleCatalog, bool>> expression)
        {
            return await _context.RuleCatalogs
                .Where(expression)
                .ToListAsync();
        }

        public async Task<List<FXD07Rule>> ExecuteFXDAsync(string sqlText)
        {
            return await _snapshotDbContext.Database.SqlQueryRaw<FXD07Rule>(sqlText).ToListAsync();
        }
    }
    
}
