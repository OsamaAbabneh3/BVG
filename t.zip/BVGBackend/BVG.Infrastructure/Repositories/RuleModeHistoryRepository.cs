﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Common;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class RuleModeHistoryRepository : IRuleModeHistoryRepository
    {
        private readonly AppDbContext _context;
        public RuleModeHistoryRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<RuleModeHistory>> GetAllRuleModeHistory(CancellationToken cancellationToken)
        {
            return await _context.RuleModeHistories
                .Include(r => r.Cycle)
                .Include(r => r.Rule)
                .ToListAsync(cancellationToken);

        }
        public IQueryable<RuleModeHistory> Query(FilterOptionsDto filterOptions)
        {
            return _context.RuleModeHistories
                .AsNoTracking()
                .ApplyDynamicFilters(filterOptions)
                .AsQueryable();
        }

        public async Task<RuleModeHistory?> GetByIdRuleModeHistory(long id, CancellationToken cancellationToken)
        {
            return await _context.RuleModeHistories
                .Include(r => r.Cycle)
                 .Include(r => r.Rule)
                .FirstOrDefaultAsync(r => r.Id == id, cancellationToken);

        }
        public async Task<RuleModeHistory> AddRuleModeHistory(RuleModeHistory ruleModeHistory, CancellationToken cancellationToken)
        {
            await _context.RuleModeHistories.AddAsync(ruleModeHistory, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);
            return ruleModeHistory;
            //تشييك
        }

        public async Task<RuleModeHistory?> LastRuleModeHistory(long ruleId)
        {
            return await _context.RuleModeHistories
                .Where(h => h.RuleId == ruleId)
                .OrderByDescending(h => h.CreatedAt)
                .FirstOrDefaultAsync();
        }
    }
}
