﻿using BVG.Domain.DTOs;
using BVG.Domain.Interfaces;
using Helper.Security;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net.Http.Json;
using System.Reflection.Metadata;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class SmsSender : ISmsSender
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;
        private readonly ILogger<SmsSender> _logger;

        public SmsSender(HttpClient httpClient, IConfiguration configuration, ILogger<SmsSender> logger)
        {
            _httpClient = httpClient;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task SendAsync(string phone, string message)
        {
            if (!_configuration.GetValue<bool>("Sms:Enabled"))
            {
                _logger.LogWarning(message);
                return;
            }
           
            
           

            try
            {
                //using var generationToken = new HttpRequestMessage(HttpMethod.Post,AutoCrypto.Process(_configuration["Sms:Generation"]??"")) { };
                //generationToken.Headers.Add("username", AutoCrypto.Process(_configuration["Sms:UserId"]??""));
                //generationToken.Headers.Add("password", AutoCrypto.Process(_configuration["Sms:Password"]??""));
                //var generationTokenResponse= await _httpClient.SendAsync(generationToken);
                //generationTokenResponse.EnsureSuccessStatusCode();
                //var generationTokenResponseData = await generationTokenResponse.Content.ReadFromJsonAsync<SmsIntegrationResponse>();
                //string[] phoneNumbersArray = new string[] { "962" + phone.Substring(1) };
                //using var req = new HttpRequestMessage(HttpMethod.Post,AutoCrypto.Process(_configuration["Sms:Send"] ?? ""))
                //{
                //    Content = JsonContent.Create(new {
                //        service_type = _configuration["Sms:ServiceType"],
                //        recipient_numbers_type = "single_numbers",
                //        phone_numbers = phoneNumbersArray,
                //        content=message,
                //        sender_id= _configuration["Sms:SenderId"]
                //    })
                //};
                //req.Headers.Add("integration_token", generationTokenResponseData?.Result.Integration_Token);
                //var res = await _httpClient.SendAsync(req);

                //res.EnsureSuccessStatusCode();
                _logger.LogWarning(message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "SMS sending failed");
                throw;
            }
        }
    }
}
