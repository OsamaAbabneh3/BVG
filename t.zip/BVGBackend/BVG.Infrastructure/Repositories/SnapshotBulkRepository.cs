﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Common;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class SnapshotBulkRepository : ISnapshotBulkRepository
    {
        private readonly AppDbContext _context;
        public SnapshotBulkRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<SnapshotBulk>> GetAllSnapshotBulk(CancellationToken cancellationToken)
        {
            return await _context.SnapshotBulks
                .Include(r => r.Cycle)
                .ToListAsync(cancellationToken);
        }
        public async Task<SnapshotBulk?> GetByIdSnapshotBulk(long id, CancellationToken cancellationToken)
        {
            var snapshotBulk = await _context.SnapshotBulks.FindAsync(id, cancellationToken);
            return snapshotBulk;
        }
        public async Task<SnapshotBulk> AddSnapshotBulk(SnapshotBulk snapshotBulk, CancellationToken cancellationToken)
        {
            await _context.SnapshotBulks.AddAsync(snapshotBulk, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);
            return snapshotBulk;
        }
        public async Task UpdateAsync(SnapshotBulk snapshotBulk, CancellationToken cancellationToken)
        {
            _context.Update(snapshotBulk);
            await _context.SaveChangesAsync(cancellationToken);
        }
        public IQueryable<SnapshotBulk> Query(FilterOptionsDto filterOptions)
        {
            return _context.SnapshotBulks
                .AsNoTracking()
                .ApplyDynamicFilters(filterOptions)
                .AsQueryable();
        }

        public IQueryable<SnapshotBulk> QueryByCycleInfoIdWithRuningStatuses(long cycleInfoId)
        {
            return _context.SnapshotBulks
            .AsNoTracking()
            .Include(s => s.CycleInfoRuningStatuses)
            .Where(s => s.CycleId == cycleInfoId)
            .OrderBy(s => s.Id);
        }

        public async Task<bool> AnyAsync(Expression<Func<SnapshotBulk, bool>> expression)
        {
            return await _context.SnapshotBulks.AnyAsync(expression);
        }

        public async Task<int> GetMaxSequence(long cycleId)
        {
            var maxSequence = await _context.SnapshotBulks
                .Where(bulk => bulk.CycleId == cycleId)
                .MaxAsync(bulk => (int?)bulk.Sequence);

            return maxSequence ?? 0;
        }

    }
}
