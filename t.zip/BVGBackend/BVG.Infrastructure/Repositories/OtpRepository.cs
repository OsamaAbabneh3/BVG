﻿using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class OtpRepository:IOtpRepository
    {
        private readonly AppDbContext _context;
        public OtpRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task AddAsync(OtpCode otp)
        {
            await _context.OtpCodes.AddAsync(otp);
            await _context.SaveChangesAsync();
        }

        public async Task<OtpCode?> GetByTokenAsync(string requestToken)
        {
            return await _context.OtpCodes.AsNoTracking().FirstOrDefaultAsync(o => o.RequestToken == requestToken);
        }
            

        public async Task<DateTime?> GetLastCreatedAtAsync(string username, OtpPurpose purpose)
        {
            return await _context.OtpCodes.AsNoTracking()
                .Where(o => o.Username == username && o.Purpose == (int)purpose)
                .OrderByDescending(o => o.CreatedAt)
                .Select(o => (DateTime?)o.CreatedAt)
                .FirstOrDefaultAsync();
        }
           

        public async Task<int> CountSentSinceAsync(string username, OtpPurpose purpose, DateTime since)
        {
            return await _context.OtpCodes.CountAsync(o => o.Username == username && o.Purpose == (int)purpose && o.CreatedAt >= since);
        }
           

        public async Task<bool> TryIncrementAttemptAsync(Guid id, int maxAttempts, DateTime now)
        {
            return await _context.OtpCodes
                .Where(o => o.Id == id && !o.IsUsed && o.ExpiresAt > now && o.Attempts < maxAttempts)
                .ExecuteUpdateAsync(s => s.SetProperty(o => o.Attempts, o => o.Attempts + 1)) == 1;
        }
           
      
        public async Task<bool> TryMarkUsedAsync(Guid id, DateTime now)
        {
            return await _context.OtpCodes
                .Where(o => o.Id == id && !o.IsUsed && o.ExpiresAt > now)
                .ExecuteUpdateAsync(s => s.SetProperty(o => o.IsUsed, true)) == 1;
        }
    

        public async Task InvalidateOthersAsync(string username, OtpPurpose purpose, Guid exceptId)
        {
            await _context.OtpCodes
                .Where(o => o.Username == username && o.Purpose == (int)purpose && o.Id != exceptId && !o.IsUsed)
                .ExecuteUpdateAsync(s => s.SetProperty(o => o.IsUsed, true));
        }

        public async Task RemoveAsync(Guid id)
        {
            await _context.OtpCodes.Where(o => o.Id == id).ExecuteDeleteAsync();
        }


        public async Task DeleteOlderThanAsync(DateTime before)
        {
            await _context.OtpCodes.Where(o => o.CreatedAt < before).ExecuteDeleteAsync();
        }
            
    }
}
