﻿using BVG.Domain.Interfaces;
using BVG.Infrastructure.RealTime;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BVG.Infrastructure.Repositories
{
    public class NotificationRepository : INotificationRepository
    {
        private readonly IHubContext<NotificationHub> _hubContext;

        public NotificationRepository(IHubContext<NotificationHub> hubContext)
        {
            _hubContext = hubContext;
        }

        public Task SendToAllAsync<T>(string eventName, T data, CancellationToken cancellationToken = default)
        {
            return _hubContext.Clients.All.SendAsync(eventName,data,cancellationToken);
        }

        public Task SendToAllAsync(string eventName, CancellationToken cancellationToken = default)
        {
            return _hubContext.Clients.All.SendAsync(eventName, cancellationToken);
        }

        public Task SendToUserAsync<T>(string userId, string eventName, T data, CancellationToken cancellationToken = default)
        {
            return _hubContext.Clients.User(userId).SendAsync(eventName,data,cancellationToken);
        }
    }
}
