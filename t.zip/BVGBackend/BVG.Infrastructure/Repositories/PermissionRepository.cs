﻿using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class PermissionRepository : IPermissionRepository
    {
        private readonly AppDbContext _context;

        public PermissionRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Permission> AddAsync(Permission permission, CancellationToken cancellationToken)
        {
            await _context.Permissions.AddAsync(permission);
            await _context.SaveChangesAsync(cancellationToken);
            return permission;
        }

        public async Task<Permission?> GetById(Guid id, CancellationToken cancellationToken)
        {
            var permission = await _context.Permissions.FindAsync(id, cancellationToken);
            return permission;
        }

        public async Task<List<Permission>> GetAllPermissions(CancellationToken cancellationToken)
        {
            return _context.Permissions.AsNoTracking().ToList(); 
        }

        public async Task<int> CountAsync(HashSet<Guid> permissionIds, CancellationToken cancellationToken)
        {
            var count = await _context.Permissions.CountAsync(p => permissionIds.Contains(p.Id), cancellationToken);
            return count;
        }
    }
}
