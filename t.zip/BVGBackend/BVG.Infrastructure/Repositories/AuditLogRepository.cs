﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Common;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace BVG.Infrastructure.Repositories
{
    public class AuditLogRepository : IAuditLogRepository
    {
        private readonly AppDbContext _context;
        

        public AuditLogRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<AuditLog> AddAsync(AuditLog auditLog, CancellationToken cancellationToken)
        {
            await _context.AuditLogs.AddAsync(auditLog, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);
            return auditLog;
        }

        public async Task<List<AuditLog>> WhereAsync(Expression<Func<AuditLog, bool>> predicate, CancellationToken cancellationToken)
        {
            return await _context.AuditLogs.Include(u => u.User).Where(predicate).ToListAsync(cancellationToken);
        }

        public IQueryable<AuditLog> Query(FilterOptionsDto filterOptions)
        {
            return _context.AuditLogs
                .Include(a => a.User)
                .AsNoTracking()
                .ApplyDynamicFilters(filterOptions)
                .AsQueryable();
        }
    }
}
