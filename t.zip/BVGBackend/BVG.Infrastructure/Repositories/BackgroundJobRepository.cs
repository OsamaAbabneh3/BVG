﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace BVG.Infrastructure.Repositories
{
    public class BackgroundJobRepository : IBackgroundJobRepository
    {
        private readonly AppDbContext _context;
        private readonly SnapshotDbContext _snapshotDbContext;

        public BackgroundJobRepository(AppDbContext context, SnapshotDbContext snapshotDbContext)
        {
            _context = context;
            _snapshotDbContext = snapshotDbContext;
        }

        public async Task AddRangeAsync(
            IEnumerable<BackgroundJob> jobs,
            CancellationToken cancellationToken = default)
        {
            await _context.BackgroundJobs.AddRangeAsync(jobs, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);
        }

        public async Task SaveChangesAsync(
            CancellationToken cancellationToken = default)
        {
            await _context.SaveChangesAsync(cancellationToken);
        }

        public async Task<bool> AnyAsync(Expression<Func<BackgroundJob, bool>> expression)
        {
            return await _context.BackgroundJobs.Include(job => job.SnapshotBulk).AnyAsync(expression);
        }

        public async Task<List<InvoiceIdRange>> GetInvoiceRangesAsync(int bulkSize, long bulkId, CancellationToken cancellationToken = default)
        {
            return await _snapshotDbContext.Database
                .SqlQuery<InvoiceIdRange>($"""
            WITH NumberedInvoices AS
            (
                SELECT
                    Id,
                    ROW_NUMBER() OVER (ORDER BY Id) AS RowNumber
                FROM dbo.FullSnapshot 
                WHERE SnapshotBulkId = {bulkId}
            )
            SELECT
                MIN(Id) AS StartInvoiceId,
                MAX(Id) AS EndInvoiceId
            FROM NumberedInvoices
            GROUP BY (RowNumber - 1) / {bulkSize}
            ORDER BY MIN(Id);
            """)
                .ToListAsync(cancellationToken);
        }

        public async Task<long?> GetUncheckedBulkId()
        {
            return (await _context.SnapshotBulks
            .FirstOrDefaultAsync(b => (b.CheckStatus == (byte)CheckStatusEnum.Pending || b.CheckStatus == (byte)CheckStatusEnum.Failed) && b.PullStatus == (byte)PullStatusEnum.Completed))?.Id;
        }

        public async Task<float> ProgressAsync(long bulkId, CancellationToken cancellationToken)
        {
            var stats = await _context.BackgroundJobs
            .Where(job => job.SnapshotBulkId == bulkId)
            .GroupBy(_ => 1)
            .Select(g => new
            {
                All = g.Count(),
                Done = g.Count(job => job.Status == (int)JobStatusEnum.Completed ||
                                      job.Status == (int)JobStatusEnum.Failed)
            })
            .FirstOrDefaultAsync(cancellationToken);

            if (stats == null || stats.All == 0)
                return 0f;

            return (float)stats.Done / stats.All;
        }

        public async Task<bool> IsCheckBulkCompletedAsync(long bulkId)
        {
            return !await _context.BackgroundJobs
                .Where(job => job.SnapshotBulkId == bulkId)
                .AnyAsync(job => job.Status == (int)JobStatusEnum.Pending || job.Status == (int)JobStatusEnum.Processing);
        }

        public async Task<long> CountAsync(Expression<Func<BackgroundJob, bool>> expression)
        {
            return await _context.BackgroundJobs
                .Where(expression)
                .CountAsync();
        }

        public async Task<long> CountComletedAsync(long bulkId)
        {
            return await _context.BackgroundJobs
                .Where(job => (job.Status == (byte)JobStatusEnum.Completed ||
                               job.Status == (byte)JobStatusEnum.Failed) &&
                               job.SnapshotBulkId == bulkId)
                .SumAsync(job => job.EndInvoiceId - job.StartInvoiceId) + 1;
        }

        public async Task DeleteByBulkId(long bulkId)
        {
            await _context.BackgroundJobs
                .Where(job => job.SnapshotBulkId == bulkId)
                .ExecuteDeleteAsync();
        }

        public async Task<BackgroundJob?> FirstOrDefaultAsync(Expression<Func<BackgroundJob, bool>> expression)
        {
            return await _context.BackgroundJobs
                .FirstOrDefaultAsync(expression);
        }
    }
}
