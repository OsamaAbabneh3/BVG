﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Common;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class UserRepository : IUserRepository
    {
        #region DI UserRepository
        private readonly AppDbContext _context;
        #endregion

        #region UserRepository
        public UserRepository(AppDbContext context)
        {
            _context = context;
           
        }
        #endregion

        #region UserRepository

        /// <summary>
        /// Add User AddAsync (AddUser)
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<BvgUser> AddAsync(BvgUser user, CancellationToken cancellationToken)
        {
            await _context.BvgUsers.AddAsync(user, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);
            return user;
        }

        /// <summary>
        /// Update User UpdateAsync (UpdateUser)
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task <BvgUser> UpdateAsync(BvgUser user, CancellationToken cancellationToken)
        {
            _context.BvgUsers.Update(user);
            await _context.SaveChangesAsync(cancellationToken);
            return user;
        }

        /// <summary>
        /// GetById (Get User By Id)
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<BvgUser?> GetById(Guid id, CancellationToken cancellationToken)
        {
            var user = await _context.BvgUsers.FindAsync(id, cancellationToken);
            return user;
        }

        /// <summary>
        /// GetByUserName (Get User By USERNAME)
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        public async Task<BvgUser?> GetByUsername(string username, CancellationToken cancellationToken)
        {
            var user = await _context.BvgUsers
                .Include(user => user.UserRoles)
                .ThenInclude(userRole => userRole.Role)
                .ThenInclude(role => role!.RolePermissions)
                .ThenInclude(rolePermissions => rolePermissions.Permission)
                .FirstOrDefaultAsync(x => x.UserName.ToUpper() == username.ToUpper().Trim(), cancellationToken);
            return user;
        }

        public async Task<BvgUser?> GetByIdentifier(string identifier, CancellationToken cancellationToken)
        {
            var user = await _context.BvgUsers
                .Include(user => user.UserRoles)
                .ThenInclude(userRole => userRole.Role)
                .ThenInclude(role => role!.RolePermissions)
                .ThenInclude(rolePermissions => rolePermissions.Permission)
                .FirstOrDefaultAsync(x => x.UserName.ToUpper() == identifier.ToUpper().Trim() || x.Email.ToUpper() == identifier.ToUpper().Trim(), cancellationToken);
            return user;
        }

        /// <summary>
        /// GetByIdWithRoles
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<BvgUser?> GetByIdWithRoles(Guid id, CancellationToken cancellationToken)
        {
            var user = await _context.BvgUsers
                .AsNoTracking()
                .Include(x => x.UserRoles)
                .ThenInclude(ur => ur.Role)
                .FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
            return user;
        }

        public async Task<BvgUser?> GetByIdWithUserRoles(Guid id, CancellationToken cancellationToken)
        {
            var user = await _context.BvgUsers
                .Include(x => x.UserRoles)
                .FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
            return user;
        }

        /// <summary>
        /// Check User Exist
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        public async Task<bool> IsUserExists(string username, CancellationToken cancellationToken)
        {
            var exists = await _context.BvgUsers.AnyAsync(u => u.UserName.Trim().ToUpper() == username.Trim().ToUpper(), cancellationToken);
            return exists;
        }

        /// <summary>
        /// Check Email is Used
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        public async Task<bool> IsEmailUsed(string email, CancellationToken cancellationToken)
        {
            var exists = await _context.BvgUsers.AnyAsync(u => u.Email.Trim().ToUpper() == email.Trim().ToUpper(), cancellationToken);
            return exists;
        }

        public async Task<bool> IsPhoneUsed(string phone, CancellationToken cancellationToken)
        {
            var exists = await _context.BvgUsers.AnyAsync(u => u.PhoneNumber.Trim().ToUpper() == phone.Trim().ToUpper(), cancellationToken);
            return exists;
        }

        public async Task<bool> IsPhoneUsedExceptCurrent(Guid id, string phone, CancellationToken cancellationToken)
        {
            var exists = await _context.BvgUsers.AnyAsync(u => u.PhoneNumber.Trim().ToUpper() == phone.Trim().ToUpper() && u.Id != id, cancellationToken);
            return exists;
        }

        /// <summary>
        /// Query with Return All Users by Query 
        /// </summary>
        /// <returns></returns>
        public IQueryable<BvgUser> Query(FilterOptionsDto filterOptions)
        {
            return _context.BvgUsers
                .AsNoTracking()
                .Include(u => u.UserRoles)
                .ThenInclude(ur => ur.Role)
                .Where(u => u.UserName != "ADMIN")
                .ApplyDynamicFilters(filterOptions)
                .AsQueryable();
        }

        public async Task RemoveRangeOfUserRoles(List<UserRole> userRoles, CancellationToken cancellationToken)
        {
            _context.UserRoles.RemoveRange(userRoles);
            await _context.SaveChangesAsync(cancellationToken);
        }
        #endregion
    }
}
