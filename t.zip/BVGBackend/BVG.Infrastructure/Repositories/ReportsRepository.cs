﻿using BVG.Domain.DTOs;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class ReportsRepository : IReportsRepository
    {
        private readonly AppDbContext _appDbContext;
        private readonly SnapshotDbContext _snapshotDbContext;
        public ReportsRepository(AppDbContext appDbContext, SnapshotDbContext snapshotDbContext)
        {
            _appDbContext = appDbContext;
            _snapshotDbContext = snapshotDbContext;
        }
        public async Task<List<CycleSummaryReportRowDto>>GetCycleSummaryAsync(long cycleId,long? snapshotBulkId,CancellationToken cancellationToken)
        {
            var bulksQuery = _appDbContext.SnapshotBulks
                .AsNoTracking()
                .Where(b => b.CycleId == cycleId);

            if (snapshotBulkId.HasValue)
            {
                bulksQuery = bulksQuery.Where(
                    b => b.Id == snapshotBulkId.Value);
            }

            var summaries = await bulksQuery
                .OrderBy(b => b.Id)
                .Select(b => new
                {
                    b.CycleId,
                    b.Cycle.CycleDate,
                    SnapshotBulkId = b.Id,
                    BulkCreatedAt = b.CreatedAt,

                    TotalExceptions = _appDbContext.InvoiceExceptions
                        .LongCount(e => e.SnapshotBulkId == b.Id),

                    AccountsWithExceptionsCount =
                        _appDbContext.InvoiceExceptions
                            .Where(e => e.SnapshotBulkId == b.Id)
                            .Select(e => e.AccountNumber)
                            .Distinct()
                            .LongCount(),

                    RulesWithExceptionsCount =
                        _appDbContext.InvoiceExceptions
                            .Where(e =>
                                e.SnapshotBulkId == b.Id &&
                                e.RuleId != null)
                            .Select(e => e.RuleId)
                            .Distinct()
                            .LongCount()
                })
                .ToListAsync(cancellationToken);

            if (summaries.Count == 0)
            {
                return new List<CycleSummaryReportRowDto>();
            }

            var bulkIds = summaries
                .Select(b => b.SnapshotBulkId)
                .ToList();

            var invoiceCounts = await GetInvoiceCountsAsync(bulkIds,cancellationToken);

            return summaries.Select(b =>
            {
                invoiceCounts.TryGetValue(
                    b.SnapshotBulkId,
                    out var counts);

                return new CycleSummaryReportRowDto
                {
                    CycleId = b.CycleId,
                    CycleDate = b.CycleDate.ToString("yyyy-MM-dd"),
                    SnapshotBulkId = b.SnapshotBulkId,
                    BulkCreatedAt = b.BulkCreatedAt,

                    TotalInvoices = counts.TotalInvoices,
                    ReadyToPublishCount = counts.ReadyToPublishCount,

                    AccountsWithExceptionsCount =
                        b.AccountsWithExceptionsCount,

                    TotalExceptions = b.TotalExceptions,

                    RulesWithExceptionsCount =
                        b.RulesWithExceptionsCount
                };
            }).ToList();
        }

        private async Task<Dictionary<long, (long TotalInvoices , long ReadyToPublishCount)>> GetInvoiceCountsAsync(List<long> bulkIds,CancellationToken cancellationToken)
        {
            var counts = new Dictionary<long, (long TotalInvoices , long ReadyToPublishCount)>();

            var connection = _snapshotDbContext.Database.GetDbConnection();
            var shouldClose = connection.State != ConnectionState.Open;

            if (shouldClose)
                await connection.OpenAsync(cancellationToken);

            try
            {
                await using var command = connection.CreateCommand();

                // تجزئة المعرّفات لتفادي حد Parameters في SQL Server.
                const int batchSize = 1000;

                for (var offset = 0; offset < bulkIds.Count;
                     offset += batchSize)
                {
                    cancellationToken.ThrowIfCancellationRequested();

                    var batch = bulkIds
                        .Skip(offset)
                        .Take(batchSize)
                        .ToList();

                    

                    command.CommandType = CommandType.Text;
                    command.CommandTimeout = 30;

                    var parameterNames = new List<string>();

                    for (var index = 0; index < batch.Count; index++)
                    {
                        var parameterName = $"@BulkId{index}";
                        parameterNames.Add(parameterName);

                        var parameter = command.CreateParameter();
                        parameter.ParameterName = parameterName;
                        parameter.DbType = DbType.Int64;
                        parameter.Value = batch[index];

                        command.Parameters.Add(parameter);
                    }

                    command.CommandText = $@" SELECT SnapshotBulkId,COUNT_BIG(*) AS TotalInvoices,SUM(CASE WHEN [InvoiceStatus] = 3 THEN CAST(1 AS bigint) ELSE CAST(0 AS bigint) END) AS ReadyToPublishCount FROM dbo.FullSnapshot WHERE SnapshotBulkId IN ({string.Join(", ", parameterNames)}) GROUP BY SnapshotBulkId;";

                    await using var reader =
                        await command.ExecuteReaderAsync(
                            cancellationToken);

                    var bulkIdOrdinal = reader.GetOrdinal("SnapshotBulkId");
                    var countOrdinal = reader.GetOrdinal("TotalInvoices");
                    var readyOrdinal = reader.GetOrdinal("ReadyToPublishCount");

                    while (await reader.ReadAsync(cancellationToken)) 
                    {
                        long bulkId = Convert.ToInt64(reader.GetValue(bulkIdOrdinal));

                        long totalInvoices = Convert.ToInt64(reader.GetValue(countOrdinal));

                        long readyToPublishCount = Convert.ToInt64(reader.GetValue(readyOrdinal));

                        counts[bulkId] = (TotalInvoices: totalInvoices,ReadyToPublishCount: readyToPublishCount
               );
                    }
                }
            }
            finally
            {
                if (shouldClose && connection.State == ConnectionState.Open)
                {
                    await connection.CloseAsync();
                }
            }

            return counts;
        }
    }
}
