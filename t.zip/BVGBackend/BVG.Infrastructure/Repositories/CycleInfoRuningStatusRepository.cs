﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Common;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;


namespace BVG.Infrastructure.Repositories
{
    public class CycleInfoRuningStatusRepository : ICycleInfoRuningStatusRepository
    {
        private readonly AppDbContext _context;

        public CycleInfoRuningStatusRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<CycleInfoRuningStatus> AddAsync(CycleInfoRuningStatus cycleInfoRuningStatus)
        {
            await _context.CycleInfoRuningStatuses.AddAsync(cycleInfoRuningStatus);
            await _context.SaveChangesAsync();
            return cycleInfoRuningStatus;
        }

        public IQueryable<CycleInfoRuningStatus> Query(FilterOptionsDto filterOptions)
        {
            return _context.CycleInfoRuningStatuses
                 .Include(s=>s.SnapshotBulk)
                 .AsNoTracking()
                 .ApplyDynamicFilters(filterOptions)
                 .AsQueryable();
        }

        public async Task<List<CycleInfoRuningStatus>> WhereAsync(Expression<Func<CycleInfoRuningStatus, bool>> predicate)
        {
            return _context.CycleInfoRuningStatuses.Include(s => s.SnapshotBulk).Where(predicate).ToList();
        }
    }
}
