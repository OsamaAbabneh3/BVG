﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Common;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class DualAuthorizationRequestRepository : IDualAuthorizationRequestRepository
    {
        private readonly AppDbContext _context;
        public DualAuthorizationRequestRepository(AppDbContext context)
        {
            _context = context;
        }
        public async Task<DualAuthorizationRequest> AddDualAuthorizationRequest(DualAuthorizationRequest dualAuthorizationRequest, CancellationToken cancellationToken)
        {
            await _context.DualAuthorizationRequests.AddAsync(dualAuthorizationRequest, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);
            return dualAuthorizationRequest;
        }
        public async Task<DualAuthorizationRequest?> GetByIdDualAuthorizationRequest(long id, CancellationToken cancellationToken)
        {
            var dualAuthorizationRequest = await _context.DualAuthorizationRequests.FindAsync(id, cancellationToken);
            return dualAuthorizationRequest;
        }
        public async Task UpdateDualAuthorizationRequest(DualAuthorizationRequest dualAuthorizationRequest, CancellationToken cancellationToken)
        {
            _context.Update(dualAuthorizationRequest);
            await _context.SaveChangesAsync(cancellationToken);
        }
        public async Task<List<DualAuthorizationRequest>> GetAllDualAuthorizationRequests(CancellationToken cancellationToken)
        {
            return await _context.DualAuthorizationRequests
                .Include(i => i.SnapshotBulk)
                .ToListAsync(cancellationToken);

        }
        public IQueryable<DualAuthorizationRequest> Query(FilterOptionsDto filterOptions)
        {
            return _context.DualAuthorizationRequests  
                .AsNoTracking()
                .ApplyDynamicFilters(filterOptions)
                .AsQueryable();
        }
    }
}
