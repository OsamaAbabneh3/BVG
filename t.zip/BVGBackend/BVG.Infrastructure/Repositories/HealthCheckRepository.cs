﻿using BVG.Domain.Interfaces;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class HealthCheckRepository : IHealthCheckRepository
    {
        private readonly AppDbContext _appDbContext;
        private readonly SnapshotDbContext _snapshotDbContext;

        public record OracleConnectionResult(bool IsConnected, string Message);

        public HealthCheckRepository(
            AppDbContext appDbContext,
            SnapshotDbContext snapshotDbContext)
        {
            _appDbContext = appDbContext;
            _snapshotDbContext = snapshotDbContext;
        }

        public async Task<bool> CanConnectWithBVGDBAsync()
        {
            return await _appDbContext.Database.CanConnectAsync();
        }

        public async Task<bool> CanConnectWithSnapshotDBAsync()
        {
            return await _snapshotDbContext.Database.CanConnectAsync();
        }

        public async Task<bool> CanConnectWithOracleDBAsync()
        {
            var result = await _snapshotDbContext.Database.SqlQuery<OracleConnectionResult>(
            $"""
            EXEC [dbo].[CheckOracleConnection]
                @LinkedServerName = "Oracle_link"
            """).ToListAsync();
            return result?.FirstOrDefault()?.IsConnected ?? false; 
        }
    }
}
