﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Common;
using BVG.Infrastructure.Persistence;
using DocumentFormat.OpenXml.Drawing.Charts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class InvoiceExceptionRepository : IInvoiceExceptionRepository
    {
        private readonly AppDbContext _context;


        public InvoiceExceptionRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<InvoiceException> AddInvoiceException(InvoiceException invoiceException, CancellationToken cancellationToken)
        {
            await _context.InvoiceExceptions.AddAsync(invoiceException);
            await _context.SaveChangesAsync(cancellationToken);
            return invoiceException;
        }
     
        public async Task<List<InvoiceException>> GetAllInvoiceException(CancellationToken cancellationToken)
        {
            return await _context.InvoiceExceptions
              .Include(r => r.Rule)
              .Include(r => r.SnapshotBulk)
              .ToListAsync(cancellationToken);

        }
        public IQueryable<InvoiceException> Query(FilterOptionsDto filterOptions)
        {
            return _context.InvoiceExceptions
                .AsNoTracking()
                .ApplyDynamicFilters(filterOptions)
                .AsQueryable();
        }
        public async Task<InvoiceException?> GetByIdInvoiceException(long id, CancellationToken cancellationToken)
        {
            var invoice = await _context.InvoiceExceptions.FindAsync(id, cancellationToken);
            return invoice;
        }
        public async Task<bool> IsDuplicate(long snapshotBulkId, long ruleId, string accountNumber, CancellationToken cancellationToken)
        {
            return await _context.InvoiceExceptions.AnyAsync(i => i.SnapshotBulkId == snapshotBulkId && i.RuleId == ruleId && i.AccountNumber == accountNumber, cancellationToken);
        }

        public async Task UpdateInvoiceException(InvoiceException invoiceException, CancellationToken cancellationToken)
        {
            _context.Update(invoiceException);
            await _context.SaveChangesAsync(cancellationToken);
        }

        public async Task AddRangeInvoidExceptions(List<InvoiceException> invoiceExceptions, CancellationToken cancellationToken)
        {
            await _context.InvoiceExceptions.AddRangeAsync(invoiceExceptions);
            await _context.SaveChangesAsync(cancellationToken);
        }

        public async Task<long> CountAsync(Expression<Func<InvoiceException, bool>> expression)
        {
            return await _context.InvoiceExceptions
                .Where(expression)
                .CountAsync();
        }

        public async Task DeleteByBulkIdAsync(long bulkId)
        {
            await _context.InvoiceExceptions
                .Where(ex => ex.SnapshotBulkId == bulkId)
                .ExecuteDeleteAsync();
        }

        public async Task<List<InvoiceException>> WhereAsync(Expression<Func<InvoiceException, bool>> expression)
        {
            return await _context.InvoiceExceptions
                .Where(expression)
                .ToListAsync();
        }
    }
}
