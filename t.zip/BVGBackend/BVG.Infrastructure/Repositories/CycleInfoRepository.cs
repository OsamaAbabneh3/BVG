﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Common;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Infrastructure
{
    public class CycleInfoRepository : ICycleInfoRepository
    {
        private readonly AppDbContext _context;
        public CycleInfoRepository(AppDbContext context)
        {
            _context = context;
        }
        public async Task<CycleInfo?> GetByIdCycleInfo(long id, CancellationToken cancellationToken)
        {
            var cycleInfo = await _context.CycleInfos.FindAsync(id, cancellationToken);
            return cycleInfo;
        }
        public async Task<CycleInfo> AddCycleInfo(CycleInfo cycleInfo, CancellationToken cancellationToken)
        {
            await _context.CycleInfos.AddAsync(cycleInfo, cancellationToken);
            await _context.SaveChangesAsync();
            return cycleInfo;
        }
        public async Task UpdateCycleInfo(CycleInfo cycleInfo, CancellationToken cancellationToken)
        {

            _context.Update(cycleInfo);
            await _context.SaveChangesAsync(cancellationToken);
        }
        public async Task<IEnumerable<CycleInfo>> GetAllCycleInfo()
        {
            return await _context.CycleInfos
                .Include(r => r.RuleModeHistories)
                .ToListAsync();
        }

        public async Task<CycleInfo?> GetFirstOrDefaultAsync(Expression<Func<CycleInfo, bool>> expression)
        {
            return await _context.CycleInfos
                .Include(c => c.SnapshotBulks)
                .FirstOrDefaultAsync(expression);
        }

        public IQueryable<CycleInfo> Query(FilterOptionsDto filterOptions)
        {
            return _context.CycleInfos
                .AsNoTracking()
                .ApplyDynamicFilters(filterOptions)
                .AsQueryable();
        }
    }
}
