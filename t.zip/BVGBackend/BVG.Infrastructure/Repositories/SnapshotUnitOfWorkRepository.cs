﻿using BVG.Domain.Interfaces;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System.Data;

namespace BVG.Infrastructure.Repositories
{
    public class SnapshotUnitOfWorkRepository : ISnapshotUnitOfWorkRepository
    {
        private readonly SnapshotDbContext _context;
        private IDbContextTransaction? _transaction;

        private int _transactionDepth = 0;

        private bool _disposed = false;

        public SnapshotUnitOfWorkRepository(SnapshotDbContext context)
        {
            _context = context;
        }

        public async Task BeginTransactionAsync(IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
        {
            ThrowIfDisposed();

            if (_transactionDepth == 0)
            {
                _transaction = await _context.Database.BeginTransactionAsync(isolationLevel);
            }
            _transactionDepth++;
        }

        public async Task CommitAsync()
        {
            ThrowIfDisposed();

            if (_transactionDepth == 0)
                throw new InvalidOperationException("Transaction not started.");

            _transactionDepth--;

            if (_transactionDepth == 0)
            {
                try
                {
                    await _context.SaveChangesAsync();
                    if (_transaction != null)
                    {
                        await _transaction.CommitAsync();
                    }
                }
                catch
                {
                    await RollbackInternalAsync();
                    throw;
                }
                finally
                {
                    await DisposeTransactionAsync();
                }
            }
        }

        public async Task RollbackAsync()
        {
            ThrowIfDisposed();
            if (_transactionDepth == 0)
                return;

            await RollbackInternalAsync();
            await DisposeTransactionAsync();
            _transactionDepth = 0;
        }

        public void ClearTrackedChanges()
        {
            ThrowIfDisposed();
            _context.ChangeTracker.Clear();
        }

        public bool HasChanges()
        {
            ThrowIfDisposed();
            return _context.ChangeTracker.HasChanges();
        }

        private async Task RollbackInternalAsync()
        {
            if (_transaction != null)
            {
                await _transaction.RollbackAsync();
            }
        }

        private async Task DisposeTransactionAsync()
        {
            if (_transaction != null)
            {
                await _transaction.DisposeAsync();
                _transaction = null;
            }
        }

        private void ThrowIfDisposed()
        {
            if (_disposed)
                throw new ObjectDisposedException(nameof(UnitOfWorkRepository));
        }

        public async ValueTask DisposeAsync()
        {
            if (_disposed)
                return;

            if (_transaction != null)
            {
                await _transaction.DisposeAsync();
                _transaction = null;
            }

            _disposed = true;
        }

        public async Task SaveChangesAsync()
        {
            ThrowIfDisposed();
            await _context.SaveChangesAsync();
        }
    }
}
