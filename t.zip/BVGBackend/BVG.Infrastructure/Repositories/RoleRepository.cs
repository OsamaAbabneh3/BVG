﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Common;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class RoleRepository : IRoleRepository
    {
        private readonly AppDbContext _context;
        private readonly DbSet<Role> _dbSet;

        public RoleRepository(AppDbContext context)
        {
            _context = context;
            _dbSet = context.Set<Role>();
        }

        public async Task<Role> AddAsync(Role role, CancellationToken cancellationToken)
        {
            await _dbSet.AddAsync(role, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);
            return role;
        }

        public async Task<Role?> GetById(Guid id, CancellationToken cancellationToken)
        {
            var role = await _dbSet.FindAsync(id, cancellationToken);
            return role;
        }

        public async Task<Role> UpdateAsync(Role role, CancellationToken cancellationToken)
        {
            _dbSet.Update(role);
            await _context.SaveChangesAsync(cancellationToken);
            return role;
        }

        public async Task<Role?> GetByIdWithRolePermissions(Guid id, CancellationToken cancellationToken)
        {
            var role = await _context.Roles
                .Include(perm => perm.RolePermissions)
                .FirstOrDefaultAsync(r => r.Id == id, cancellationToken);
            return role;
        }

        public async Task<List<Role>> Where(Expression<Func<Role, bool>> predicate, CancellationToken cancellationToken)
        {
            var roles = await _dbSet.Where(predicate).ToListAsync(cancellationToken);
            return roles;
        }

        public IQueryable<Role> Query(FilterOptionsDto filterOptions)
        {
            return _dbSet
                .AsNoTracking()
                .Include(r => r.RolePermissions)
                .ThenInclude(rp => rp.Role)
                .ApplyDynamicFilters(filterOptions)
                .AsQueryable();
        }

        public async Task<int> CountAsync(HashSet<Guid> roleIds, CancellationToken cancellationToken)
        {
            var count = await _dbSet.CountAsync(r => roleIds.Contains(r.Id), cancellationToken);
            return count;
        }

        public async Task RemoveRangeOfRolePermissions(List<RolePermission> rolePermissions, CancellationToken cancellationToken)
        {
            _context.RolePermissions.RemoveRange(rolePermissions);
            await _context.SaveChangesAsync(cancellationToken);
        }

        public async Task<Role?> GetByIdWithRelationsAsync(Guid id, CancellationToken cancellationToken)
        {
            return await _context.Roles
                .Include(r => r.RolePermissions)
                .Include(r => r.UserRoles)
                .FirstOrDefaultAsync(r => r.Id == id, cancellationToken);
        }

        public async Task DeleteRoleAsync(Role role, CancellationToken cancellationToken)
        {
            _context.RolePermissions.RemoveRange(role.RolePermissions);
            _context.Roles.Remove(role);
            await _context.SaveChangesAsync(cancellationToken);
        }
    }
}
