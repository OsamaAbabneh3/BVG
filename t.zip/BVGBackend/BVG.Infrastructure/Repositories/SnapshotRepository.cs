﻿using BVG.Domain.DTOs;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class SnapshotRepository : ISnapshotRepository
    {
        private readonly SnapshotDbContext _snapshotDbContext;

        public SnapshotRepository(SnapshotDbContext snapshotDbContext)
        {
            _snapshotDbContext = snapshotDbContext;
        }

        public async Task<CycleRecord?> TakeActiveCycle()
        {
            var result =  await _snapshotDbContext.Database.SqlQuery<CycleRecord>(
                $""""
                EXEC [dbo].[usp_GetCurrentBillingCycle]
                """"
                ).ToListAsync();
            return result.FirstOrDefault();
        }

        public async Task<MigrateFullSnapshot?> TakeSnapshotAsync(string cycleYM, long bulkId)
        {
            _snapshotDbContext.Database.SetCommandTimeout(TimeSpan.FromMinutes(60));
            var result = await _snapshotDbContext.Database.SqlQuery<MigrateFullSnapshot>(
                $""""
                EXEC [dbo].[usp_MigrateOracleSnapshots]
                    @CycleYM = {int.Parse(cycleYM)},
                    @BulkId = {bulkId}
                """"
                ).ToListAsync();
            return result.FirstOrDefault();
        }

        public async Task TakeReferencesSnapshotAsync(DateOnly cycleDate)
        {
            _snapshotDbContext.Database.SetCommandTimeout(TimeSpan.FromMinutes(60));
            await _snapshotDbContext.Database.ExecuteSqlAsync(
                $""""
                EXEC [dbo].[usp_SyncOracleReferenceData]
                    @EffectiveDate = {cycleDate}
                """"
                );
        }

        public async Task TakePricesSnapshotAsync(DateOnly cycleDate)
        {
            _snapshotDbContext.Database.SetCommandTimeout(TimeSpan.FromMinutes(60));
            await _snapshotDbContext.Database.ExecuteSqlAsync(
                $""""
                EXEC [dbo].[usp_SyncOraclePrices]
                    @EffectiveDate = {cycleDate}
                """"
                );
        }
    }
}
