﻿using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Persistence;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class EmailLogRepository : IEmailLogRepository
    {

        private readonly AppDbContext _context;
        public EmailLogRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task Add(EmailLog emailLog)
        {
            await _context.EmailLogs.AddAsync(emailLog);
            await _context.SaveChangesAsync();
        }
    }
}
