﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace BVG.Infrastructure.Repositories
{
    public class GeneralRepository : IGeneralRepository
    {
        private readonly SnapshotDbContext _snapshotDbContext;

        public GeneralRepository(SnapshotDbContext snapshotDbContext)
        {
            _snapshotDbContext = snapshotDbContext;
        }

        public async Task<List<ExceptionResult>> ExceuteAsync(long startId, long endId, string sqlText, CancellationToken cancellationToken)
        {
            var connection = _snapshotDbContext.Database.GetDbConnection();
            var shouldClose = connection.State != ConnectionState.Open;

            if (shouldClose)
                await connection.OpenAsync(cancellationToken);

            try
            {
                await using var command = connection.CreateCommand();

                command.CommandText = sqlText;
                command.CommandType = CommandType.Text;
                command.CommandTimeout = 30;

                var startIdParameter = command.CreateParameter();
                startIdParameter.ParameterName = "@StartId";
                startIdParameter.Value = startId;
                startIdParameter.DbType = DbType.Decimal;
                command.Parameters.Add(startIdParameter);

                var endIdParameter = command.CreateParameter();
                endIdParameter.ParameterName = "@EndId";
                endIdParameter.Value = endId;
                endIdParameter.DbType = DbType.Decimal;
                command.Parameters.Add(endIdParameter);

                await using var reader = await command.ExecuteReaderAsync(cancellationToken);

                var exceptions = new List<ExceptionResult>();
                while (await reader.ReadAsync(cancellationToken))
                {
                    exceptions.Add(new ExceptionResult 
                    {
                        AccountNumber = reader.GetString(reader.GetOrdinal("AccountNumber")),
                    });
                }

                return exceptions;
            }
            finally
            {
                if (shouldClose && connection.State == ConnectionState.Open)
                    await connection.CloseAsync();
            }
        }

        public async Task<List<string>> GetInvalidBillKindsAsync(long snapshotBulkId,string sqlText,CancellationToken cancellationToken)
        {
            var connection = _snapshotDbContext.Database.GetDbConnection();
            var shouldClose = connection.State != ConnectionState.Open;
            if (shouldClose)
                await connection.OpenAsync(cancellationToken);
            try
            {
                await using var command = connection.CreateCommand();
                command.CommandText = sqlText;
                command.CommandType = CommandType.Text;
                command.CommandTimeout = 30;

                var snapshotBulkIdParameter = command.CreateParameter();
                snapshotBulkIdParameter.ParameterName = "@SnapshotBulkId";
                snapshotBulkIdParameter.Value = snapshotBulkId;
                snapshotBulkIdParameter.DbType = DbType.Int64;

                command.Parameters.Add(snapshotBulkIdParameter);

                var invalidBillKinds = new List<string>();

                await using var reader = await command.ExecuteReaderAsync(cancellationToken);

                var billKindOrdinal = reader.GetOrdinal("BillKind");

                while (await reader.ReadAsync(cancellationToken))
                {
                    if(!reader.IsDBNull(billKindOrdinal))
                    {
                        invalidBillKinds.Add(
                            Convert.ToString(reader.GetValue(billKindOrdinal))!
                            );
                    }
                }
                return invalidBillKinds;
            }
            finally
            {
                if (shouldClose && connection.State == ConnectionState.Open)
                    await connection.CloseAsync();
            }
        }

        public async Task<long> GetRowCountAsync(long snapshotBulkId,string sqlText, CancellationToken cancellationToken)
        {
            var connection = _snapshotDbContext.Database.GetDbConnection();
            var shouldClose = connection.State != ConnectionState.Open;
            if (shouldClose)
                await connection.OpenAsync(cancellationToken);
            try
            {
                await using var command = connection.CreateCommand();
                command.CommandText = sqlText;
                command.CommandType = CommandType.Text;
                command.CommandTimeout = 30;


                var snapshotBulkIdParameter = command.CreateParameter();
                snapshotBulkIdParameter.ParameterName = "@SnapshotBulkId";
                snapshotBulkIdParameter.Value = snapshotBulkId;
                snapshotBulkIdParameter.DbType = DbType.Int64;

                command.Parameters.Add(snapshotBulkIdParameter);

                var result = await command.ExecuteScalarAsync(cancellationToken);
                if(result == null || result == DBNull.Value)
                {
                    return 0;
                }
                return Convert.ToInt64(result);
            }
            finally
            {
                if (shouldClose && connection.State == ConnectionState.Open)
                    await connection.CloseAsync();
            }
        }

        public async Task ClearAllTablesAsync(CancellationToken cancellationToken)
        {
            await _snapshotDbContext.Database.ExecuteSqlAsync(
            $""""
            EXEC [dbo].[usp_ClearAllTables]
            """"
            , cancellationToken);
        }

        public async Task ClearByBulkAsync(long bulkId, CancellationToken cancellationToken)
        {
            await _snapshotDbContext.Database.ExecuteSqlAsync(
            $""""
            EXEC [dbo].[usp_DeleteSnapshotBulk]
                @BulkId = {bulkId},

            """"
            , cancellationToken);
        }
    }
}
