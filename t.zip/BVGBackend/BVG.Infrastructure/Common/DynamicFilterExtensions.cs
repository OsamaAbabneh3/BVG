﻿using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text.Json;

namespace BVG.Infrastructure.Common
{
    public static class DynamicFilterExtensions
    {
        public static IQueryable<T> ApplyDynamicFilters<T>(
            this IQueryable<T> query,
            FilterOptionsDto filterOptions)
        {
            ArgumentNullException.ThrowIfNull(query);
            ArgumentNullException.ThrowIfNull(filterOptions);

            if (filterOptions.Groups == null ||
                filterOptions.Groups.Count == 0)
            {
                return query;
            }

            var parameter = Expression.Parameter(typeof(T), "x");

            Expression? combinedGroups = null;

            foreach (var group in filterOptions.Groups)
            {
                bool useInnerOr = IsOr(group.InnerOperator);
                bool useOuterOr = IsOr(group.OuterOperator);

                var groupExpression = BuildGroupExpression(
                    parameter,
                    group,
                    useInnerOr
                );

                if (groupExpression == null)
                    continue;

                combinedGroups = CombineExpressions(
                    combinedGroups,
                    groupExpression,
                    useOuterOr
                );
            }

            if (combinedGroups == null)
                return query;

            var lambda = Expression.Lambda<Func<T, bool>>(
                combinedGroups,
                parameter
            );

            return query.Where(lambda);
        }

        private static Expression? BuildGroupExpression(
            ParameterExpression parameter,
            FilterGroupDto group,
            bool useOr)
        {
            if (group.Filters == null ||
                group.Filters.Count == 0)
            {
                return null;
            }

            var filters = group.Filters;

            var collectionPaths = filters
                .Select(f => GetCollectionPath(
                    parameter.Type,
                    f.Field
                ))
                .ToList();

            bool hasCollection = collectionPaths
                .Any(p => p != null);

            if (!hasCollection)
            {
                return BuildNormalGroup(
                    parameter,
                    filters,
                    useOr
                );
            }

            if (collectionPaths.Any(p => p == null))
            {
                throw new ArgumentException(
                    "Cannot mix collection filters with " +
                    "normal filters in the same group."
                );
            }

            var distinctPaths = collectionPaths
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            if (distinctPaths.Count != 1)
            {
                throw new ArgumentException(
                    "All collection filters in the same group " +
                    "must target the same collection."
                );
            }

            return BuildCollectionGroup(
                parameter,
                filters,
                distinctPaths[0]!,
                useOr
            );
        }

        private static Expression? BuildNormalGroup(
            ParameterExpression parameter,
            List<DynamicFilter> filters,
            bool useOr)
        {
            Expression? combined = null;

            foreach (var filter in filters)
            {
                var condition = BuildFilterCondition(
                    parameter,
                    filter.Field,
                    filter
                );

                combined = CombineExpressions(
                    combined,
                    condition,
                    useOr
                );
            }

            return combined;
        }

        private static Expression BuildCollectionGroup(
            ParameterExpression parameter,
            List<DynamicFilter> filters,
            string collectionPath,
            bool useOr)
        {
            var (collectionMember, guards) = GetMember(
                parameter,
                collectionPath
            );

            var elementType = GetCollectionElementType(
                collectionMember.Type
            );

            if (elementType == null)
            {
                throw new ArgumentException(
                    $"'{collectionPath}' is not a collection."
                );
            }

            var itemParameter = Expression.Parameter(
                elementType,
                "item"
            );

            Expression? itemConditions = null;

            foreach (var filter in filters)
            {
                var relativePath = filter.Field.Substring(
                    collectionPath.Length + 1
                );

                if (string.IsNullOrWhiteSpace(relativePath))
                {
                    throw new ArgumentException(
                        "Collection filter requires a child property."
                    );
                }

                var condition = BuildFilterCondition(
                    itemParameter,
                    relativePath,
                    filter
                );

                itemConditions = CombineExpressions(
                    itemConditions,
                    condition,
                    useOr
                );
            }

            if (itemConditions == null)
            {
                throw new ArgumentException(
                    "Collection group cannot be empty."
                );
            }

            var lambda = Expression.Lambda(
                itemConditions,
                itemParameter
            );


            Expression anyExpression = Expression.Call(
                typeof(Enumerable),
                nameof(Enumerable.Any),
                new[] { elementType },
                collectionMember,
                lambda
            );


            if (!collectionMember.Type.IsValueType)
            {
                anyExpression = Expression.AndAlso(
                    Expression.NotEqual(
                        collectionMember,
                        Expression.Constant(
                            null,
                            collectionMember.Type
                        )
                    ),
                    anyExpression
                );
            }

            foreach (var guard in guards)
            {
                anyExpression = Expression.AndAlso(
                    guard,
                    anyExpression
                );
            }

            return anyExpression;
        }

        private static Expression BuildFilterCondition(
            Expression parameter,
            string fieldPath,
            DynamicFilter filter)
        {
            var (member, guards) = GetMember(
                parameter,
                fieldPath
            );

            Expression condition = BuildCondition(
                member,
                filter
            );

            foreach (var guard in guards)
            {
                condition = Expression.AndAlso(
                    guard,
                    condition
                );
            }

            return condition;
        }

        private static (MemberExpression Member,
            List<Expression> Guards) GetMember(
            Expression parameter,
            string path)
        {
            if (string.IsNullOrWhiteSpace(path))
                throw new ArgumentException("Field is required.");

            Expression current = parameter;

            var guards = new List<Expression>();
            var parts = path.Split('.');

            for (int i = 0; i < parts.Length; i++)
            {
                var part = parts[i];

                if (string.IsNullOrWhiteSpace(part))
                {
                    throw new ArgumentException(
                        "Invalid field path."
                    );
                }

                var property = GetProperty(
                    current.Type,
                    part
                );

                current = Expression.Property(
                    current,
                    property
                );

                if (i < parts.Length - 1)
                {
                    if (GetCollectionElementType(current.Type)
                        != null)
                    {
                        throw new ArgumentException(
                            $"Collection '{part}' requires Any()."
                        );
                    }

                    if (CanBeNull(current.Type))
                    {
                        guards.Add(
                            Expression.NotEqual(
                                current,
                                Expression.Constant(
                                    null,
                                    current.Type
                                )
                            )
                        );
                    }
                }
            }

            return ((MemberExpression)current, guards);
        }

        private static string? GetCollectionPath(
            Type rootType,
            string fieldPath)
        {
            if (string.IsNullOrWhiteSpace(fieldPath))
            {
                throw new ArgumentException(
                    "Field is required."
                );
            }

            var parts = fieldPath.Split('.');
            var currentType = rootType;

            for (int i = 0; i < parts.Length; i++)
            {
                if (string.IsNullOrWhiteSpace(parts[i]))
                {
                    throw new ArgumentException(
                        "Invalid field path."
                    );
                }

                var property = GetProperty(
                    currentType,
                    parts[i]
                );

                var elementType = GetCollectionElementType(
                    property.PropertyType
                );

                if (elementType != null)
                {
                    if (i == parts.Length - 1)
                    {
                        throw new ArgumentException(
                            $"Collection '{parts[i]}' " +
                            "requires a child property."
                        );
                    }

                    return string.Join(".", parts.Take(i + 1));
                }

                currentType = Nullable.GetUnderlyingType(
                    property.PropertyType
                ) ?? property.PropertyType;
            }

            return null;
        }

        private static Type? GetCollectionElementType(
            Type type)
        {
            if (type == typeof(string))
                return null;

            var collectionType = type
                .GetInterfaces()
                .Concat(new[] { type })
                .FirstOrDefault(t =>
                    t.IsGenericType &&
                    t.GetGenericTypeDefinition()
                        == typeof(IEnumerable<>)
                );

            return collectionType?.GetGenericArguments()[0];
        }

        private static PropertyInfo GetProperty(
            Type type,
            string name)
        {
            var property = type.GetProperty(
                name,
                BindingFlags.Public |
                BindingFlags.Instance |
                BindingFlags.IgnoreCase
            );

            if (property == null ||
                property.GetIndexParameters().Length > 0)
            {
                throw new ArgumentException(
                    $"Property '{name}' does not exist " +
                    $"in '{type.Name}'."
                );
            }

            return property;
        }

        private static bool CanBeNull(Type type)
        {
            return !type.IsValueType ||
                   Nullable.GetUnderlyingType(type) != null;
        }


        private static Expression BuildCondition(
            MemberExpression member,
            DynamicFilter filter)
        {
            if (string.IsNullOrWhiteSpace(filter.Operator))
            {
                throw new ArgumentException(
                    "Filter operator is required."
                );
            }

            var op = filter.Operator.Trim().ToLowerInvariant();

            var type = member.Type;
            var underlying = Nullable.GetUnderlyingType(type)
                             ?? type;

            if (op is "isnull" or "isnotnull")
            {
                if (!CanBeNull(type))
                {
                    throw new ArgumentException(
                        $"'{filter.Field}' is not nullable."
                    );
                }

                var isNull = Expression.Equal(
                    member,
                    Expression.Constant(null, type)
                );

                return op == "isnull"
                    ? isNull
                    : Expression.Not(isNull);
            }

            if (filter.Value.ValueKind is
                JsonValueKind.Null or JsonValueKind.Undefined)
            {
                throw new ArgumentException(
                    $"A value is required for '{filter.Field}'."
                );
            }

            if (op is "contains" or "startswith" or "endswith")
            {
                if (type != typeof(string))
                {
                    throw new ArgumentException(
                        $"{filter.Operator} requires a string field."
                    );
                }

                var value = ConvertValue(
                    filter.Value,
                    typeof(string)
                );

                var methodName = op switch
                {
                    "contains" => nameof(string.Contains),
                    "startswith" => nameof(string.StartsWith),
                    _ => nameof(string.EndsWith)
                };

                var method = typeof(string).GetMethod(
                    methodName,
                    new[] { typeof(string) }
                )!;

                return Expression.AndAlso(
                    Expression.NotEqual(
                        member,
                        Expression.Constant(null, type)
                    ),
                    Expression.Call(
                        member,
                        method,
                        Expression.Constant(value, typeof(string))
                    )
                );
            }

            if (op == "in")
            {
                if (filter.Value.ValueKind != JsonValueKind.Array)
                {
                    throw new ArgumentException(
                        "'in' requires an array."
                    );
                }

                var values = filter.Value
                    .EnumerateArray()
                    .Select(v => ConvertValue(v, underlying))
                    .ToArray();

                if (values.Length == 0)
                    return Expression.Constant(false);

                var array = Array.CreateInstance(
                    underlying,
                    values.Length
                );

                for (int i = 0; i < values.Length; i++)
                    array.SetValue(values[i], i);

                Expression item = member;

                if (underlying != type)
                {
                    item = Expression.Convert(
                        member,
                        underlying
                    );
                }

                var contains = Expression.Call(
                    typeof(Enumerable),
                    nameof(Enumerable.Contains),
                    new[] { underlying },
                    Expression.Constant(
                        array,
                        underlying.MakeArrayType()
                    ),
                    item
                );

                if (underlying != type)
                {
                    return Expression.AndAlso(
                        Expression.NotEqual(
                            member,
                            Expression.Constant(null, type)
                        ),
                        contains
                    );
                }

                return contains;
            }

            var valueObject = ConvertValue(
                filter.Value,
                underlying
            );

            Expression right = Expression.Constant(
                valueObject,
                underlying
            );

            if (underlying != type)
            {
                right = Expression.Convert(right, type);
            }

            Expression comparison;

            try
            {
                comparison = op switch
                {
                    "eq" or "equals" =>
                        Expression.Equal(member, right),

                    "neq" or "notequals" =>
                        Expression.NotEqual(member, right),

                    "gt" or "greaterthan" =>
                        Expression.GreaterThan(member, right),

                    "gte" or "greaterthanorequal" =>
                        Expression.GreaterThanOrEqual(member, right),

                    "lt" or "lessthan" =>
                        Expression.LessThan(member, right),

                    "lte" or "lessthanorequal" =>
                        Expression.LessThanOrEqual(member, right),

                    _ => throw new ArgumentException(
                        $"Unsupported operator: {filter.Operator}"
                    )
                };
            }
            catch (InvalidOperationException ex)
            {
                throw new ArgumentException(
                    $"Operator '{filter.Operator}' is not " +
                    $"supported for field '{filter.Field}' " +
                    $"of type '{underlying.Name}'.",
                    ex
                );
            }

            if (underlying != type &&
                op is "gt" or "greaterthan"
                    or "gte" or "greaterthanorequal"
                    or "lt" or "lessthan"
                    or "lte" or "lessthanorequal")
            {
                return Expression.AndAlso(
                    Expression.NotEqual(
                        member,
                        Expression.Constant(null, type)
                    ),
                    comparison
                );
            }

            return comparison;
        }

        private static object ConvertValue(
            JsonElement value,
            Type type)
        {
            try
            {
                if (type == typeof(string))
                {
                    return value.GetString()
                        ?? throw new ArgumentException(
                            "Expected string."
                        );
                }

                if (type == typeof(Guid))
                {
                    return Guid.Parse(value.GetString()!);
                }

                if (type == typeof(DateOnly))
                {
                    return DateOnly.ParseExact(
                        value.GetString()!,
                        "yyyy-MM-dd",
                        CultureInfo.InvariantCulture
                    );
                }

                if (type == typeof(DateTime))
                {
                    return DateTime.Parse(
                        value.GetString()!,
                        CultureInfo.InvariantCulture,
                        DateTimeStyles.RoundtripKind
                    );
                }

                if (type == typeof(DateTimeOffset))
                {
                    return DateTimeOffset.Parse(
                        value.GetString()!,
                        CultureInfo.InvariantCulture,
                        DateTimeStyles.RoundtripKind
                    );
                }

                if (type.IsEnum)
                {
                    var result =
                        value.ValueKind == JsonValueKind.String
                        ? Enum.Parse(
                            type,
                            value.GetString()!,
                            true
                        )
                        : Enum.ToObject(
                            type,
                            value.GetInt32()
                        );

                    if (!Enum.IsDefined(type, result))
                    {
                        throw new ArgumentException(
                            "Invalid enum value."
                        );
                    }

                    return result;
                }

                if (type == typeof(bool))
                {
                    return value.GetBoolean();
                }

                return Convert.ChangeType(
                    JsonToObject(value),
                    type,
                    CultureInfo.InvariantCulture
                );
            }
            catch (Exception ex) when (
                ex is FormatException
                or InvalidCastException
                or OverflowException
                or JsonException
                or ArgumentException)
            {
                throw new ArgumentException(
                    $"Invalid filter value '{value}' " +
                    $"for type '{type.Name}'.",
                    ex
                );
            }
        }

        private static object JsonToObject(JsonElement value)
        {
            return value.ValueKind switch
            {
                JsonValueKind.String => value.GetString()!,
                JsonValueKind.True => true,
                JsonValueKind.False => false,
                JsonValueKind.Number => value.GetDecimal(),

                _ => throw new ArgumentException(
                    "Unsupported JSON value type."
                )
            };
        }

        private static bool IsOr(string logicalOperator)
        {
            if (string.Equals(
                logicalOperator,
                "OR",
                StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            if (string.Equals(
                logicalOperator,
                "AND",
                StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            throw new ArgumentException(
                "Logical operator must be AND or OR."
            );
        }

        private static Expression CombineExpressions(
            Expression? left,
            Expression right,
            bool useOr)
        {
            if (left == null)
                return right;

            return useOr
                ? Expression.OrElse(left, right)
                : Expression.AndAlso(left, right);
        }
    }
}
