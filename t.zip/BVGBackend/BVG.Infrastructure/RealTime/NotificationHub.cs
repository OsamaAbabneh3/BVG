﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Infrastructure.RealTime
{
    public class NotificationHub:Hub
    {
    }
}
