﻿using BVG.Domain.Interfaces;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Infrastructure.RealTime
{
    public class InternalHub : Hub
    {
        private readonly INotificationRepository _repository;
        private readonly IConfiguration _config;

        public InternalHub(INotificationRepository repository, IConfiguration config)
        {
            _repository = repository;
            _config = config;
        }

        public override Task OnConnectedAsync()
        {
            var key = Context.GetHttpContext()?.Request.Query["key"].ToString();
            if (key != _config["InternalHub:Key"])
                Context.Abort();

            return base.OnConnectedAsync();
        }

        public Task SendToAll(string eventName, object data) =>
            _repository.SendToAllAsync(eventName, data);

        public Task SendToAllNoData(string eventName) =>
            _repository.SendToAllAsync(eventName);

        public Task SendToUser(string userId, string eventName, object data) =>
            _repository.SendToUserAsync(userId, eventName, data);
    }
}
