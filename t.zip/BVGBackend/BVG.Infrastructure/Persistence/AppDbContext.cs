﻿using System;
using System.Collections.Generic;
using BVG.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace BVG.Infrastructure.Persistence;

public partial class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<AuditLog> AuditLogs { get; set; }

    public virtual DbSet<BackgroundJob> BackgroundJobs { get; set; }

    public virtual DbSet<BvgUser> BvgUsers { get; set; }

    public virtual DbSet<CycleInfo> CycleInfos { get; set; }

    public virtual DbSet<CycleInfoRuningStatus> CycleInfoRuningStatuses { get; set; }

    public virtual DbSet<DualAuthorizationApproval> DualAuthorizationApprovals { get; set; }

    public virtual DbSet<DualAuthorizationRequest> DualAuthorizationRequests { get; set; }

    public virtual DbSet<EmailLog> EmailLogs { get; set; }

    public virtual DbSet<Fingerprint> Fingerprints { get; set; }

    public virtual DbSet<InvoiceException> InvoiceExceptions { get; set; }

    public virtual DbSet<OtpCode> OtpCodes { get; set; }

    public virtual DbSet<Permission> Permissions { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<RolePermission> RolePermissions { get; set; }

    public virtual DbSet<RuleCatalog> RuleCatalogs { get; set; }

    public virtual DbSet<RuleFamily> RuleFamilies { get; set; }

    public virtual DbSet<RuleModeHistory> RuleModeHistories { get; set; }

    public virtual DbSet<SnapshotBulk> SnapshotBulks { get; set; }

    public virtual DbSet<UserRole> UserRoles { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AuditLog>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__AuditLog__3214EC077D4EA37A");

            entity.ToTable("AuditLog");

            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(sysutcdatetime())", "DF_1221579390_CreatedAt");
            entity.Property(e => e.EntityRowId)
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.HasOne(d => d.User).WithMany(p => p.AuditLogs)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK__AuditLog__UserId__123EB7A3");
        });

        modelBuilder.Entity<BackgroundJob>(entity =>
        {
            entity.Property(e => e.WorkerId).HasMaxLength(450);

            entity.HasOne(d => d.SnapshotBulk).WithMany(p => p.BackgroundJobs)
                .HasForeignKey(d => d.SnapshotBulkId)
                .HasConstraintName("FK_BackgroundJobs_SnapshotBulk");
        });

        modelBuilder.Entity<BvgUser>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__BvgUser__3214EC072EFE4259");

            entity.ToTable("BvgUser");

            entity.Property(e => e.Id).HasDefaultValueSql("(newsequentialid())");
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(sysutcdatetime())");
            entity.Property(e => e.Email).HasMaxLength(255);
            entity.Property(e => e.FirstName).HasMaxLength(100);
            entity.Property(e => e.LastName).HasMaxLength(100);
            entity.Property(e => e.MustChangePassword).HasDefaultValue(true);
            entity.Property(e => e.PasswordHash).HasMaxLength(255);
            entity.Property(e => e.PhoneNumber).HasMaxLength(10);
            entity.Property(e => e.UserName).HasMaxLength(100);
        });

        modelBuilder.Entity<CycleInfo>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__CycleInf__3214EC07F48AF217");

            entity.ToTable("CycleInfo");

            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(getdate())");
        });

        modelBuilder.Entity<CycleInfoRuningStatus>(entity =>
        {
            entity.ToTable("CycleInfoRuningStatus");

            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(sysdatetime())");

            entity.HasOne(d => d.SnapshotBulk).WithMany(p => p.CycleInfoRuningStatuses)
                .HasForeignKey(d => d.SnapshotBulkId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_CycleInfoRuningStatus_SnapshotBulk");
        });

        modelBuilder.Entity<DualAuthorizationApproval>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__DualAuth__3214EC07B6043772");

            entity.ToTable("DualAuthorizationApproval");

            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(sysutcdatetime())");
            entity.Property(e => e.Justification).HasMaxLength(1000);

            entity.HasOne(d => d.ApproverUser).WithMany(p => p.DualAuthorizationApprovals)
                .HasForeignKey(d => d.ApproverUserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DAA_User");

            entity.HasOne(d => d.DualAuthorizationRequest).WithMany(p => p.DualAuthorizationApprovals)
                .HasForeignKey(d => d.DualAuthorizationRequestId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DualAuthorizationApproval_Request");
        });

        modelBuilder.Entity<DualAuthorizationRequest>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__DualAuth__3214EC071150E26B");

            entity.ToTable("DualAuthorizationRequest");

            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(sysutcdatetime())");
            entity.Property(e => e.Description).HasMaxLength(1000);

            entity.HasOne(d => d.SnapshotBulk).WithMany(p => p.DualAuthorizationRequests)
                .HasForeignKey(d => d.SnapshotBulkId)
                .HasConstraintName("FK_DualAuthorizationRequest_SnapshotBulk");
        });

        modelBuilder.Entity<EmailLog>(entity =>
        {
            entity.ToTable("EmailLog");

            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(sysdatetime())");
            entity.Property(e => e.Subject).HasMaxLength(500);
        });

        modelBuilder.Entity<Fingerprint>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Fingerpr__3214EC079E91A0F0");

            entity.ToTable("Fingerprint");

            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(getdate())");

            entity.HasOne(d => d.SnapshotBulk).WithMany(p => p.Fingerprints)
                .HasForeignKey(d => d.SnapshotBulkId)
                .HasConstraintName("FK_Fingerprint_SnapshotBulk");
        });

        modelBuilder.Entity<InvoiceException>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__InvoiceE__3214EC07362B907F");

            entity.ToTable("InvoiceException");

            entity.HasIndex(e => new { e.SnapshotBulkId, e.RuleId, e.AccountNumber }, "UQ_dup").IsUnique();

            entity.Property(e => e.AccountNumber).HasMaxLength(50);
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(getdate())");

            entity.HasOne(d => d.Rule).WithMany(p => p.InvoiceExceptions)
                .HasForeignKey(d => d.RuleId)
                .HasConstraintName("FK_InvoiceException_RuleCatalog");

            entity.HasOne(d => d.SnapshotBulk).WithMany(p => p.InvoiceExceptions)
                .HasForeignKey(d => d.SnapshotBulkId)
                .HasConstraintName("FK_InvoiceException_SnapshotBulk");
        });

        modelBuilder.Entity<OtpCode>(entity =>
        {
            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.CodeHash).HasMaxLength(128);
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(sysutcdatetime())", "DF_1637580872_CreatedAt");
            entity.Property(e => e.RequestToken).HasMaxLength(64);
            entity.Property(e => e.Username).HasMaxLength(100);
        });

        modelBuilder.Entity<Permission>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Permissi__3214EC0729CB33C8");

            entity.ToTable("Permission");

            entity.Property(e => e.Id).HasDefaultValueSql("(newsequentialid())");
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(sysutcdatetime())", "DF_1429580131_CreatedAt");
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.NameAr).HasMaxLength(100);
            entity.Property(e => e.PermissionName).HasMaxLength(100);
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Role__3214EC07FD377EF0");

            entity.ToTable("Role");

            entity.Property(e => e.Id).HasDefaultValueSql("(newsequentialid())");
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(sysutcdatetime())", "DF_1493580359_CreatedAt");
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.NameAr).HasMaxLength(100);
            entity.Property(e => e.RoleName).HasMaxLength(100);
        });

        modelBuilder.Entity<RolePermission>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__RolePerm__3214EC0751728957");

            entity.ToTable("RolePermission");

            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(sysutcdatetime())", "DF_1557580587_CreatedAt");

            entity.HasOne(d => d.Permission).WithMany(p => p.RolePermissions)
                .HasForeignKey(d => d.PermissionId)
                .HasConstraintName("FK__RolePermi__Permi__1AD3FDA4");

            entity.HasOne(d => d.Role).WithMany(p => p.RolePermissions)
                .HasForeignKey(d => d.RoleId)
                .HasConstraintName("FK__RolePermi__RoleI__1BC821DD");
        });

        modelBuilder.Entity<RuleCatalog>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__RuleCata__3214EC071B96B23B");

            entity.ToTable("RuleCatalog");

            entity.Property(e => e.AlertBudget).HasColumnType("decimal(6, 5)");
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(sysutcdatetime())", "DF_1589580701_CreatedAt");
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.RuleCode).HasMaxLength(10);
            entity.Property(e => e.RuleName).HasMaxLength(50);
            entity.Property(e => e.Version).HasMaxLength(20);

            entity.HasOne(d => d.Family).WithMany(p => p.RuleCatalogs)
                .HasForeignKey(d => d.FamilyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RuleCatalog_RuleFamily");
        });

        modelBuilder.Entity<RuleFamily>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__RuleFami__3214EC0705AC987A");

            entity.ToTable("RuleFamily");

            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(sysutcdatetime())", "DF_1701581100_CreatedAt");
            entity.Property(e => e.FamilyName).HasMaxLength(50);
            entity.Property(e => e.RuleFamilyCode).HasMaxLength(50);
        });

        modelBuilder.Entity<RuleModeHistory>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__RuleMode__3214EC079EF01628");

            entity.ToTable("RuleModeHistory");

            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(sysutcdatetime())", "DF_1749581271_CreatedAt");

            entity.HasOne(d => d.Cycle).WithMany(p => p.RuleModeHistories)
                .HasForeignKey(d => d.CycleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RuleModeHistory_CycleInfo");

            entity.HasOne(d => d.Rule).WithMany(p => p.RuleModeHistories)
                .HasForeignKey(d => d.RuleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RuleModeHistory_RuleCatalog");
        });

        modelBuilder.Entity<SnapshotBulk>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Snapshot__3214EC07C96F1CA2");

            entity.ToTable("SnapshotBulk");

            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(getdate())");
            entity.Property(e => e.Status).HasColumnName("status");

            entity.HasOne(d => d.Cycle).WithMany(p => p.SnapshotBulks)
                .HasForeignKey(d => d.CycleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SnapshotBulk_CycleInfo");
        });

        modelBuilder.Entity<UserRole>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__UserRole__3214EC07922007C7");

            entity.ToTable("UserRole");

            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(sysutcdatetime())", "DF_1781581385_CreatedAt");

            entity.HasOne(d => d.Role).WithMany(p => p.UserRoles)
                .HasForeignKey(d => d.RoleId)
                .HasConstraintName("FK__UserRole__RoleId__208CD6FA");

            entity.HasOne(d => d.User).WithMany(p => p.UserRoles)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK__UserRole__UserId__2180FB33");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
