﻿using BVG.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Infrastructure.Persistence
{
    public partial class SnapshotDbContext : DbContext
    {
        public SnapshotDbContext(DbContextOptions<SnapshotDbContext> options)
        : base(options)
        {
        }
    }
}
