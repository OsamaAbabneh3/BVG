﻿using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace Helper.EmailBody
{
    public static class EmailBody
    {
        public static string SubjectCreateAccount = "Create New Account";
        public static string GenerateEmailBody(string body)
        {
            string bvgLogo = GetImage("bvg-logo.png");
            string idecoLogo = GetImage("ideco-mark.png");
            var dateText = DateTime.Now.ToString("dd'/'MM'/'yyyy HH:mm", CultureInfo.InvariantCulture);

            var mailbody= $@"<!DOCTYPE html>
<html lang=""ar"" dir=""rtl"" xmlns:v=""urn:schemas-microsoft-com:vml"" xmlns:o=""urn:schemas-microsoft-com:office:office"">
<head>
  <meta charset=""utf-8"">
  <meta name=""viewport"" content=""width=device-width, initial-scale=1"">
  <style type=""text/css"">
    body {{
      margin: 0;
      padding: 0;
      -webkit-text-size-adjust: 100%;
      -ms-text-size-adjust: 100%;
    }}

    table,
    td {{
      border-collapse: collapse;
      border: 0;
      border-spacing: 0;
      mso-table-lspace: 0pt;
      mso-table-rspace: 0pt;
    }}

    img {{
      border: 0;
      outline: none;
      text-decoration: none;
      -ms-interpolation-mode: bicubic;
      display: block;
    }}

    a {{
      text-decoration: none;
    }}

    @media only screen and (max-width:660px) {{
      .wrap {{
        width: 100% !important;
      }}

      .pad {{
        padding-left: 22px !important;
        padding-right: 22px !important;
      }}
    }}
  </style>
</head>

<body dir=""rtl""
  style=""margin:0;padding:0;background-color:#E6EBF2;font-family:'Segoe UI', Tahoma, Arial, sans-serif;direction:rtl;"">
  <table role=""presentation"" dir=""rtl"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" bgcolor=""#E6EBF2""
    style=""background-color:#E6EBF2;"">
    <tr>
      <td align=""center"" style=""padding:32px 10px;"">

        <table role=""presentation"" dir=""rtl"" class=""wrap"" width=""640"" cellpadding=""0"" cellspacing=""0"" border=""0""
          bgcolor=""#FFFFFF"" style=""width:640px;background-color:#FFFFFF;"">

          <!-- Header: logo + date -->
          <tr>
            <td class=""pad"" bgcolor=""#FFFFFF"" style=""background-color:#FFFFFF;padding:30px 44px 26px;"">
              <table role=""presentation"" dir=""rtl"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" bgcolor=""#FFFFFF""
                style=""background-color:#FFFFFF;"">
                <tr>
                  <td align=""right"" valign=""middle"" width=""170"" bgcolor=""#FFFFFF"" style=""background-color:#FFFFFF;"">
                    <img src=""{bvgLogo}"" width=""150"" height=""116"" alt=""BVG - بوابة تدقيق الفواتير"" style=""display:block;border:0;width:150px;height:116px;color:#004B8D;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:20px;font-weight:bold;"">
                  </td>
                  <td align=""left"" valign=""middle"" bgcolor=""#FFFFFF"" style=""background-color:#FFFFFF;"">
                    <table role=""presentation"" dir=""ltr"" align=""left"" cellpadding=""0"" cellspacing=""0"" border=""0"" bgcolor=""#FFFFFF""
                      style=""background-color:#FFFFFF;"">
                      <tr>
                        <td align=""left"" dir=""rtl"" style=""padding-top:8px;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:12px;line-height:20px;color:#6B7B8E;"">التاريخ</td>
                      </tr>
                      <tr>
                        <td align=""left"" dir=""ltr"" style=""font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:22px;font-weight:bold;color:#0A2F57;"">{dateText}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Top color bar -->
          <tr>
            <td style=""font-size:0;line-height:0;"">
              <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"">
                <tr>
                  <td width=""55%"" height=""5"" bgcolor=""#1266B0""
                    style=""height:5px;font-size:1px;line-height:5px;mso-line-height-rule:exactly;"">&nbsp;</td>
                  <td width=""30%"" height=""5"" bgcolor=""#7FC4EA""
                    style=""height:5px;font-size:1px;line-height:5px;mso-line-height-rule:exactly;"">&nbsp;</td>
                  <td width=""15%"" height=""5"" bgcolor=""#6B2FA0""
                    style=""height:5px;font-size:1px;line-height:5px;mso-line-height-rule:exactly;"">&nbsp;</td>
                </tr>
              </table>
            </td>
          </tr>

{body}

          <!-- Signature -->
          <tr>
            <td class=""pad"" bgcolor=""#FFFFFF"" style=""background-color:#FFFFFF;padding:34px 44px 38px;"">
              <table role=""presentation"" dir=""rtl"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" bgcolor=""#FFFFFF""
                style=""background-color:#FFFFFF;"">
                <tr>
                  <td align=""right""
                    style=""border-top:1px solid #E3E9F1;padding-top:20px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:24px;mso-line-height-rule:exactly;color:#33475F;"">
                    مع خالص التحية،<br><strong style=""color:#0A2F57;font-size:15px;"">فريق بوابة تدقيق الفواتير</strong><br><span style=""color:#6B7B8E;font-size:13px;"">شركة كهرباء محافظة إربد</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Footer: IDECO -->
          <tr>
            <td class=""pad"" bgcolor=""#F1F6FC""
              style=""background-color:#F1F6FC;border-top:1px solid #E3E9F1;padding:30px 44px 26px;font-family:'Segoe UI', Tahoma, Arial, sans-serif;"">
              <table role=""presentation"" dir=""rtl"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" bgcolor=""#F1F6FC""
                style=""background-color:#F1F6FC;"">
                <tr>
                  <td colspan=""2"" bgcolor=""#F1F6FC"" style=""background-color:#F1F6FC;"">
                    <table role=""presentation"" dir=""rtl"" align=""right"" cellpadding=""0"" cellspacing=""0"" border=""0"" bgcolor=""#F1F6FC""
                      style=""background-color:#F1F6FC;"">
                      <tr>
                        <td align=""right"" valign=""middle"" width=""46"" bgcolor=""#F1F6FC""
                          style=""width:46px;padding-left:10px;background-color:#F1F6FC;"">
                          <img src=""{idecoLogo}"" width=""46"" height=""44"" alt=""IDECO"" style=""display:block;border:0;width:46px;height:44px;"">
                        </td>
                        <td align=""right"" valign=""middle"" bgcolor=""#F1F6FC"" style=""background-color:#F1F6FC;"">
                          <table role=""presentation"" dir=""rtl"" cellpadding=""0"" cellspacing=""0"" border=""0"" bgcolor=""#F1F6FC""
                            style=""background-color:#F1F6FC;"">
                            <tr>
                              <td align=""right"" dir=""rtl"" style=""font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:16px;line-height:24px;font-weight:bold;color:#0A2F57;"">شركة كهرباء محافظة إربد</td>
                            </tr>
                            <tr>
                              <td align=""right"" dir=""ltr"" style=""font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:11px;line-height:16px;letter-spacing:4px;color:#6B7B8E;text-align:right;"">IDECO</td>
                            </tr>
                          </table>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td colspan=""2"" style=""padding-top:18px;"">
                    <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"">
                      <tr>
                        <td height=""1"" bgcolor=""#DCE5EF""
                          style=""height:1px;background-color:#DCE5EF;font-size:1px;line-height:1px;mso-line-height-rule:exactly;"">&nbsp;</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td colspan=""2"" align=""right""
                    style=""padding-top:16px;text-align:right;font-size:12px;line-height:22px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    هذه رسالة آلية من بوابة تدقيق الفواتير، يرجى عدم الرد عليها. المعلومات الواردة فيها سرية ومخصصة للمستلم فقط.</td>
                </tr>
                <tr>
                  <td colspan=""2"" align=""right""
                    style=""padding-top:8px;text-align:right;font-size:11px;line-height:18px;color:#8593A3;"">&copy; {DateTime.Now.Year} شركة كهرباء محافظة إربد</td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Bottom color bar -->
          <tr>
            <td style=""font-size:0;line-height:0;"">
              <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"">
                <tr>
                  <td width=""15%"" height=""4"" bgcolor=""#6B2FA0""
                    style=""height:4px;font-size:1px;line-height:4px;mso-line-height-rule:exactly;"">&nbsp;</td>
                  <td width=""30%"" height=""4"" bgcolor=""#7FC4EA""
                    style=""height:4px;font-size:1px;line-height:4px;mso-line-height-rule:exactly;"">&nbsp;</td>
                  <td width=""55%"" height=""4"" bgcolor=""#1266B0""
                    style=""height:4px;font-size:1px;line-height:4px;mso-line-height-rule:exactly;"">&nbsp;</td>
                </tr>
              </table>
            </td>
          </tr>
        </table>

      </td>
    </tr>
  </table>
</body>

</html>";
            return mailbody;
        }

        public static string GenerateEmilStartAudit(string body)
        {
            var startAuditMail = $@"
          <tr>
            <td class=""pad"" align=""right"" bgcolor=""#F1F6FC""
              style=""background-color:#F1F6FC;border-bottom:1px solid #E3E9F1;padding:30px 44px 28px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;"">
              <div style=""font-size:28px;line-height:40px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                بدء التدقيق على الدورة</div>
              <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""margin-top:12px;"">
                <tr>
                  <td width=""46"" height=""3"" bgcolor=""#1266B0""
                    style=""width:46px;height:3px;background-color:#1266B0;font-size:1px;line-height:3px;mso-line-height-rule:exactly;"">
                    &nbsp;</td>
                </tr>
              </table>
            </td>
          </tr>

          <tr>
            <td class=""pad"" align=""right""
              style=""padding:38px 44px 0;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:15px;line-height:28px;mso-line-height-rule:exactly;color:#33475F;"">
              <div style=""font-size:17px;line-height:28px;font-weight:bold;color:#0A2F57;"">عزيزي المستخدم،</div>
              <div style=""margin-top:8px;"">نفيدكم بأنه تم بدء تدقيق فواتير الدورة الموضحة أدناه، وسنوافيكم برسالة عند
                اكتمال التدقيق.</div>
            </td>
          </tr>

          <tr>
            <td class=""pad"" style=""padding:32px 44px 0;"">
              <div
                style=""font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:16px;line-height:26px;font-weight:bold;color:#0A2F57;text-align:right;"">
                تفاصيل الدورة</div>
              <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""margin:6px 0 14px;"">
                <tr>
                  <td width=""30"" height=""2"" bgcolor=""#7FC4EA""
                    style=""width:30px;height:2px;background-color:#7FC4EA;font-size:1px;line-height:2px;mso-line-height-rule:exactly;"">
                    &nbsp;</td>
                </tr>
              </table>
              <table role=""presentation"" dir=""rtl"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0""
                bgcolor=""#FBFCFE""
                style=""background-color:#FBFCFE;border:1px solid #E3E9F1;border-top:3px solid #004B8D;"">
                <tr>
                  <td width=""38%"" align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    حالة التدقيق</td>
                  <td align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                    <span style=""color:#1266B0;font-weight:bold;"">&#9679;&nbsp;قيد التدقيق</span></td>
                </tr>
                <tr>
                  <td width=""38%"" align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    رقم الدورة</td>
                  <td align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                    <span dir=""ltr"" style=""direction:ltr;unicode-bidi:embed;"">{/*replace رقم الدورة*/ body}</span></td>
                </tr>
                <tr>
                  <td width=""38%"" align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    رقم الحزمة</td>
                  <td align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                    <span dir=""ltr"" style=""direction:ltr;unicode-bidi:embed;"">{/*replace رقم الحزمة*/ body}</span></td>
                </tr>
                <tr>
                  <td width=""38%"" align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    فترة الدورة</td>
                  <td align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                    {/*فترة الدورة */ body}</td>
                </tr>
                <tr>
                  <td width=""38%"" align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    عدد الفواتير</td>
                  <td align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                    {body /*عدد الفواتير*/} فاتورة</td>
                </tr>
                <tr>
                  <td width=""38%"" align=""right""
                    style=""padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    وقت البدء</td>
                  <td align=""right""
                    style=""padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                    <span dir=""ltr"" style=""direction:ltr;unicode-bidi:embed;"">{/*وقت البدء*/ body}</span></td>
                </tr>
              </table>
            </td>
          </tr>

          <tr>
            <td class=""pad"" style=""padding:30px 44px 0;"">
              <table role=""presentation"" dir=""rtl"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"">
                <tr>
                  <td width=""5"" bgcolor=""#1266B0""
                    style=""width:5px;background-color:#1266B0;font-size:1px;line-height:1px;"">&nbsp;</td>
                  <td bgcolor=""#F2F6FA"" align=""right""
                    style=""background-color:#F2F6FA;padding:16px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:24px;mso-line-height-rule:exactly;color:#33475F;"">
                    <strong style=""font-size:14px;"">ملاحظة</strong><br>لا يلزمكم أي إجراء في الوقت الحالي، ويمكنكم
                    متابعة التقدم من البوابة في أي وقت.</td>
                </tr>
              </table>
            </td>
          </tr>
";
            return startAuditMail;

        }

        public static string GenerateEmilEndAudit(string body)
        {
            var endAuditMail = $@"<tr>
            <td class=""pad"" align=""right"" bgcolor=""#F1F6FC""
              style=""background-color:#F1F6FC;border-bottom:1px solid #E3E9F1;padding:30px 44px 28px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;"">
              <div style=""font-size:28px;line-height:40px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                انتهاء التدقيق لحزمة الفواتير</div>
              <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""margin-top:12px;"">
                <tr>
                  <td width=""46"" height=""3"" bgcolor=""#1266B0""
                    style=""width:46px;height:3px;background-color:#1266B0;font-size:1px;line-height:3px;mso-line-height-rule:exactly;"">
                    &nbsp;</td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- النص -->
          <tr>
            <td class=""pad"" align=""right""
              style=""padding:38px 44px 0;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:15px;line-height:28px;mso-line-height-rule:exactly;color:#33475F;"">
              <div style=""font-size:17px;line-height:28px;font-weight:bold;color:#0A2F57;"">عزيزي المستخدم،</div>
              <div style=""margin-top:8px;"">نفيدكم بأنه تم الانتهاء من تدقيق حزمة الفواتير الموضحة أدناه، وفيما يلي ملخص
                النتائج.</div>
            </td>
          </tr>

          <tr>
            <td class=""pad"" style=""padding:32px 44px 0;"">
              <div
                style=""font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:16px;line-height:26px;font-weight:bold;color:#0A2F57;text-align:right;"">
                تفاصيل الحزمة</div>
              <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""margin:6px 0 14px;"">
                <tr>
                  <td width=""30"" height=""2"" bgcolor=""#7FC4EA""
                    style=""width:30px;height:2px;background-color:#7FC4EA;font-size:1px;line-height:2px;mso-line-height-rule:exactly;"">
                    &nbsp;</td>
                </tr>
              </table>
              <table role=""presentation"" dir=""rtl"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0""
                bgcolor=""#FBFCFE""
                style=""background-color:#FBFCFE;border:1px solid #E3E9F1;border-top:3px solid #004B8D;"">
                <tr>
                  <td width=""38%"" align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    حالة التدقيق</td>
                  <td align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                    <span style=""color:#1E7B46;font-weight:bold;"">&#9679;&nbsp;اكتمل التدقيق</span></td>
                </tr>
                <tr>
                  <td width=""38%"" align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    رقم الحزمة</td>
                  <td align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                    <span dir=""ltr"" style=""direction:ltr;unicode-bidi:embed;"">B-0457</span></td>
                </tr>
                <tr>
                  <td width=""38%"" align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    الدورة</td>
                  <td align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                    <span dir=""ltr"" style=""direction:ltr;unicode-bidi:embed;"">2026-10</span></td>
                </tr>
                <tr>
                  <td width=""38%"" align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    وقت الانتهاء</td>
                  <td align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                    <span dir=""ltr"" style=""direction:ltr;unicode-bidi:embed;"">09/11/2026 - 10:12 AM</span></td>
                </tr>
                <tr>
                  <td width=""38%"" align=""right""
                    style=""padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    مدة التدقيق</td>
                  <td align=""right""
                    style=""padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                    102 دقيقة</td>
                </tr>
              </table>
            </td>
          </tr>

          
          <tr>
            <td class=""pad"" style=""padding:32px 44px 0;"">
              <div
                style=""font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:16px;line-height:26px;font-weight:bold;color:#0A2F57;text-align:right;"">
                نتائج التدقيق</div>
              <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""margin:6px 0 14px;"">
                <tr>
                  <td width=""30"" height=""2"" bgcolor=""#7FC4EA""
                    style=""width:30px;height:2px;background-color:#7FC4EA;font-size:1px;line-height:2px;mso-line-height-rule:exactly;"">
                    &nbsp;</td>
                </tr>
              </table>
              <table role=""presentation"" dir=""rtl"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0""
                bgcolor=""#FBFCFE""
                style=""background-color:#FBFCFE;border:1px solid #E3E9F1;border-top:3px solid #004B8D;"">
                <tr>
                  <td width=""6"" bgcolor=""#F2F6FA""
                    style=""width:6px;background-color:#F2F6FA;border-bottom:1px solid #E3E9F1;font-size:1px;line-height:1px;"">
                    &nbsp;</td>
                  <td align=""right""
                    style=""background-color:#F2F6FA;border-bottom:1px solid #E3E9F1;padding:11px 16px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:12px;line-height:18px;font-weight:bold;color:#6B7B8E;""
                    bgcolor=""#F2F6FA"">البند</td>
                  <td align=""center""
                    style=""background-color:#F2F6FA;border-bottom:1px solid #E3E9F1;padding:11px 16px;text-align:center;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:12px;line-height:18px;font-weight:bold;color:#6B7B8E;""
                    bgcolor=""#F2F6FA"">العدد</td>
                  <td align=""center""
                    style=""background-color:#F2F6FA;border-bottom:1px solid #E3E9F1;padding:11px 16px;text-align:center;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:12px;line-height:18px;font-weight:bold;color:#6B7B8E;""
                    bgcolor=""#F2F6FA"">النسبة</td>
                </tr>
                <tr>
                  <td width=""6"" bgcolor=""#004B8D""
                    style=""width:6px;background-color:#004B8D;font-size:1px;line-height:1px;border-bottom:1px solid #E3E9F1;"">
                    &nbsp;</td>
                  <td align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:15px 16px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;color:#33475F;"">
                    إجمالي الفواتير</td>
                  <td align=""center""
                    style=""border-bottom:1px solid #E3E9F1;padding:15px 16px;text-align:center;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:17px;line-height:22px;font-weight:bold;color:#004B8D;"">
                    1,248</td>
                  <td align=""center""
                    style=""border-bottom:1px solid #E3E9F1;padding:15px 16px;text-align:center;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;color:#6B7B8E;"">
                    100%</td>
                </tr>
                <tr>
                  <td width=""6"" bgcolor=""#1E7B46""
                    style=""width:6px;background-color:#1E7B46;font-size:1px;line-height:1px;border-bottom:1px solid #E3E9F1;"">
                    &nbsp;</td>
                  <td align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:15px 16px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;color:#33475F;"">
                    فواتير مطابقة</td>
                  <td align=""center""
                    style=""border-bottom:1px solid #E3E9F1;padding:15px 16px;text-align:center;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:17px;line-height:22px;font-weight:bold;color:#1E7B46;"">
                    1,236</td>
                  <td align=""center""
                    style=""border-bottom:1px solid #E3E9F1;padding:15px 16px;text-align:center;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;color:#6B7B8E;"">
                    99.04%</td>
                </tr>
                <tr>
                  <td width=""6"" bgcolor=""#C47A00""
                    style=""width:6px;background-color:#C47A00;font-size:1px;line-height:1px;"">&nbsp;</td>
                  <td align=""right""
                    style=""padding:15px 16px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;color:#33475F;"">
                    فواتير بها ملاحظات</td>
                  <td align=""center""
                    style=""padding:15px 16px;text-align:center;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:17px;line-height:22px;font-weight:bold;color:#C47A00;"">
                    12</td>
                  <td align=""center""
                    style=""padding:15px 16px;text-align:center;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;color:#6B7B8E;"">
                    0.96%</td>
                </tr>
              </table>
            </td>
          </tr>
            <tr>
            <td class=""pad"" style=""padding:30px 44px 0;"">
              <table role=""presentation"" dir=""rtl"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"">
                <tr>
                  <td width=""5"" bgcolor=""#C47A00""
                    style=""width:5px;background-color:#C47A00;font-size:1px;line-height:1px;"">&nbsp;</td>
                  <td bgcolor=""#FFF8E6"" align=""right""
                    style=""background-color:#FFF8E6;padding:16px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:24px;mso-line-height-rule:exactly;color:#6B4E00;"">
                    <strong style=""font-size:14px;"">يتطلب مراجعة</strong><br>الفواتير التي بها ملاحظات تحتاج مراجعة
                    يدوية قبل اعتمادها، وتجدونها في تبويب الملاحظات داخل البوابة.</td>
                </tr>
              </table>
            </td>
          </tr>
";
            return endAuditMail;

        }


        public static string GenerateEmailCreateAccount(AccountCreatedSentDto accountCreatedSentDto)
        {
            var createAccountMail = $@"<tr>
            <td class=""pad"" align=""right"" bgcolor=""#F1F6FC""
              style=""background-color:#F1F6FC;border-bottom:1px solid #E3E9F1;padding:30px 44px 28px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;"">
              <div style=""font-size:28px;line-height:40px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                إنشاء حساب مستخدم</div>
              <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""margin-top:12px;"">
                <tr>
                  <td width=""46"" height=""3"" bgcolor=""#1266B0""
                    style=""width:46px;height:3px;background-color:#1266B0;font-size:1px;line-height:3px;mso-line-height-rule:exactly;"">
                    &nbsp;</td>
                </tr>
              </table>
            </td>
          </tr>

          <tr>
            <td class=""pad"" align=""right""
              style=""padding:38px 44px 0;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:15px;line-height:28px;mso-line-height-rule:exactly;color:#33475F;"">
              <div style=""font-size:17px;line-height:28px;font-weight:bold;color:#0A2F57;"">عزيزي المستخدم،</div>
              <div style=""margin-top:8px;"">نفيدكم بأنه تم إنشاء حساب لكم في بوابة تدقيق الفواتير</div>
            </td>
          </tr>

          <tr>
            <td class=""pad"" style=""padding:32px 44px 0;"">
              <div
                style=""font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:16px;line-height:26px;font-weight:bold;color:#0A2F57;text-align:right;"">
                بيانات الحساب</div>
              <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""margin:6px 0 14px;"">
                <tr>
                  <td width=""30"" height=""2"" bgcolor=""#7FC4EA""
                    style=""width:30px;height:2px;background-color:#7FC4EA;font-size:1px;line-height:2px;mso-line-height-rule:exactly;"">
                    &nbsp;</td>
                </tr>
              </table>
              <table role=""presentation"" dir=""rtl"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0""
                bgcolor=""#FBFCFE""
                style=""background-color:#FBFCFE;border:1px solid #E3E9F1;border-top:3px solid #004B8D;"">
                <tr>
                  <td width=""38%"" align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    اسم المستخدم</td>
                  <td align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                    <span dir=""ltr"" style=""direction:ltr;unicode-bidi:embed;"">{accountCreatedSentDto.UserName}</span></td>
                </tr>
                <tr>
                  <td width=""38%"" align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    الاسم الكامل</td>
                  <td align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                    {accountCreatedSentDto.FullName}</td>
                </tr>
                <tr>
                  <td width=""38%"" align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    البريد الإلكتروني</td>
                  <td align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                    <span dir=""ltr"" style=""direction:ltr;unicode-bidi:embed;"">{accountCreatedSentDto.Email}</span></td>
                </tr>
                <tr>
                  <td width=""38%"" align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:13px;line-height:20px;mso-line-height-rule:exactly;color:#6B7B8E;"">
                    كلمة المرور</td>
                  <td align=""right""
                    style=""border-bottom:1px solid #E3E9F1;padding:14px 22px;text-align:right;font-family:'Segoe UI', Tahoma, Arial, sans-serif;font-size:14px;line-height:20px;mso-line-height-rule:exactly;font-weight:bold;color:#0A2F57;"">
                    <span dir=""ltr"" style=""direction:ltr;unicode-bidi:embed;"">{accountCreatedSentDto.Password}</span></td>
                </tr>
              
              </table>
            </td>
          </tr>
";
            return createAccountMail;

        }

        public static string GetImage(string imageName)
        {
            var assembly = typeof(EmailBody).Assembly;
            var resources = assembly.GetManifestResourceNames();

            var resourceName = resources.FirstOrDefault(r =>
                r.EndsWith("." + imageName, StringComparison.OrdinalIgnoreCase))
                ?? throw new FileNotFoundException(
                    $"'{imageName}' not found in '{assembly.GetName().Name}'. Available: " +
                    (resources.Length == 0 ? "(none)" : string.Join(", ", resources)));

            using var stream = assembly.GetManifestResourceStream(resourceName)!;
            using var memoryStream = new MemoryStream();
            stream.CopyTo(memoryStream);

            var mimeType = Path.GetExtension(imageName).ToLowerInvariant() switch
            {
                ".png" => "image/png",
                ".jpg" or ".jpeg" => "image/jpeg",
                _ => "application/octet-stream"
            };

            return $"data:{mimeType};base64,{Convert.ToBase64String(memoryStream.ToArray())}";
        }




    }
}
