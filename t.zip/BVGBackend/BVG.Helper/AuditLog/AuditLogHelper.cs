﻿using BVG.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Localization;

namespace Helper.AuditLog
{
    public static class AuditLogHelper
    {
        public static string GenerateAuditLogDetails(
       IStringLocalizer localizer,
       SystemActionEnum action,
       params object[] args)
        {
            
            string key = action.ToString();
            var translatedText = localizer[key, args];
            return $"\u202B{translatedText}\u202C";
        }
    }
}
