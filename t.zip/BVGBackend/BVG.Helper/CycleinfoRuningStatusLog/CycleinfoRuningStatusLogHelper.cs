﻿using BVG.Domain.Enums;
using Microsoft.Extensions.Localization;
using System;
using System.Collections.Generic;
using System.Text;

namespace Helper.CycleinfoRuningStatusLog
{
    public static class CycleinfoRuningStatusLogHelper
    {
        public static string GenerateCycleInfoRuningStatusLogAction(
       IStringLocalizer localizer,
       CycleInfoRuningStatusActionEnum action,
       params object[] args)
        {

            string key = action.ToString();
            var translatedText = localizer[key, args];
            return $"\u202B{translatedText}\u202C";
        }
    }
}
