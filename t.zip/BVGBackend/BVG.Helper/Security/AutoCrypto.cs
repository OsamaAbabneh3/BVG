﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Helper.Security
{
    public static class AutoCrypto
    {
        private static readonly byte[] CryptoEngine = { 0x41, 0x76, 0x32, 0x69, 0x39, 0x38, 0x34 };

        public static string Process(string input)
        {
            if (string.IsNullOrEmpty(input)) return input;

            try
            {
                byte[] buffer = Convert.FromBase64String(input);
                for (int i = 0; i < buffer.Length; i++)
                {
                    buffer[i] = (byte)(buffer[i] ^ CryptoEngine[i % CryptoEngine.Length]);
                }
                return Encoding.UTF8.GetString(buffer);
            }
            catch
            {
                byte[] buffer = Encoding.UTF8.GetBytes(input);
                for (int i = 0; i < buffer.Length; i++)
                {
                    buffer[i] = (byte)(buffer[i] ^ CryptoEngine[i % CryptoEngine.Length]);
                }
                return Convert.ToBase64String(buffer);
            }
        }
    }
}
