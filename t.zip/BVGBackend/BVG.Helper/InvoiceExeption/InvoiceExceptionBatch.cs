﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Helper.InvoiceExeption
{
    public sealed class InvoiceExceptionBatch
    {
        private readonly List<InvoiceException> _invoiceExceptions = new();
        public void AddRange(IEnumerable<ExceptionResult> invoiceExceptions, long bulkId, long ruleId)
        {
            foreach (var invoiceException in invoiceExceptions) 
            {
                if (_invoiceExceptions.Any(ex => ex.AccountNumber == invoiceException.AccountNumber && ex.RuleId == ruleId && ex.SnapshotBulkId == bulkId))
                    continue;
                _invoiceExceptions.Add(new InvoiceException
                {
                    SnapshotBulkId = bulkId,
                    RuleId = ruleId,
                    AccountNumber = invoiceException.AccountNumber,
                    MonitoreStatus = 0,
                    CreatedAt = DateTime.UtcNow,
                });
            
            }
        }

        public List<InvoiceException> GetAll()
        {
            return _invoiceExceptions;
        }
    }
}
