﻿using BVG.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Helper.InvoiceExeption
{
    public class AuditContext
    {
        public ClaimedBackgroundJob Job { get; set; } = new();
        public long StartId {  get; set; }
        public long EndId {  get; set; }
        public long BulkId { get; set; }
        public long RuleId { get; set; }
        public InvoiceExceptionBatch ExceptionBatch { get; }=new InvoiceExceptionBatch();
    }
}
