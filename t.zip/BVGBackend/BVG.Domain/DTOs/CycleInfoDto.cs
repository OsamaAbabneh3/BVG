﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class GetCycleInfoDto
    {
        public long Id { get; set; }

        public DateOnly CycleDate { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }

    }
    public class AddCycleInfoDto
    {
        [Required]
        [DataType(DataType.Date)]
        public required DateOnly CycleDate { get; set; }
        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }



    }
    public class UpdateCycleInfoDto
    {
        [Required]
        public required long Id { get; set; }
        public DateTime? EndDate { get; set; }
    }
  
    public class CycleInfoFilterDto
    {
    }

    public record CycleRecord(int CycleYM);

    public record MigrateFullSnapshot(
        int BillingCycle,
        long BulkId,
        long FullSnapshot,
        long TouSnapshot,
        long NEMSnapshot,
        long TNXSnapshot,
        long DayNightSnapshot,
        long MeterChange,
        long IllegalConsumptionRecords,
        long SkippedIllegalConsumptionRecords
);
}