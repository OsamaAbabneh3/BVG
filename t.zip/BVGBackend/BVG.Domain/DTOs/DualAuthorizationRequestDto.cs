﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class DualAuthorizationRequestDto
    {
        public long Id { get; set; }
        public string? Description { get; set; }

        public bool? Status { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }

    }
    public class UpdateDualAuthorizationRequestDto
    {
        [Required]
        public required long Id { get; set; }
        public string? Description { get; set; }
        public bool? Status { get; set; }
        public long? SnapshotBulkId { get; set; }
    }
    public class AddDualAuthorizationRequestDto
    {
        [Required]
        public required string Description { get; set; }
        public bool? Status { get; set; }
        public long? SnapshotBulkId { get; set; }
    }
}
