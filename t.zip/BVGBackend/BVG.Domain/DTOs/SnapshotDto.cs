﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class SnapshotDto
    {
        [Required]
        [RegularExpression(@"^[12]\d{3}$")]
        public required string Year { get; set; } = string.Empty;

        [Required]
        [RegularExpression(@"^(0?[1-9]|1[0-2])$")]
        public required string Month {  get; set; } = string.Empty;
    }
}
