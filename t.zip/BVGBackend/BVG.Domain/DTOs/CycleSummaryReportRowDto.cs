﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class CycleSummaryReportRowDto
    {
        public long CycleId { get; set; }
        public string CycleDate { get; set; } = string.Empty;
        public long SnapshotBulkId { get; set; }
        public DateTime BulkCreatedAt { get; set; }

        public long TotalInvoices { get; set; }
        public long? ReadyToPublishCount { get; set; }

        public long AccountsWithExceptionsCount { get; set; }
        public long TotalExceptions { get; set; }
        public long RulesWithExceptionsCount { get; set; }
    }
}
