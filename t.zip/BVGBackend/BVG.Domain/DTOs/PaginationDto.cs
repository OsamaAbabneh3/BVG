﻿using BVG.Domain.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Text.Json;

namespace BVG.Domain.DTOs
{
    public sealed record DynamicFilter(string Field, string Operator, JsonElement Value);

    public class FilterGroupDto
    {
        public string InnerOperator { get; set; } = "AND";

        public string OuterOperator { get; set; } = "AND";

        public List<DynamicFilter> Filters { get; set; } = new();
    }

    public class FilterOptionsDto
    {
        public List<FilterGroupDto> Groups { get; set; } = new();
    }

    public class DynamicPaginationDto
    {
        [Range(1, 50000)]
        public int PageNumber { get; set; } = 1;

        [Range(1, 100)]
        public int PageSize { get; set; } = 10;

        [Required]
        [MaxLength(100)]
        public string OrderBy { get; set; } = string.Empty;

        [EnumDataType(typeof(OrderDirectionEnum))]
        public OrderDirectionEnum OrderDirection { get; set; } = OrderDirectionEnum.DESC;

        public FilterOptionsDto FilterOptions { get; set; } = new();
    }

    public class PaginationResponseDto
    {
        public object Data { get; set; } = new();
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public int TotalCount { get; set; }
    }

    public class PaginatorResponseDto<T>
    {
        public IQueryable<T> Query { get; set; } = null!;

        public int TotalCount { get; set; }
    }
}
