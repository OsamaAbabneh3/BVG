﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class RolesDto
    {
    }

    public class CreateRoleDto
    {
        [Required]
        [MaxLength(100)]
        public string NameEn { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string NameAr { get; set; } = string.Empty;

        [MaxLength(500)]
        public string? Description { get; set; }

        [Required]
        [MinLength(1)]
        public HashSet<Guid> PermissionIds { get; set; } = new HashSet<Guid>();
    }

    public class CreateRoleResponseDto
    {
        public Guid Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public string? Description { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }

    public class GetAllRolesResponseDto
    {
        public Guid Id { get; set; }

        public string NameEn { get; set; } = string.Empty;
        public string NameAr { get; set; } = string.Empty;

        public string? Description { get; set; }

        public List<PermissionDto> Permissions { get; set; } = new();
    }

    public class RoleFiltersDto
    {
        [Required]
        [MaxLength(100)]
        public string RoleName { get; set; } = string.Empty;
    }

    public class AssignPermissionsToRoleDto
    {
        [Required]
        public required Guid RoleId { get; set; }

        [Required]
        [MinLength(1)]
        public HashSet<Guid> PermissionIds { get; set; } = new HashSet<Guid>();
    }

    public class ModifyDescriptionDto
    {
        [Required]
        public required Guid Id { get; set; }

        [MaxLength(500)]
        public string? Description { get; set; }
    }
}
