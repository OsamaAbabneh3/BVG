﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class CreateRuleFamilyDto
    {
        [Required]
        public string FamilyName { get; set; } = null!;
        [Required]
        public string RuleFamilyCode { get; set; } = null!;
    }
    public class RuleFamilyFilterDto
    {
    }
    public class GetRuleFamilyDto
    {
        public long Id { get; set; }
        public string FamilyName { get; set; } = null!;
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public string RuleFamilyCode { get; set; } = null!;
    }
    public class UpdateRuleFamilyDto
    {
        [Required]
        public required long Id { get; set; }
        [Required]
        public string FamilyName { get; set; } = null!;
        [Required]
        public string RuleFamilyCode { get; set; } = null!;

    }
    public class DeleteRuleFamilyDto
    {
        [Required]
        public required long Id { get; set; }
    }
}
