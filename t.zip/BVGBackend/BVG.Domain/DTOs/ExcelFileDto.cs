﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class ExcelFileDto
    {
        public byte[] Content { get; set; } = System.Array.Empty<byte>();

        public string FileName { get; set; } = string.Empty;

        public string ContentType { get; set; } ="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    }
}
