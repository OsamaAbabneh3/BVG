﻿ using BVG.Domain.Entities;
using BVG.Domain.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class AddInvoiceExceptionDto
    {
        [Required]
        public required long SnapshotBulkId { get; set; }
        [Required]
        public required long RuleId { get; set; }
        [Required]
        public required string AccountNumber { get; set; }
        [Required]
        [EnumDataType(typeof(SeverityEnum))]
        public required SeverityEnum Severity { get; set; }

        public string? Description { get; set; }

        public string? Status { get; set; }
        [Required]
        public required byte MonitoreStatus { get; set; }

        public string? Count { get; set; }
    }
    public class UpdateInvoiceExceptionDto
    {
        [Required]
        public required long Id { get; set; }
        public string? Description { get; set; }
        [Required]
        public required byte MonitoreStatus { get; set; }
    }
    public class GetInvoiceExceptionDto
    {
        public long Id { get; set; }

        public long? SnapshotBulkId { get; set; }

        public long? RuleId { get; set; }

        public string? AccountNumber { get; set; }

        public string? Description { get; set; }

        public byte MonitoreStatus { get; set; } 

        public DateTime CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
    public class InvoiceExceptionFilterDto
    {
    }

    public record ExceptionResult 
    {
        public string AccountNumber { get; set; } = string.Empty;
    };
}
