﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class CycleSummaryReportRequestDto
    {
        [Range(1, long.MaxValue)]
        public long CycleId { get; set; }

        [Range(1, long.MaxValue)]
        public long? SnapshotBulkId { get; set; }
    }
}
