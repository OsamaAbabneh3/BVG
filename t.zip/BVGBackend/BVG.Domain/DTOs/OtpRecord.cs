﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.DTOs
{
    public record OtpRecord(string Hash, string Username);
}
