﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class VerifyLoginOtpDto
    {
        [Required]
        public string RequestToken { get; set; } = default!;
        [Required, StringLength(6, MinimumLength = 6)]
        public string Code { get; set; } = default!;
    }
}
