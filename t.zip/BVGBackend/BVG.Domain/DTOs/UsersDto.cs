﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class UsersDto
    {
    }

    public class UserFilterDto
    {

    }

    public class UpdateUserDto
    {
        [Required]
        [MaxLength(100)]
        public string FirstName { get; set; } = string.Empty;
        [Required]
        [MaxLength(100)]
        public string LastName { get; set; } = string.Empty;

        [Required]
        [Length(10, 10)]
        [RegularExpression(@"^07[789]\d{7}$", ErrorMessage = "رقم الهاتف يجب أن يبدأ بـ 077 أو 078 أو 079 ويتكون من 10 أرقام.")]
        public string PhoneNumber { get; set; } = string.Empty;

    
    }

    public class CreateUserDto
    {
        [Required]
        [MaxLength(100)]
        public string Username { get; set; } = null!;

        [Required]
        [MaxLength(255)]
        [EmailAddress]
        [RegularExpression(@"(?i)^[a-zA-Z0-9._%+-]+@ideco\.com\.jo$", ErrorMessage = "يجب أن يكون البريد الإلكتروني تابعاً لنطاق شركة كهرباء إربد (@ideco.com.jo).")]
        public string Email { get; set; } = null!;

        [Required]
        [MaxLength(100)]
        public string FirstName { get; set; } = null!;

        [Required]
        [MaxLength(100)]
        public string LastName { get; set; } = null!;

        [Required]
        [Length(10, 10)]
        [RegularExpression(@"^07[789]\d{7}$", ErrorMessage = "رقم الهاتف يجب أن يبدأ بـ 077 أو 078 أو 079 ويتكون من 10 أرقام.")]
        public string PhoneNumber { get; set; } = string.Empty;

        [Required]
        [MinLength(1)]
        public HashSet<Guid> RoleIds { get; set; } = new HashSet<Guid>();
    }


    public class UserDetailsDto
    {
        public Guid Id { get; set; }
        public string Username { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;

        public List<GetAllRolesResponseDto> Roles { get; set; } = new();
    }

    public class GetUserDetailsDto
    {
        public Guid Id { get; set; }
        public string Username { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public bool IsBlocked { get; set; }
        public bool IsLocked { get; set; }
        public DateTime? LockedUntil { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public bool MustChangePassword { get; set; }
        public List<GetAllRolesResponseDto> Roles { get; set; } = new();
    }

    public class GetByIdResponseDto
    {
        public Guid Id { get; set; }

        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public List<GetAllRolesResponseDto> Roles { get; set; } = new List<GetAllRolesResponseDto>();
        public DateTime? CreatedAt { get; set; }
    }

    public class AssignRolesToUserDto
    {
        [Required]
        public required Guid UserId { get; set; }

        [Required]
        [MinLength(1)]
        public HashSet<Guid> RoleIds { get; set; } = new HashSet<Guid>(); 
    }
}
