﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class LoginDto
    {
        [Required]
        public string Identifier { get; set; } = string.Empty;

        [Required]
        public string Password { get; set; } = string.Empty;
    }

    public class RequestLoginResponseDto
    {
        public string RequestToken { get; set; } = string.Empty;
        public int? ExpireInSecond { get; set; }
    }


    public class LoginResponseDto
    {
        public string AccessToken { get; set; } = string.Empty;

        public bool MustChangePassword { get; set; }
    }

    public class ResetPasswordDto
    {
        [Required]
        public string OldPassword { get; set; } = string.Empty;

        [Required]
        [RegularExpression(@"^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\-]).{12,}$")]
        public string NewPassword { get; set; } = string.Empty;

        [Required]
        [Compare(nameof(NewPassword))]
        public string ConfirmNewPassword { get; set; } = string.Empty;
    }

    public class SendOtpDto
    {
        [Required]
        public string Identifier { get; set; } = string.Empty;
    }

    public class ForgetPasswordDto
    {
        [Required]
        public string RequestToken { get; set; } = string.Empty;
        
        [Required]
        [Length(6, 6)]
        public string Code { get; set; } = string.Empty;

        [Required]
        [RegularExpression(@"^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\-]).{12,}$")]
        public string NewPassword { get; set; } = string.Empty;

        [Compare(nameof(NewPassword))]
        public string ConfirmNewPassword { get; set; } = string.Empty;
    }
}
