﻿using BVG.Domain.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class SnapshotBulkDto
    {
        public long Id { get; set; }
        public long CycleId { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public bool? ReferenceOk { get; set; }
        public string? ReferenceReason { get; set; }
        public int Sequence { get; set; }
        public VerdictEnum? Status { get; set; }
        public CheckStatusEnum CheckStatus { get; set; }
        public PullStatusEnum PullStatus { get; set; }
    }
    public class AddSnapshotBulkDto
    {
        [Required]
        public required long CycleId { get; set; }
        public bool? ReferenceOk { get; set; }

        public string? ReferenceReason { get; set; }

        public int? Status { get; set; }
        [Required]
        public required bool IsChecked { get; set; }
    }
    public class UpdateSnapshotBulkDto
    {
        [Required]
        public required long Id { get; set; }
        //[Required]
        //public required int CycleId { get; set; }
        //public bool? ReferenceOk { get; set; }

        //public string? ReferenceReason { get; set; }

        //public int? Status { get; set; }
        [Required]
        public required bool IsChecked { get; set; }
    }
}
