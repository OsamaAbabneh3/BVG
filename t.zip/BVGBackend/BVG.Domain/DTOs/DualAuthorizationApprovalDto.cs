﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class DualAuthorizationApprovalDto
    {
        public long Id { get; set; }

        public long DualAuthorizationRequestId { get; set; }

        public Guid ApproverUserId { get; set; }

        public DateTime? ApprovalTime { get; set; }

        public string? Justification { get; set; }

        public bool? Decision { get; set; } 

        public DateTime CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
    public class DecisionDualAuthorizationApprovalDto
    {
        [Required]
        public required long Id { get; set; }

        public string? Justification { get; set; }
        [Required]
        public required bool Decision { get; set; }
    }
}
