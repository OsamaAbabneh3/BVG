﻿using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class CyucleInfoRuningStatusDto
    {

    }
    public class CycleInfoRuningstatusBySnapShotBulkRequestDto : DynamicPaginationDto
    {
        [Required]
        public required long SnapShotBulkId { get; set; }
    }
    public class CycleInfoRuningstatusResponseDto
    {
        public long Id { get; set; }

        public DateTime? CreatedAt { get; set; }

        public string? ActionType { get; set; } = string.Empty;

        

    }
    public class SnapshotBulkRuningStatusResponseDto
    {
        public long SnapshotBulkId { get; set; }
        public List<CycleInfoRuningstatusResponseDto> RuningStatuses { get; set; } = new();
    }
    public class CycleInfoRuningStatusByCycleInfoRequestDto : DynamicPaginationDto
    {
        [Required]
        public long CycleInfoId { get; set; }
    }

    public class CycleInfoRuningStatusByCycleInfoResponseDto:DynamicPaginationDto
    {
        public long CycleInfoId { get; set; }
        public List<SnapshotBulkRuningStatusResponseDto> SnapshotBulks { get; set; } = new();
    }
}
