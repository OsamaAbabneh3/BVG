﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class HealthCheckResponse
    {
        public bool BvgConnection { get; set; }
        public bool SnapshotConnection { get; set; }
        public bool OracleConnection { get; set; }
    }
}
