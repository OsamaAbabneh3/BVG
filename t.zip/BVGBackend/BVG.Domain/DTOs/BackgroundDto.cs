﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class BackgroundDto
    {
    }

    public class EnqueueBackgroundJobsResponse
    {
        public Guid BatchRunId { get; set; }

        public int JobsCreated { get; set; }
    }
}
