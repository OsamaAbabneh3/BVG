﻿using BVG.Domain.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class AuditLogDto
    {
    }

    public class AuditLogsByRowIdRequestDto : DynamicPaginationDto
    {
        [Required]
        [EnumDataType(typeof(EntityTypeEnum))]
        public required EntityTypeEnum EntityType { get; set; }

        [Required]
        [MaxLength(100)]
        public string EntityRowId { get; set; } = string.Empty;
    }

    public class AuditLogsByUserRequestDto : DynamicPaginationDto
    {
        [Required]
        public required Guid UserId { get; set; }
    }

    public class AuditLogsByRowIdResponseDto
    {
        public UserDetailsDto? UserDetails { get; set; }

        public SystemActionEnum? ActionType { get; set; }

        public string? Details { get; set; } = string.Empty;

        public DateTime? OccurredAt { get; set; }
    }

    public class AuditLogsByUserResponseDto
    {
        public SystemActionEnum? ActionType { get; set; }

        public string? Details { get; set; } = string.Empty;

        public DateTime? OccurredAt { get; set; }
    }

    public class AuditLogDetailsFilterDto
    {
    }

    public class AuditLogActionsFilterDto
    {
    }
}
