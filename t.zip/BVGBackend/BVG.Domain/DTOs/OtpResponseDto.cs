﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class OtpResponseDto
    {
        public string RequestToken { get; set; } = default!;
        public  int ExpiresInSeconds { get; set; }
    }

    public class SmsIntegrationResponse
    {
        public string Status {  get; set; }= default!;
        public ResultData Result { get; set; } = default!;
    }

    public class ResultData
    {
        public string Integration_Token { get; set; } = default!;
    }
}
