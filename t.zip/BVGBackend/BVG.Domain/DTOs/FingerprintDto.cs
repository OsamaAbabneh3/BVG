﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class FingerprintDto
    {
        public long Id { get; set; }
        public long? SnapshotBulkId { get; set; }
        public bool? FingerprintOk { get; set; } 
        public int? RowCount { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }

    }
    public class AddFingerprintDto
    {
        [Required]
        public required int SnapshotBulkId { get; set; }
        public  bool? FingerprintOk { get; set; }
        public int? RowCount { get; set; }
    }
    public class UpdateFingerprintDto
    {
        [Required]
        public required int Id { get; set; }
        [Required]
        public required int SnapshotBulkId { get; set; }
        public  bool? FingerprintOk { get; set; }
        public int? RowCount { get; set; }
    }
}
