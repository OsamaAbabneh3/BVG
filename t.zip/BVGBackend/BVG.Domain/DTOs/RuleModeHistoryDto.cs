﻿using BVG.Domain.Entities;
using BVG.Domain.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class GetRuleModeHistoryDto
    {
        public long Id { get; set; }

        public long RuleId { get; set; }
        public long CycleId { get; set; }
        public ModeEnum Mode { get; set; }
        public int ExceededAlertCount { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
    }
  
    public class AddRuleModeHistoryDto
    {

        public long RuleId { get; set; }

        public long CycleId { get; set; }

        [Required]
        [EnumDataType(typeof(ModeEnum))]
        public required ModeEnum Mode { get; set; }
        [Required]

        public required int ExceededAlertCount { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }


    public class RuleModeHistoryFilterDto
    {
    }
}
