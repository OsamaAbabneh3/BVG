﻿using BVG.Domain.Entities;
using BVG.Domain.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class RuleCatalogFilterDto
    {
    }

    public class CreateRuleCatalogDto
    {
        [Required]
        [MaxLength(50)]
        [RegularExpression(@"^[0-9]+$")]
        public required string RuleCode { get; set; } = null!;
        

        [Required]
        [MaxLength(200)]
        public required string RuleName { get; set; } = null!;
        
        
        [Required]
        public required int FamilyId { get; set; }


        [Required]
        [EnumDataType(typeof(SeverityEnum))]
        public required SeverityEnum Severity { get; set; }


        [Required]
        [EnumDataType(typeof(AuditLayer))]
        public required AuditLayer Layer { get; set; }

        [Required]
        public required bool IsActive { get; set; }

        [Required]
        [Range(0.00000, 9.99999)]
        public required decimal AlertBudget { get; set; }
        public string? QuerySql { get; set; }
        public string? Description { get; set; }
    }

    public class UpdateRuleCatalogDto
    {
        [Required]
        public required int Id { get; set; }
        
        
        [Required]
        [MaxLength(50)]
        public required string RuleCode { get; set; } = null!;


        [Required]
        [MaxLength(200)]
        public required string RuleName { get; set; } = null!;


        [Required]
        [EnumDataType(typeof(SeverityEnum))]
        public required SeverityEnum Severity { get; set; }


        [Required]
        [EnumDataType(typeof(AuditLayer))]
        public required AuditLayer Layer { get; set; }


        [Required]
        public required bool IsActive { get; set; }

        [Required]
        [Range(0.00000, 9.99999)]
        public required decimal AlertBudget { get; set; }
        public string? QuerySql { get; set; }
        public string? Description { get; set; }
    }


    public class DeleteRuleCatalogDto
    {
        [Required]
        public required long Id { get; set; }
    }

    public class GetRuleCatalogDto
    {
        public long Id { get; set; }
        public string RuleCode { get; set; } = null!;
        public string RuleName { get; set; } = null!;
        public string? Description { get; set; }
        public SeverityEnum Severity { get; set; }
        public string? QuerySql { get; set; }
        public decimal AlertBudget { get; set; }
        public ModeEnum Mode { get; set; }
        public byte Layer { get; set; }
        public string? Version { get; set; }
        public bool IsActive { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }

        public long FamilyId { get; set; }
        public string? FamilyName { get; set; }

        public int InvoiceExceptionsCount { get; set; }

    }

    public class GetByIdRuleCatalogDto
    {
        public long Id { get; set; }
        public string RuleCode { get; set; } = null!;
        public string RuleName { get; set; } = null!;
        public string? Description { get; set; }
        public int FamilyId { get; set; }
        public string FamilyName { get; set; } = null!;
        public SeverityEnum Severity { get; set; }
        public string? QuerySql { get; set; }

        public decimal AlertBudget { get; set; }

        public ModeEnum Mode { get; set; }
        public byte Layer { get; set; }
        public string? Version { get; set; }
        public bool IsActive { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public int InvoiceExceptionsCount { get; set; }


    }

    public class RuleModeHistoryDto
    {
        public int Id { get; set; }
        public string Mode { get; set; } = null!;
    }

    public record FXD07Rule(string REF_TABLE, string BillKindId);
}
