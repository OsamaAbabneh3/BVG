﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.DTOs
{
    public class InvoiceIdRange
    {
        public long StartInvoiceId { get; set; }

        public long EndInvoiceId { get; set; }
    }
}
