﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class OtpCode
{
    public Guid Id { get; set; }

    public string RequestToken { get; set; } = null!;

    public string Username { get; set; } = null!;

    public int Purpose { get; set; }

    public string CodeHash { get; set; } = null!;

    public int Attempts { get; set; }

    public bool IsUsed { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime ExpiresAt { get; set; }

    public DateTime? UpdatedAt { get; set; }
}
