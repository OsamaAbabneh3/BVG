﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class BvgUser
{
    public Guid Id { get; set; }

    public string UserName { get; set; } = null!;

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string PasswordHash { get; set; } = null!;

    public string PhoneNumber { get; set; } = null!;

    public bool IsBlocked { get; set; }

    public bool MustChangePassword { get; set; }

    public DateTime? LockedUntil { get; set; }

    public DateTime? LastTryAttempt { get; set; }

    public int LoginTryAttempt { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<AuditLog> AuditLogs { get; set; } = new List<AuditLog>();

    public virtual ICollection<DualAuthorizationApproval> DualAuthorizationApprovals { get; set; } = new List<DualAuthorizationApproval>();

    public virtual ICollection<UserRole> UserRoles { get; set; } = new List<UserRole>();
}
