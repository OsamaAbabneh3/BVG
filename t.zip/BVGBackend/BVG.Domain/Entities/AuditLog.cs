﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class AuditLog
{
    public long Id { get; set; }

    public Guid? UserId { get; set; }

    public int? ActionType { get; set; }

    public string? Details { get; set; }

    public DateTime CreatedAt { get; set; }

    public int EntityType { get; set; }

    public string EntityRowId { get; set; } = null!;

    public DateTime? UpdatedAt { get; set; }

    public virtual BvgUser? User { get; set; }
}
