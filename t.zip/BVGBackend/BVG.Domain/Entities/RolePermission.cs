﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class RolePermission
{
    public long Id { get; set; }

    public Guid? RoleId { get; set; }

    public Guid? PermissionId { get; set; }

    public DateTime? AssignedAt { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual Permission? Permission { get; set; }

    public virtual Role? Role { get; set; }
}
