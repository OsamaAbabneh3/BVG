﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class SnapshotBulk
{
    public long Id { get; set; }

    public long CycleId { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public int Sequence { get; set; }

    public byte CheckStatus { get; set; }

    public bool? ReferenceOk { get; set; }

    public string? ReferenceReason { get; set; }

    public int? Status { get; set; }

    public byte PullStatus { get; set; }

    public int AttemptCount { get; set; }

    public DateTime? StartedAt { get; set; }

    public DateTime? CompletedAt { get; set; }

    public string? ErrorMessage { get; set; }

    public virtual ICollection<BackgroundJob> BackgroundJobs { get; set; } = new List<BackgroundJob>();

    public virtual CycleInfo Cycle { get; set; } = null!;

    public virtual ICollection<CycleInfoRuningStatus> CycleInfoRuningStatuses { get; set; } = new List<CycleInfoRuningStatus>();

    public virtual ICollection<DualAuthorizationRequest> DualAuthorizationRequests { get; set; } = new List<DualAuthorizationRequest>();

    public virtual ICollection<Fingerprint> Fingerprints { get; set; } = new List<Fingerprint>();

    public virtual ICollection<InvoiceException> InvoiceExceptions { get; set; } = new List<InvoiceException>();
}
