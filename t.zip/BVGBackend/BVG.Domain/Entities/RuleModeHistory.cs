﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class RuleModeHistory
{
    public long Id { get; set; }

    public long RuleId { get; set; }

    public long CycleId { get; set; }

    public byte Mode { get; set; }

    public int ExceededAlertCount { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual CycleInfo Cycle { get; set; } = null!;

    public virtual RuleCatalog Rule { get; set; } = null!;
}
