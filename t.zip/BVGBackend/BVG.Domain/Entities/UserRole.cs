﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class UserRole
{
    public long Id { get; set; }

    public Guid? UserId { get; set; }

    public Guid? RoleId { get; set; }

    public DateTime? AssignedAt { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual Role? Role { get; set; }

    public virtual BvgUser? User { get; set; }
}
