﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class CycleInfoRuningStatus
{
    public long Id { get; set; }

    public DateTime CreatedAt { get; set; }

    public string ActionType { get; set; } = null!;

    public long SnapshotBulkId { get; set; }

    public virtual SnapshotBulk SnapshotBulk { get; set; } = null!;
}
