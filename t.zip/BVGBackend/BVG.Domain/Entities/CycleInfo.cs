﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class CycleInfo
{
    public long Id { get; set; }

    public DateOnly CycleDate { get; set; }

    public DateTime? StartDate { get; set; }

    public DateTime? EndDate { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<RuleModeHistory> RuleModeHistories { get; set; } = new List<RuleModeHistory>();

    public virtual ICollection<SnapshotBulk> SnapshotBulks { get; set; } = new List<SnapshotBulk>();
}
