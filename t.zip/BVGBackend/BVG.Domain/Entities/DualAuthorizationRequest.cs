﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class DualAuthorizationRequest
{
    public long Id { get; set; }

    public string? Description { get; set; }

    public bool? Status { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public long? SnapshotBulkId { get; set; }

    public virtual ICollection<DualAuthorizationApproval> DualAuthorizationApprovals { get; set; } = new List<DualAuthorizationApproval>();

    public virtual SnapshotBulk? SnapshotBulk { get; set; }
}
