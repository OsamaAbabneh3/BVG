﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class RuleFamily
{
    public long Id { get; set; }

    public string FamilyName { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public string RuleFamilyCode { get; set; } = null!;

    public virtual ICollection<RuleCatalog> RuleCatalogs { get; set; } = new List<RuleCatalog>();
}
