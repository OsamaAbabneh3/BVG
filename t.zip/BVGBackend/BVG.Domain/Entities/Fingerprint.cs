﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class Fingerprint
{
    public long Id { get; set; }

    public long? SnapshotBulkId { get; set; }

    public int? RowCount { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public bool? FingerprintOk { get; set; }

    public virtual SnapshotBulk? SnapshotBulk { get; set; }
}
