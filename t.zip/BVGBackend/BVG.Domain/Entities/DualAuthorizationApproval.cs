﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class DualAuthorizationApproval
{
    public long Id { get; set; }

    public long DualAuthorizationRequestId { get; set; }

    public Guid ApproverUserId { get; set; }

    public DateTime? ApprovalTime { get; set; }

    public string? Justification { get; set; }

    public bool? Decision { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual BvgUser ApproverUser { get; set; } = null!;

    public virtual DualAuthorizationRequest DualAuthorizationRequest { get; set; } = null!;
}
