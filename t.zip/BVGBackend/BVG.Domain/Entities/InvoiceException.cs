﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class InvoiceException
{
    public long Id { get; set; }

    public long? SnapshotBulkId { get; set; }

    public long? RuleId { get; set; }

    public string AccountNumber { get; set; } = null!;

    public string? Description { get; set; }

    public byte MonitoreStatus { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual RuleCatalog? Rule { get; set; }

    public virtual SnapshotBulk? SnapshotBulk { get; set; }
}
