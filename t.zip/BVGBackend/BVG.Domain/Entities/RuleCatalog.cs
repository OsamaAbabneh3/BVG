﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class RuleCatalog
{
    public long Id { get; set; }

    public string RuleCode { get; set; } = null!;

    public string RuleName { get; set; } = null!;

    public string? Description { get; set; }

    public long FamilyId { get; set; }

    public byte Severity { get; set; }

    public string? QuerySql { get; set; }

    public decimal AlertBudget { get; set; }

    public byte Mode { get; set; }

    public byte Layer { get; set; }

    public string Version { get; set; } = null!;

    public bool IsActive { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual RuleFamily Family { get; set; } = null!;

    public virtual ICollection<InvoiceException> InvoiceExceptions { get; set; } = new List<InvoiceException>();

    public virtual ICollection<RuleModeHistory> RuleModeHistories { get; set; } = new List<RuleModeHistory>();
}
