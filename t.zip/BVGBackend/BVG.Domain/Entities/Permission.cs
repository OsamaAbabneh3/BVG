﻿using System;
using System.Collections.Generic;

namespace BVG.Domain.Entities;

public partial class Permission
{
    public Guid Id { get; set; }

    public string PermissionName { get; set; } = null!;

    public string NameAr { get; set; } = null!;

    public string? Description { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<RolePermission> RolePermissions { get; set; } = new List<RolePermission>();
}
