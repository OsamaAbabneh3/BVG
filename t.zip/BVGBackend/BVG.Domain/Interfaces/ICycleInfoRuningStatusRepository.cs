﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface ICycleInfoRuningStatusRepository
    {
        Task<CycleInfoRuningStatus> AddAsync(CycleInfoRuningStatus cycleInfoRuningStatus);

        Task<List<CycleInfoRuningStatus>> WhereAsync(Expression<Func<CycleInfoRuningStatus, bool>> predicate);

        IQueryable<CycleInfoRuningStatus> Query(FilterOptionsDto filterOptions);
    }
}
