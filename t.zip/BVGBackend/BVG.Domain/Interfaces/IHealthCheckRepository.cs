﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IHealthCheckRepository
    {
        Task<bool> CanConnectWithBVGDBAsync();

        Task<bool> CanConnectWithSnapshotDBAsync();

        Task<bool> CanConnectWithOracleDBAsync();
    }
}
