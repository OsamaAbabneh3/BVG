﻿using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface ISnapshotRepository
    {
        Task<CycleRecord?> TakeActiveCycle();
        Task<MigrateFullSnapshot?> TakeSnapshotAsync(string cycleYM, long bulkId);
        Task TakeReferencesSnapshotAsync(DateOnly cycleDate);
        Task TakePricesSnapshotAsync(DateOnly cycleDate);
    }
}
