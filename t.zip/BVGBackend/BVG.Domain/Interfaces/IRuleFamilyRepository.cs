﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IRuleFamilyRepository
    {
        Task<IEnumerable<RuleFamily>> GetAllRuleFamily(CancellationToken cancellationToken);
        Task<RuleFamily?> getByIdRuleFamily(long id, CancellationToken cancellationToken);
        Task<RuleFamily> CreateRuleFamily(RuleFamily ruleFamily, CancellationToken cancellationToken);
        Task UpdateRuleFamily(RuleFamily ruleFamily, CancellationToken cancellationToken);
        Task DeleteRuleFamily(long id, CancellationToken cancellationToken);
        IQueryable<RuleFamily> Query(FilterOptionsDto filterOptions);
        Task<bool> IsRuleFamilyLinkedToRuleCatalog(long ruleFamilyId, CancellationToken cancellationToken);
        Task<bool> IsValidRuleNameAsync(string ruleName, CancellationToken cancellationToken);
        Task<bool> IsValidRuleCodeAsync(string ruleCode, CancellationToken cancellationToken);
        Task<string> GetCodyByruleFamilyId(long ruleFamilyId, CancellationToken cancellationToken); 
        

    }
}
