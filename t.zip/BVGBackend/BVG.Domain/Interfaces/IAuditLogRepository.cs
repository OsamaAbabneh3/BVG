﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IAuditLogRepository
    {
        Task<AuditLog> AddAsync(AuditLog auditLog, CancellationToken cancellationToken);

        Task<List<AuditLog>> WhereAsync(Expression<Func<AuditLog, bool>> predicate, CancellationToken cancellationToken);

        IQueryable<AuditLog> Query(FilterOptionsDto filterOptions);
    }
}
