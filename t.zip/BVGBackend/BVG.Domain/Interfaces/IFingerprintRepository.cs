﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IFingerprintRepository
    {
        Task<Fingerprint> AddFingerprint(Fingerprint fingerprint, CancellationToken cancellationToken);
        Task<Fingerprint?> GetByIdFingerprint(long id, CancellationToken cancellationToken);
        Task UpdateFingerprint(Fingerprint fingerprint, CancellationToken cancellationToken);
        Task<IEnumerable<Fingerprint>> GetAllFingerprints(CancellationToken cancellationToken);
        IQueryable<Fingerprint> Query(FilterOptionsDto filterOptions);
        Task<Fingerprint?> GetBySnapshotBulkIdAsync(long snapshotBulkId, CancellationToken cancellationToken);
        Task<long> CountAsync(Expression<Func<Fingerprint, bool>> expression);
        Task<List<Fingerprint>> WhereAsync(Expression<Func<Fingerprint, bool>> expression);
    }
}
