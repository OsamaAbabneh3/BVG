﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface ICycleInfoRepository
    {
        Task<IEnumerable<CycleInfo>> GetAllCycleInfo();
        Task<CycleInfo?> GetByIdCycleInfo(long id, CancellationToken cancellationToken);
        Task<CycleInfo> AddCycleInfo(CycleInfo cycleInfo , CancellationToken cancellationToken);
        Task UpdateCycleInfo(CycleInfo cycleInfo, CancellationToken cancellationToken);
        IQueryable<CycleInfo> Query(FilterOptionsDto filterOptions);
        Task<CycleInfo?> GetFirstOrDefaultAsync(Expression<Func<CycleInfo, bool>> expression);
    }
}
