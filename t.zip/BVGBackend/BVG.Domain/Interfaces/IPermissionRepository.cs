﻿using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IPermissionRepository
    {
        Task<Permission> AddAsync(Permission permission, CancellationToken cancellationToken);

        Task<Permission?> GetById(Guid id, CancellationToken cancellationToken);

        Task<int> CountAsync(HashSet<Guid> permissionIds, CancellationToken cancellationToken);

        Task<List<Permission>> GetAllPermissions(CancellationToken cancellationToken);
    }
}
