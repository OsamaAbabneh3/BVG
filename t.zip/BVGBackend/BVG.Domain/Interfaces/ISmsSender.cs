﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface ISmsSender
    {
        Task SendAsync(string phone, string message);
    }
}
