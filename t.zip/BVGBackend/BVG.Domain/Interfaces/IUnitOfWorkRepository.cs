﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IUnitOfWorkRepository
    {
        Task BeginTransactionAsync(IsolationLevel isolationLevel = IsolationLevel.ReadCommitted);
        Task CommitAsync();
        Task RollbackAsync();
    }
}
