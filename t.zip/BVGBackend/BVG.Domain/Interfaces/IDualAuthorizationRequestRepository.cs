﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IDualAuthorizationRequestRepository
    {
        Task<DualAuthorizationRequest> AddDualAuthorizationRequest(DualAuthorizationRequest dualAuthorizationRequest, CancellationToken cancellationToken);
        Task<DualAuthorizationRequest?> GetByIdDualAuthorizationRequest(long id, CancellationToken cancellationToken);
        Task UpdateDualAuthorizationRequest(DualAuthorizationRequest dualAuthorizationRequest, CancellationToken cancellationToken);
        Task<List<DualAuthorizationRequest>> GetAllDualAuthorizationRequests(CancellationToken cancellationToken);
        IQueryable<DualAuthorizationRequest> Query(FilterOptionsDto filterOptions);
    }
}
