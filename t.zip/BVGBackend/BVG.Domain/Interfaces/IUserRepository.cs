﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IUserRepository
    {
        Task<BvgUser> AddAsync(BvgUser user, CancellationToken cancellationToken);

        Task<BvgUser?> GetById(Guid id, CancellationToken cancellationToken);

        Task<BvgUser> UpdateAsync(BvgUser user, CancellationToken cancellationToken);

        Task<bool> IsUserExists(string username, CancellationToken cancellationToken);

        Task<bool> IsEmailUsed(string email, CancellationToken cancellationToken);

        IQueryable<BvgUser> Query(FilterOptionsDto filterOptions);

        Task<BvgUser?> GetByIdWithRoles(Guid id, CancellationToken cancellationToken);

        Task<BvgUser?> GetByUsername(string username, CancellationToken cancellationToken);

        Task<BvgUser?> GetByIdWithUserRoles(Guid id, CancellationToken cancellationToken);

        Task RemoveRangeOfUserRoles(List<UserRole> userRoles, CancellationToken cancellationToken);
        Task<bool> IsPhoneUsed(string phone, CancellationToken cancellationToken);
        Task<bool> IsPhoneUsedExceptCurrent(Guid id, string phone, CancellationToken cancellationToken);
        Task<BvgUser?> GetByIdentifier(string identifier, CancellationToken cancellationToken);
    }
}
