﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IRuleCatalogRepository
    {
        Task<IEnumerable<RuleCatalog>> GetAllRuleCatalog(CancellationToken cancellationToken);
        Task<RuleCatalog?> GetByIdRuleCatalog(long id, CancellationToken cancellationToken);
        Task<RuleCatalog> CreateRuleCatalog(RuleCatalog ruleCatalog, CancellationToken cancellationToken);
        Task UpdateRuleCatalog(RuleCatalog ruleCatalog, CancellationToken cancellationToken);
        Task DeleteRuleCatalog(long id, CancellationToken cancellationToken);
        Task<bool> IsDuplicate(string ruleCode, CancellationToken cancellationToken);
        IQueryable<RuleCatalog> Query(FilterOptionsDto filterOptions);
        Task<IEnumerable<RuleCatalog>> GetRuleByLayer(byte layer, CancellationToken cancellationToken);
        Task<bool> ExistsRuleCatalog(string version, long FamilyId, string ruleCode, CancellationToken cancellationToken);
        Task<bool> ExistsRuleCatalogWhenUpdate(string version, string ruleName, string ruleCode , CancellationToken cancellationToken, long? excludeId=null);
        Task<RuleCatalog?> GetByRuleCodeAsync(string ruleCode, byte layer, CancellationToken cancellationToken);
        Task<List<string>> GetRuleVersionsAsync(RuleCatalog rule, CancellationToken cancellationToken);
        Task DeactivateOtherVersionsAsync(RuleCatalog rule, CancellationToken cancellationToken);
        Task<RuleCatalog?> GetByIdAsync(long id);
        Task<List<RuleCatalog>> WhereAsync(Expression<Func<RuleCatalog, bool>> expression);
        Task<List<FXD07Rule>> ExecuteFXDAsync(string sqlText);
    }
}
