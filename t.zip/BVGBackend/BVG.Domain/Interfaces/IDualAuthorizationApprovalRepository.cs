﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IDualAuthorizationApprovalRepository
    {
        Task<DualAuthorizationApproval> AddDualAuthorizationApproval(DualAuthorizationApproval dualAuthorizationApproval, CancellationToken cancellationToken);
        Task<DualAuthorizationApproval?> GetByIdDualAuthorizationApproval(long id, CancellationToken cancellationToken);
        Task UpdateDualAuthorizationApproval(DualAuthorizationApproval dualAuthorizationApproval, CancellationToken cancellationToken);
        Task<List<DualAuthorizationApproval>> GetAllDualAuthorizationApproval(CancellationToken cancellationToken);
        IQueryable<DualAuthorizationApproval> Query(FilterOptionsDto filterOptions);
        Task<bool> IsDuplicate(long DualAuthorizationRequestId, Guid ApproverUserId , CancellationToken cancellationToken);
        Task<DualAuthorizationApproval?> GetByRequestAndApproverAsync(long dualAuthorizationRequestId, Guid approverUserId, CancellationToken cancellationToken);
        Task<List<Guid>> GetAuthorizedApproverUserIdsAsync(CancellationToken cancellationToken);

    }
}
