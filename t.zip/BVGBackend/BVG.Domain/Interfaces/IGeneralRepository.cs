﻿using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IGeneralRepository
    {
        Task<List<ExceptionResult>> ExceuteAsync(long startId, long endId, string sqlText, CancellationToken cancellationToken);
        Task<long> GetRowCountAsync(long snapshotBulkId, string sqlText, CancellationToken cancellationToken);
        Task<List<string>> GetInvalidBillKindsAsync(long snapshotBulkId,string sqlText,CancellationToken cancellationToken);
        Task ClearAllTablesAsync(CancellationToken cancellationToken);
        Task ClearByBulkAsync(long bulkId, CancellationToken cancellationToken);
    }
}
