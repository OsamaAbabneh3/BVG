﻿using BVG.Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IReportsRepository
    {
        Task<List<CycleSummaryReportRowDto>> GetCycleSummaryAsync(long cycleId, long? snapshotBulkId, CancellationToken cancellationToken);
    }
}
