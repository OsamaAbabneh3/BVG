﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IRuleModeHistoryRepository
    {
        Task<IEnumerable<RuleModeHistory>> GetAllRuleModeHistory(CancellationToken cancellationToken);
        Task<RuleModeHistory?> GetByIdRuleModeHistory(long id, CancellationToken cancellationToken); 
        Task<RuleModeHistory> AddRuleModeHistory(RuleModeHistory ruleModeHistory, CancellationToken cancellationToken);
        IQueryable<RuleModeHistory> Query(FilterOptionsDto filterOptions);
        Task<RuleModeHistory?> LastRuleModeHistory(long ruleId);
    }
}
