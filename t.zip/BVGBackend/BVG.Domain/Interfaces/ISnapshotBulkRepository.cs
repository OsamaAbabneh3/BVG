﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface ISnapshotBulkRepository
    {
        Task<List<SnapshotBulk>> GetAllSnapshotBulk(CancellationToken cancellationToken);
        Task<SnapshotBulk?> GetByIdSnapshotBulk(long id, CancellationToken cancellationToken);
        Task<SnapshotBulk> AddSnapshotBulk(SnapshotBulk snapshotBulk, CancellationToken cancellationToken);
        Task UpdateAsync(SnapshotBulk snapshotBulk, CancellationToken cancellationToken);
        IQueryable<SnapshotBulk> Query(FilterOptionsDto filterOptions);
        IQueryable<SnapshotBulk> QueryByCycleInfoIdWithRuningStatuses(long cycleInfoId);
        Task<bool> AnyAsync(Expression<Func<SnapshotBulk, bool>> expression);
        Task<int> GetMaxSequence(long cycleId);

    }
}
