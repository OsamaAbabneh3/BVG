﻿using BVG.Domain.Entities;
using BVG.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IOtpRepository
    {
        Task AddAsync(OtpCode otp);
        Task<OtpCode?> GetByTokenAsync(string requestToken);
        Task<DateTime?> GetLastCreatedAtAsync(string username, OtpPurpose purpose); 
        Task<int> CountSentSinceAsync(string username, OtpPurpose purpose, DateTime since);
        Task<bool> TryIncrementAttemptAsync(Guid id, int maxAttempts, DateTime now);
        Task<bool> TryMarkUsedAsync(Guid id, DateTime now); 
        Task InvalidateOthersAsync(string username, OtpPurpose purpose, Guid exceptId);
        Task RemoveAsync(Guid id);
        Task DeleteOlderThanAsync(DateTime before);
    }
}
