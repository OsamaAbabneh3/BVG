﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IRoleRepository
    {
        Task<Role> AddAsync(Role role, CancellationToken cancellationToken);

        Task<Role?> GetById(Guid id, CancellationToken cancellationToken);

        Task<List<Role>> Where(Expression<Func<Role, bool>> predicate, CancellationToken cancellationToken);

        IQueryable<Role> Query(FilterOptionsDto filterOptions);

        Task<int> CountAsync(HashSet<Guid> roleIds, CancellationToken cancellationToken);

        Task<Role?> GetByIdWithRolePermissions(Guid id, CancellationToken cancellationToken);

        Task<Role> UpdateAsync(Role role, CancellationToken cancellationToken);

        Task RemoveRangeOfRolePermissions(List<RolePermission> rolePermissions, CancellationToken cancellationToken);

        Task<Role?> GetByIdWithRelationsAsync(Guid id, CancellationToken cancellationToken);

        Task DeleteRoleAsync(Role role, CancellationToken cancellationToken);
    }
}
