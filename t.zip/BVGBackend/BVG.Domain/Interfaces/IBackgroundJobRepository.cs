﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System.Linq.Expressions;

namespace BVG.Domain.Interfaces
{
    public interface IBackgroundJobRepository
    {
        Task AddRangeAsync(IEnumerable<BackgroundJob> jobs, CancellationToken cancellationToken = default);

        Task SaveChangesAsync(CancellationToken cancellationToken = default);

        Task<List<InvoiceIdRange>> GetInvoiceRangesAsync(int bulkSize, long bulkId, CancellationToken cancellationToken = default);

        Task<long?> GetUncheckedBulkId();

        Task<bool> AnyAsync(Expression<Func<BackgroundJob, bool>> expression);
        Task<float> ProgressAsync(long bulkId, CancellationToken cancellationToken);
        Task<bool> IsCheckBulkCompletedAsync(long bulkId);
        Task<long> CountAsync(Expression<Func<BackgroundJob, bool>> expression);
        Task<long> CountComletedAsync(long bulkId);
        Task DeleteByBulkId(long bulkId);
        Task<BackgroundJob?> FirstOrDefaultAsync(Expression<Func<BackgroundJob, bool>> expression);
    }
}
