﻿using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IEmailLogRepository
    {
        public Task Add(EmailLog emailLog);
    }
}
