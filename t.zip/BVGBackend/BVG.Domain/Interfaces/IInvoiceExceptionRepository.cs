﻿using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace BVG.Domain.Interfaces
{
    public interface IInvoiceExceptionRepository
    {
        Task<List<InvoiceException>> GetAllInvoiceException(CancellationToken cancellationToken);
        Task<InvoiceException?> GetByIdInvoiceException(long id, CancellationToken cancellationToken);
        Task<InvoiceException> AddInvoiceException(InvoiceException invoiceException, CancellationToken cancellationToken);
        Task UpdateInvoiceException(InvoiceException invoiceException, CancellationToken cancellationToken);
        IQueryable<InvoiceException> Query(FilterOptionsDto filterOptions);
        Task<bool> IsDuplicate(long snapshotBulkId, long ruleId, string accountNumber, CancellationToken cancellationToken);
        Task AddRangeInvoidExceptions(List<InvoiceException> invoiceExceptions, CancellationToken cancellationToken);
        Task<long> CountAsync(Expression<Func<InvoiceException, bool>> expression);
        Task<List<InvoiceException>> WhereAsync(Expression<Func<InvoiceException, bool>> expression);
        Task DeleteByBulkIdAsync(long bulkId);
    }
}
