﻿namespace BVG.Domain.Enums
{
    public enum VerdictEnum
    {
        Hold,
        Release,
        Fault
    }
}
