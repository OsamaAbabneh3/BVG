﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Enums
{
    public enum OtpPurpose
    {
        Login = 1, ForgetPassword = 2
    }
}
