﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Enums
{
    public enum BVGMessage
    {
        ReturnSuccessfully,
        UserUpdated,
        RoleCreated,
        ExecuteSuccessfully,
        DeletedSuccessfully,
        UpdatedSuccessfully,
        ProcessInProgress
    }
}
