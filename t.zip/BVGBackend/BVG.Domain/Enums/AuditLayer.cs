﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Enums
{
    public enum AuditLayer
    {
        Layer1=1,
        Layer2=2,
        Layer3=3

    }
}
