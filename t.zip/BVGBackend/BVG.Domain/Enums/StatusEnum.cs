﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Enums
{
    public enum JobStatusEnum
    {
        Pending,
        Processing,
        Completed,
        Failed
    }

    public enum PullStatusEnum
    {
        Pending,
        Processing,
        Completed,
        Failed
    }

    public enum CheckStatusEnum
    {
        Pending,
        Processing,
        Completed,
        Failed
    }
}
