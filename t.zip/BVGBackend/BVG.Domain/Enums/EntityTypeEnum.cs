﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Enums
{
    public enum EntityTypeEnum
    {
        BvgUser,
        Role,
        RuleCatalog,
        CycleInfo,
        RuleModeHistory,
        DualAuthorizationRequest,
        DualAuthorizationApproval,
        Fingerprint,
        SnapshotBulk,
        InvoiceException,
        RuleFamily

    }
}
