﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Enums
{
    public enum SeverityEnum
    {
        Low,
        Medium,
        High,
        Critical
    }
}
