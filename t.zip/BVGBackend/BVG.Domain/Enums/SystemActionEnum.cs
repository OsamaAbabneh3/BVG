﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Enums
{
    public enum SystemActionEnum
    {
        LoginSuccessfully,
        CreateRole,
        ResetPassword,
        GetAllCycleInfo,
        ForgetPassword,
        AddInvoiceException,
        DecisionOfApproval,
        UpdateInvoiceException,
        AddDualAuthorizationRequest,
        UpdateDualAuthorizationRequest,
        UpdateFingerprint,
        AddFingerprint,
        DeleteRole,
        AddCycleInfo,
        UpdateDescription,
        CreateRuleFamily,
        CheckedSnapshotBulk,
        AddSnapshotBulk,
        CycleIsChecked,
        UpdateCycleInfo,
        CreateRuleCatalog,
        AddRuleModeHistory,
        UpdateRuleCatalog,
        UpdateRuleFamily,
        UserUnlocked,
        DeleteRuleFamily,
        CreateUser,
        UpdateUser,
        DeleteRuleCatalog,
        AssignPermissionsToRole,
        BlockUser,
        UnblockUser,
        AssignRolesToUser,
        OtpSmsMessage,
        StartBVG
    }
}
