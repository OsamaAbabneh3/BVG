﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BVG.Domain.Enums
{
    public enum PermissionsEnum
    {
        CreateUser,
        UpdateUser,
        UpdateSnapshotBulk,
        GetByIdFingerprint,
        UpdateFingerprint,
        AddFingerprint,
        GetAllSnapshotBulk,
        ExportCycleSummaryReport,
        GetAllRuleModeHistory,
        GetAllFingerprint,
        AddRuleModeHistory,
        AddCycleInfo,
        GetByIdRuleModeHistory,
        AddDualAuthorizationRequestAndApproval,
        GetAllDualAuthorizationRequest,
        UpdateDualAuthorizationRequest,
        GetByIdSnapshotBulk,
        UpdateCycleInfo,
        GetByIdDualAuthorizationRequest,
        GetAllCycleInfo,
        GetAllDualAuthorizationApprovalByUserId,
        GetByIdDualAuthorizationApproval,

        GetAllDualAuthorizationApproval,
        UpdateInvoiceException,
        DecisionDualAuthorizationApproval,
        GetByIdInvoiceException,
        GetAllInvoiceException,
        AddInvoiceException,
        GetAllUsers,
        GetUser,
        GetByIdCycleInfo,
        CreateRole,
        GetAllRoles,
        GetAllRuleCataloges,
        GetAllRuleFamily,
        GetRuleCatalog,
        GetRuleFamily,
        CreateRuleCatalog,
        CreateRuleFamily,
        UpdateRuleCatalog,
        UpdateRuleFamily,
        DeleteRuleCatalog,
        DeleteRuleFamily,
        ToggleBlock,
        Unlocked,
        GetAllPermissions,
        AssignPermissionsToRole,
        AssignRolesToUser,
        GetAuditLog,
        DeleteRole,
        UpdateRole
    }
}
