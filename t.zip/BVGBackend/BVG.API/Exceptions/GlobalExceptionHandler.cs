﻿using BVG.API;
using BVG.Application;
using BVG.Application.Common;
using BVG.Application.Exceptions;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.Extensions.Localization;
using System.Text.Json;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BVG.API.Exceptions
{
    public class GlobalExceptionHandler : IExceptionHandler
    {
        private readonly IStringLocalizer<Messages> _localizer;
        private readonly ILogger<GlobalExceptionHandler> _logger;

        public GlobalExceptionHandler(
            IStringLocalizer<Messages> localizer, 
            ILogger<GlobalExceptionHandler> logger)
        {
            _localizer = localizer;
            _logger = logger;
        }

        public async ValueTask<bool> TryHandleAsync(HttpContext httpContext, Exception exception, CancellationToken cancellationToken)
        {
            if (exception is BusinessException businessException)
            {
               httpContext.Response.StatusCode = businessException.StatusCode;

                await httpContext.Response.WriteAsJsonAsync(
                    new
                    {
                        errorCode = businessException.ErrorCode,
                        message = _localizer[businessException.ErrorCode].Value,
                    }
                , cancellationToken);

                return true;
            }
            if (exception is ArgumentException argumentException)
            {
                httpContext.Response.StatusCode = StatusCode.BadRequest;

                await httpContext.Response.WriteAsJsonAsync(
                    new
                    {
                        statusCode = StatusCode.BadRequest,
                        data = (object?)null,
                        message = argumentException.Message,
                        errorCode = (object?)null,
                    }
                , cancellationToken);

                return true;
            }

            _logger.LogError(exception, exception.Message);
            httpContext.Response.StatusCode = StatusCode.InternalServerError;

            await httpContext.Response.WriteAsJsonAsync(
                new
                {
                    errorCode = ErrorCode.InternalServerError,
                    message = _localizer[ErrorCode.InternalServerError].Value,
                }
            , cancellationToken);

            return true;
        }
    }
}
