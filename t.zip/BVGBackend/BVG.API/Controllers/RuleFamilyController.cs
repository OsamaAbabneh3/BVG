﻿using BVG.API.Authorization;
using BVG.Application.Services;
using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("/api/rule-family")]
    public class RuleFamilyController : BaseApiController
    {
        private readonly IRuleFamilyService _ruleFamilyService;
        public RuleFamilyController(IRuleFamilyService ruleFamilyService)
        {
            _ruleFamilyService = ruleFamilyService;

        }


        [HttpGet("id:long")]
        [Permission(PermissionsEnum.GetRuleFamily)]
        public async Task<IActionResult> GetByIdRuleFamily(long id, CancellationToken cancellationToken)
        {
            var rule = await _ruleFamilyService.GetByIdRuleFamily(id, cancellationToken);
            //exeption
            return Send(rule);
        }


        [HttpPost("pagination")]
        [Permission(PermissionsEnum.GetAllRuleFamily)]
        public async Task<IActionResult> GetAllRuleFamily([FromBody] DynamicPaginationDto dto, CancellationToken cancellationToken)
        {
            var result = await _ruleFamilyService.GetAllRuleFamily(dto, cancellationToken);
            return Send(result);
        }

        [HttpPost]
        [Permission(PermissionsEnum.CreateRuleFamily)]
        public async Task<IActionResult> CreateRuleFamily([FromBody] CreateRuleFamilyDto createRuleFamilyDto, CancellationToken cancellationToken)
        {
            var result = await _ruleFamilyService.CreateRuleFamily(createRuleFamilyDto, cancellationToken);
            return Send(result);
        }

        [HttpPut]
        [Permission(PermissionsEnum.UpdateRuleFamily)]
        public async Task<IActionResult> UpdateRuleFamily([FromBody] UpdateRuleFamilyDto updateRuleFamilyDto, CancellationToken cancellationToken)
        {
            var result = await _ruleFamilyService.UpdateRuleFamily(updateRuleFamilyDto, cancellationToken);
            return Send(result);
        }

        [HttpDelete]
        [Permission(PermissionsEnum.DeleteRuleFamily)]
        public async Task<IActionResult> DeleteRuleFamily(DeleteRuleFamilyDto deleteRuleFamilyDto, CancellationToken cancellationToken)
        {
            var result = await _ruleFamilyService.DeleteRuleFamily(deleteRuleFamilyDto, cancellationToken);
            return Send(result);
        }
        [HttpGet("GetLastRuleCodeFamily/{id:long}")]
        [Permission(PermissionsEnum.CreateRuleFamily)]
        public async Task<IActionResult> LastRuleCode(long id, CancellationToken cancellationToken)
        {
            var result = await _ruleFamilyService.GetLastCodeRuleFamily(id, cancellationToken);
            return Send(result);
        }
    }
}
