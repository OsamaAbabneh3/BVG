﻿using BVG.API.Authorization;
using BVG.Application.Services;
using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CycleInfoRuningStatus : BaseApiController
    {
        private readonly ICycleInfoRuningStatusService _cycleInfoRuningStatusService;

        public CycleInfoRuningStatus(ICycleInfoRuningStatusService cycleInfoRuningStatusService)
        {
            _cycleInfoRuningStatusService = cycleInfoRuningStatusService;
        }

        [HttpPost("by-snapshotbulk-id")]
        public async Task<IActionResult> GetCycleInfoRuningStatusBySnapShotBulkId([FromBody] CycleInfoRuningstatusBySnapShotBulkRequestDto dto)
        {
            var result = await _cycleInfoRuningStatusService.GetCycleInfoRuningStatusBySnapShotBulkIdPagenation(dto);
            return Send(result);
        }

      
        [HttpPost("by-cycleinfo-id")]
        public async Task<IActionResult> GetCycleInfoRuningStatusByCycleId([FromBody] CycleInfoRuningStatusByCycleInfoRequestDto dto)
        {
            var result = await _cycleInfoRuningStatusService.GetCycleInfoRuningStatusByCycleInfoIdPagenation(dto);
            return Send(result);
        }
    }
}
