﻿using BVG.Application.Common;
using BVG.Application.Services.Snapshot;
using BVG.Domain.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SDK;

namespace BVG.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class SnapshotController : BaseApiController
    {
        private readonly ISnapshotService _snapshotService;
        private readonly BVGBackgroundClient _bVGBackgroundClient;

        public SnapshotController(
            ISnapshotService snapshotService,
            BVGBackgroundClient bVGBackgroundClient) 
        {
            _snapshotService = snapshotService;
            _bVGBackgroundClient = bVGBackgroundClient;
        }

        [HttpPost("pull")]
        public async Task<IActionResult> PullSnapshot(CancellationToken cancellationToken)
        {
            var result = await _bVGBackgroundClient.PostAsync<BVGResponse<object>>("api/snapshot/pull", null!, cancellationToken);
            return Send(result);
        }

    }
}
