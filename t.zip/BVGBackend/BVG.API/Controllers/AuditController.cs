﻿using BVG.Application.Services.Email.EmailSender;
using BVG.Application.Services.Notification;
using BVG.Domain.Enums;
using Helper.CycleinfoRuningStatusLog;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.Controllers
{
    //[Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AuditController : BaseApiController
    {
        private readonly INotificationService _notificationService;
        private readonly IEmailSenderService _emailSenderService;
        public AuditController(INotificationService notificationService,IEmailSenderService emailSenderService)
        {
            _notificationService = notificationService;
            _emailSenderService = emailSenderService;
        
        }

        [HttpPost("start-audit")]
        public async Task<IActionResult> StartAuditBVG()
        {
           await _notificationService.SendToAllAsync(EventNotifications.AddCycleInfoRuningstatus.ToString());
            return Ok();
        }
       
    }
}
