﻿using BVG.API.Authorization;
using BVG.Application.Common;
using BVG.Domain.DTOs;
using BVG.Application.Services.RoleService;
using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("/api/roles")]
    public class RoleController : BaseApiController
    {
        private readonly IRoleService _roleService;

        public RoleController(IRoleService roleService)
        {
            _roleService = roleService;
        }

        
        [HttpPost]
        [Permission(PermissionsEnum.CreateRole)]
        public async Task<IActionResult> CreateRole([FromBody] CreateRoleDto dto, CancellationToken cancellationToken)
        {
            var result = await _roleService.CreateRole(dto, cancellationToken);
            return Send(result);
        }

        [Permission(PermissionsEnum.GetAllRoles)]
        [HttpPost("pagination")]
        public async Task<IActionResult> GetAllRoles([FromBody] DynamicPaginationDto dto, CancellationToken cancellationToken)
        {
            var result = await _roleService.GetAllRoles(dto, cancellationToken);
            return Send(result);
        }

        [HttpPatch("assign/permissions")]
        [Permission(PermissionsEnum.AssignPermissionsToRole)]
        public async Task<IActionResult> AssignPermissionsToRole([FromBody] AssignPermissionsToRoleDto dto, CancellationToken cancellationToken)
        {
            var result = await _roleService.AssignPermissionsToRole(dto, cancellationToken);
            return Send(result);
        }

        [HttpDelete("{id}")]
        [Permission(PermissionsEnum.DeleteRole)]
        public async Task<IActionResult> DeleteRole([FromRoute] Guid id, CancellationToken cancellationToken)
        {
            var result = await _roleService.DeleteRole(id, cancellationToken);
            return Send(result);
        }

        [HttpPatch("description")]
        [Permission(PermissionsEnum.UpdateRole)]
        public async Task<IActionResult> UpdateDescription([FromBody] ModifyDescriptionDto dto, CancellationToken cancellationToken)
        {
            var result = await _roleService.UpdateDescription(dto, cancellationToken);
            return Send(result);
        }
    }
}
