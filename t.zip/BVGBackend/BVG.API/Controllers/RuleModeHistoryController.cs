﻿using BVG.API.Authorization;
using BVG.Application.Services;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
namespace BVG.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("/api/rule-mode-history")]
        
    public class RuleModeHistoryController : BaseApiController
    {
        private readonly IRuleModeHistoryService _ruleModeHistoryService;
        public RuleModeHistoryController(IRuleModeHistoryService ruleModeHistoryService)
        {
            _ruleModeHistoryService = ruleModeHistoryService;
        }
        [HttpGet("id:long")]
        [Permission(PermissionsEnum.GetByIdRuleModeHistory)]
        public async Task<IActionResult> GetByIdRuleModeHistory(long id, CancellationToken cancellationToken)
        {
            var rule = await _ruleModeHistoryService.GetByIdRuleModeHistory(id, cancellationToken);
            //exeption
            return Send(rule);
        }
        [HttpPost]
        //[Permission(PermissionsEnum.AddRuleModeHistory)]
        //public async Task<IActionResult> AddRuleModeHistory([FromBody] AddRuleModeHistoryDto addRuleModeHistoryDto, CancellationToken cancellationToken)

        //{
        //    var result = await _ruleModeHistoryService.AddRuleModeHistory(addRuleModeHistoryDto, cancellationToken);
        //    return Send(result);
        //}
        [HttpPost("pagination")]
        [Permission(PermissionsEnum.GetAllRuleModeHistory)]
        public async Task<IActionResult> GetAllRuleModeHistory([FromBody] DynamicPaginationDto history, CancellationToken cancellationToken)
        {
            var result = await _ruleModeHistoryService.GetAllRuleModeHistory(history, cancellationToken);
            return Send(result);
        }

    }
}
