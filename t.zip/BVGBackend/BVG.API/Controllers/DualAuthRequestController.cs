﻿using BVG.API.Authorization;
using BVG.Application.Services;
using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("/api/dual-authorization-request")]

    public class DualAuthRequestController : BaseApiController
    {
        private readonly IDualAuthorizationRequestService _dualAuthorizationRequestService;
        public DualAuthRequestController(IDualAuthorizationRequestService dualAuthorizationRequestService)
        {
            _dualAuthorizationRequestService = dualAuthorizationRequestService;
        }
        [HttpGet("id:long")]
        [Permission(PermissionsEnum.GetByIdDualAuthorizationRequest)]
        public async Task<IActionResult> GetByIdDualAuthorizationRequest(long id, CancellationToken cancellationToken)
        {
            var rule = await _dualAuthorizationRequestService.GetByIdDualAuthorizationRequest(id, cancellationToken);
            //exeption
            return Send(rule);
        }
        [HttpPost]
        [Permission(PermissionsEnum.AddDualAuthorizationRequestAndApproval)]
        public async Task<IActionResult> AddDualAuthorizationRequest([FromBody] AddDualAuthorizationRequestDto addDualAuthorizationRequestDto, CancellationToken cancellationToken)
        {
            var result = await _dualAuthorizationRequestService.AddDualAuthorizationRequest(addDualAuthorizationRequestDto, cancellationToken);
            return Send(result);
        }
        [HttpPut]
        [Permission(PermissionsEnum.UpdateDualAuthorizationRequest)]
        public async Task<IActionResult> UpdateDualAuthorizationRequest([FromBody] UpdateDualAuthorizationRequestDto updateDualAuthorizationRequestDto, CancellationToken cancellationToken)
        {
            var result = await _dualAuthorizationRequestService.UpdateDualAuthorizationRequest(updateDualAuthorizationRequestDto, cancellationToken);
            return Send(result);
        }
        [HttpPost("pagination")]
        [Permission(PermissionsEnum.GetAllDualAuthorizationRequest)]
        public async Task<IActionResult> GetAllDualAuthorizationRequest([FromBody] DynamicPaginationDto dualAuthorizationRequest, CancellationToken cancellationToken)
        {
            var result = await _dualAuthorizationRequestService.GetAllDualAuthorizationRequest(dualAuthorizationRequest, cancellationToken);
            return Send(result);
        }

    }
}
