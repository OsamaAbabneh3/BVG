﻿using BVG.API.Authorization;
using BVG.Application.Services;
using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("/api/snapshot-bulk")]
    public class SnapshotBulkController : BaseApiController
    {
        private readonly ISnapshotBulkService _snapshotBulkService;
        public SnapshotBulkController(ISnapshotBulkService snapshotBulkService)
        {
            _snapshotBulkService = snapshotBulkService;
        }
        [HttpGet("id:long")]
        [Permission(PermissionsEnum.GetByIdSnapshotBulk)]
        public async Task<IActionResult> GetByIdSnapshotBulk(long id, CancellationToken cancellationToken)
        {
            var snap = await _snapshotBulkService.GetByIdSnapshotBulk(id, cancellationToken);
            //exeption
            return Send(snap);
        }
        //[HttpPost]
        //[Permission(PermissionsEnum.AddSnapshotBulk)]
        //public async Task<IActionResult> AddSnapshotBulk([FromBody] AddSnapshotBulkDto addSnapshotBulkDto, CancellationToken cancellationToken)
        //{
        //    var snap = await _snapshotBulkService.AddSnapshotBulk(addSnapshotBulkDto, cancellationToken);
        //    return Send(snap);
        //}
        [HttpPost("pagination")]
        [Permission(PermissionsEnum.GetAllSnapshotBulk)]
        public async Task<IActionResult> GetAllSnapshotBulk([FromBody] DynamicPaginationDto snapshotBulk, CancellationToken cancellationToken)
        {
            var snap = await _snapshotBulkService.GetAllSnapshotBulk(snapshotBulk, cancellationToken);
            return Send(snap);
        }
    }
}
