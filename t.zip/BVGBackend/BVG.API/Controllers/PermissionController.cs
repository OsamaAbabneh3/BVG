﻿using BVG.API.Authorization;
using BVG.Application.Services.Permission;
using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("/api/permissions")]
    public class PermissionController : BaseApiController
    {
        private IPermissionService _permissionService;

        public PermissionController(IPermissionService permissionService)
        {
            _permissionService = permissionService;
        }

        [HttpGet]
        [Permission(PermissionsEnum.GetAllPermissions)]
        public async Task<IActionResult> GetAllPermissions(CancellationToken cancellationToken)
        {
            var result = await _permissionService.GetAllPermissions(cancellationToken);
            return Send(result);
        }
    }
}
