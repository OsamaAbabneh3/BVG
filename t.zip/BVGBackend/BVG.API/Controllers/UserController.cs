﻿using BVG.API.Authorization;
using BVG.Domain.DTOs;
using BVG.Application.Services;
using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("/api/users")]
    public class UserController : BaseApiController
    {
        private readonly IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }


        [HttpPut("{id:guid}")]
        [Permission(PermissionsEnum.UpdateUser)]
        public async Task<IActionResult> UpdateUser(Guid id, [FromBody] UpdateUserDto dto, CancellationToken cancellationToken)
        {
            var result = await _userService.UpdateUserAsync(id, dto, cancellationToken);
            return Send(result);
        }
        
        [HttpGet("{id:guid}")]
        [Permission(PermissionsEnum.GetUser)]
        public async Task<IActionResult> GetById(Guid id, CancellationToken cancellationToken)
        {
            var GetByIdResponseDto = await _userService.GetById(id, cancellationToken);
            return Send(GetByIdResponseDto);
        }


        [HttpPost]
        [Permission(PermissionsEnum.CreateUser)]
        public async Task<IActionResult> CreateUser([FromBody] CreateUserDto dto, CancellationToken cancellationToken)
        {
            var result = await _userService.CreateUser(dto, cancellationToken);
            return Send(result);
        }

        [HttpPost("pagination")]
        [Permission(PermissionsEnum.GetAllUsers)]
        public async Task<IActionResult> GetAllUsers([FromBody] DynamicPaginationDto dto, CancellationToken cancellationToken)
        {
            var result = await _userService.GetAllUsers(dto, cancellationToken);
            return Send(result);
        }

        [HttpPatch("toggle-block/{id}")]
        [Permission(PermissionsEnum.ToggleBlock)]
        public async Task<IActionResult> ToggleBlock(Guid id, CancellationToken cancellationToken)
        {
            var result = await _userService.ToggleBlock(id, cancellationToken);
            return Send(result);
        }
        [HttpPatch("unlocked/{id}")]
        [Permission(PermissionsEnum.Unlocked)]
        public async Task<IActionResult> Unlocked(Guid id, CancellationToken cancellationToken)
        {
            var result = await _userService.Unlocked(id, cancellationToken);
            return Send(result);
        }

        [HttpPatch("assign/roles")]
        [Permission(PermissionsEnum.AssignRolesToUser)]
        public async Task<IActionResult> AssignRolesToUser(AssignRolesToUserDto dto, CancellationToken cancellationToken)
        {
            var result = await _userService.AssignRolesToUser(dto, cancellationToken);
            return Send(result);
        }
    }
}
