﻿using BVG.API.Authorization;
using BVG.Application.Services;
using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/audit-log")]
    public class AuditLogController : BaseApiController
    {
        private readonly IAuditLogService _auditLogService;

        public AuditLogController(IAuditLogService auditLogService)
        {
            _auditLogService = auditLogService;
        }

        /// <summary>
        /// Get Audit Log by Type and User Id
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("by-row-id")]
        [Permission(PermissionsEnum.GetAuditLog)]
        public async Task<IActionResult> GetAuditLog([FromBody] AuditLogsByRowIdRequestDto dto , CancellationToken cancellationToken)
        {
            var result = await _auditLogService.GetAuditLogsByRowIdPagination(dto, cancellationToken);
            return Send(result);
        }

        /// <summary>
        /// get the audit log by user id
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpPost("by-user")]
        [Permission(PermissionsEnum.GetAuditLog)]
        public async Task<IActionResult> GetAuditLogsByUserPagination([FromBody] AuditLogsByUserRequestDto dto, CancellationToken cancellationToken)
        {
            var result = await _auditLogService.GetAuditLogsByUserPagination(dto, cancellationToken);
            return Send(result);
        }
    }
}
