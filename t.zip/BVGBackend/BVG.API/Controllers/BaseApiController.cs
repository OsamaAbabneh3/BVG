﻿using BVG.Application.Common;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.Controllers
{
    [ApiController]
    public class BaseApiController:ControllerBase
    {
        protected IActionResult Send<T>(BVGResponse<T> response)
        {
            return StatusCode(response.StatusCode, response);
        }
    }
}
