﻿using BVG.API.Authorization;
using BVG.Application.Services;
using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("/api/invoice-exception")]
    public class InvoiceExceptionController : BaseApiController
    {
        private readonly IInvoiceExceptionService _iInvoiceExceptionService;
        public InvoiceExceptionController(IInvoiceExceptionService iInvoiceExceptionService)
        {
            _iInvoiceExceptionService = iInvoiceExceptionService;

        }

        [HttpGet("id:long")]
        [Permission(PermissionsEnum.GetByIdInvoiceException)]
        public async Task<IActionResult> GetByIdInvoiceException(long id, CancellationToken cancellationToken)
        {
            var rule = await _iInvoiceExceptionService.GetByIdInvoiceException(id, cancellationToken);
            //exeption
            return Send(rule);
        }
        [HttpPost]
        [Permission(PermissionsEnum.AddInvoiceException)]
        public async Task<IActionResult> AddInvoiceException([FromBody] AddInvoiceExceptionDto addInvoiceExceptionDto, CancellationToken cancellationToken)

        {
            var result = await _iInvoiceExceptionService.AddInvoiceException(addInvoiceExceptionDto, cancellationToken);
            return Send(result);
        }
        [HttpPut]
        [Permission(PermissionsEnum.UpdateInvoiceException)]
        public async Task<IActionResult> UpdateInvoiceException([FromBody] UpdateInvoiceExceptionDto updateInvoiceExceptionDto, CancellationToken cancellationToken)
        {
            var result = await _iInvoiceExceptionService.UpdateInvoiceException(updateInvoiceExceptionDto, cancellationToken);
            return Send(result);
        }
        [HttpPost("pagination")]
        [Permission(PermissionsEnum.GetAllInvoiceException)]
        public async Task<IActionResult> GetAllInvoiceException([FromBody] DynamicPaginationDto invoice, CancellationToken cancellationToken)
        {
            var result = await _iInvoiceExceptionService.GetAllInvoiceException(invoice, cancellationToken);
            return Send(result);
        }


    }
}
