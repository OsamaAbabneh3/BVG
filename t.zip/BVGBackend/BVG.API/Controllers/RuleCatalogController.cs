﻿using BVG.API.Authorization;
using BVG.Domain.DTOs;
using BVG.Application.Services;
using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("/api/ruleCatalogs")]
    public class RuleCatalogController : BaseApiController
    {
        private readonly IRuleCatalogService _ruleCatalogService;
        public RuleCatalogController(IRuleCatalogService ruleCatalogService)
        {
            _ruleCatalogService = ruleCatalogService;

        }

        [HttpGet("id:long")]
        [Permission(PermissionsEnum.GetRuleCatalog)]
        public async Task<IActionResult> GetByIdRuleCatalog(long id, CancellationToken cancellationToken)
        {
            var result = await _ruleCatalogService.GetByIdRuleCatalog(id, cancellationToken);
            //exeption
            return Send(result);
        }


        [HttpPost("pagination")]
        [Permission(PermissionsEnum.GetAllRuleCataloges)]
        public async Task<IActionResult> GetAllRuleCatalog([FromBody] DynamicPaginationDto getAllRuleCatalog, CancellationToken cancellationToken)
        {
            var result = await _ruleCatalogService.GetAllRuleCatalog(getAllRuleCatalog, cancellationToken);
            return Send(result);
        }

        [HttpPost]
        [Permission(PermissionsEnum.CreateRuleCatalog)]
        public async Task<IActionResult> CreateRuleCatalog([FromBody] CreateRuleCatalogDto createRuleCatalogDto, CancellationToken cancellationToken)
        {
          var result =  await  _ruleCatalogService.CreateRuleCatalog(createRuleCatalogDto, cancellationToken);
            return Send(result);
        }


        [HttpPut]
        [Permission(PermissionsEnum.UpdateRuleCatalog)]
        public async Task<IActionResult> UpdateRuleCatalog([FromBody] UpdateRuleCatalogDto updateRuleCatalogDto, CancellationToken cancellationToken)
        {
           var result = await _ruleCatalogService.UpdateRuleCatalog(updateRuleCatalogDto, cancellationToken);
            return Send(result);
        }


        //[HttpDelete]
        //[Permission(PermissionsEnum.DeleteRuleCatalog)]
        //public async Task<IActionResult> DeleteRuleCatalog(DeleteRuleCatalogDto deleteRuleCatalogDto, CancellationToken cancellationToken)
        //{
        //    var result = await _ruleCatalogService.DeleteRuleCatalog(deleteRuleCatalogDto, cancellationToken);
        //    return Send(result);
        //}
    }
}
