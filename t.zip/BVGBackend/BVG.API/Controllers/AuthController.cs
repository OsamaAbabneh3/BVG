﻿using BVG.Domain.DTOs;
using BVG.Application.Services.Jwt;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace BVG.API.Controllers
{
    [ApiController]
    [Route("/api/auth")]
    public class AuthController : BaseApiController
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto dto, CancellationToken cancellationToken)
        {
            var result = await _authService.Login(dto, cancellationToken);
            return Send(result);
        }
        [HttpPost("login/verify")]
        public async Task<IActionResult> VerifyLogin([FromBody] VerifyLoginOtpDto dto, CancellationToken cancellationToken)
        {
            var result=await _authService.VerfiyLoginOtp(dto, cancellationToken);
            return Send(result);
        }

        [Authorize]
        [HttpPatch("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordDto dto, CancellationToken cancellationToken)
        {
            var result = await _authService.ResetPassword(dto, cancellationToken);
            return Send(result);
        }

        [HttpPatch("send-otp")]
        public async Task<IActionResult> SendOtp([FromBody] SendOtpDto dto, CancellationToken cancellationToken)
        {
            var result = await _authService.SendOtp(dto, cancellationToken);
            return Send(result);
        }

        [HttpPatch("forget-password")]
        public async Task<IActionResult> ForgetPasswor([FromBody] ForgetPasswordDto dto, CancellationToken cancellationToken)
        {
            var result = await _authService.ForgetPassword(dto, cancellationToken);
            return Send(result);
        }
    }
}
