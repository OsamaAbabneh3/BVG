﻿using BVG.API.Authorization;
using BVG.Application.Services;
using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("/api/dual-auth-approval")]
    public class DualAuthorizationApprovalController : BaseApiController
    {
        private readonly IDualAuthorizationApprovalService _dualAuthorizationApprovalService;
        public DualAuthorizationApprovalController(IDualAuthorizationApprovalService dualAuthorizationApprovalService)
        {
            _dualAuthorizationApprovalService = dualAuthorizationApprovalService;
        }
        [HttpGet("id:long")]
        [Permission(PermissionsEnum.GetByIdDualAuthorizationApproval)]
        public async Task<IActionResult> GetByIdDualAuthorizationApproval(long id, CancellationToken cancellationToken)
        {
            var rule = await _dualAuthorizationApprovalService.GetByIdDualAuthorizationApproval(id, cancellationToken);
            //exeption
            return Send(rule);
        }
        [HttpPost("pagination")]
        [Permission(PermissionsEnum.GetAllDualAuthorizationApproval)]
        public async Task<IActionResult> GetAllDualAuthorizationApproval([FromBody] DynamicPaginationDto dualApproval, CancellationToken cancellationToken)
        {
            var result = await _dualAuthorizationApprovalService.GetAllDualAuthorizationApproval(dualApproval, cancellationToken);
            return Send(result);
        }

        [HttpPost("pagination/by-user")]
        [Permission(PermissionsEnum.GetAllDualAuthorizationApprovalByUserId)]
        public async Task<IActionResult> GetAllDualAuthorizationApprovalByUserId([FromBody] DynamicPaginationDto dualApproval, CancellationToken cancellationToken)
        {
            var result = await _dualAuthorizationApprovalService.GetAllDualAuthorizationApprovalByUserId(dualApproval, cancellationToken);
            return Send(result);
        }

        [HttpPost]
        [Permission(PermissionsEnum.DecisionDualAuthorizationApproval)]
        public async Task<IActionResult> DecisionDualAuthorizationApproval([FromBody] DecisionDualAuthorizationApprovalDto dto, CancellationToken cancellationToken)
        {
            var response = await _dualAuthorizationApprovalService.DecisionDualAuthorizationApproval(dto, cancellationToken);
            return Send(response);
        }

    }
}
