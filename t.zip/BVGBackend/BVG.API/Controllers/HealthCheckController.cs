﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SDK;

namespace BVG.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class HealthCheckController : BaseApiController
    {
        private readonly BVGBackgroundClient _httpBvgBackGroundClient;
        public HealthCheckController(BVGBackgroundClient httpBVGBackgroundClient)
        {
            _httpBvgBackGroundClient = httpBVGBackgroundClient;
        }

        [HttpPost]
        public async Task<IActionResult> CheckHealthBVG(CancellationToken cancellationToken)
        {
            var result = await _httpBvgBackGroundClient.PostAsync<object>("api/healthCheck", null!, cancellationToken);
            return Send(result);
        }
    }
}
