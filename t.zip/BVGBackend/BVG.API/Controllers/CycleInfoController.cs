﻿using BVG.API.Authorization;
using BVG.Application.Services;
using BVG.Domain.DTOs;
using BVG.Domain.Entities;
using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BVG.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("/api/cycle-info")]
    public class CycleInfoController : BaseApiController
    {
        private readonly ICycleInfoService _iCycleInfoService;
        public CycleInfoController(ICycleInfoService iCycleInfoService)
        {
            _iCycleInfoService = iCycleInfoService;
        }
        [HttpGet("id:long")]
        [Permission(PermissionsEnum.GetByIdCycleInfo)]
        public async Task<IActionResult> GetByIdCycleInfo(long id, CancellationToken cancellationToken)
        {
            var rule = await _iCycleInfoService.GetByIdCycleInfo(id, cancellationToken);
            //exeption
            return Send(rule);
        }
        //[HttpPost]
        //[Permission(PermissionsEnum.AddCycleInfo)]
        //public async Task<IActionResult> AddCycleInfo([FromBody] AddCycleInfoDto addCycleInfoDto, CancellationToken cancellationToken)
        //{
        //    var result = await _iCycleInfoService.AddCycleInfo(addCycleInfoDto, cancellationToken);
        //    return Send(result);
        //}
        [HttpPost("pagination")]
        [Permission(PermissionsEnum.GetAllCycleInfo)]
        public async Task<IActionResult> GetAllCycleInfo([FromBody] DynamicPaginationDto cycle, CancellationToken cancellationToken)
        {
            var result = await _iCycleInfoService.GetAllCycleInfo(cycle, cancellationToken);
            return Send(result);
        }
        
        //[HttpPut]
        //[Permission(PermissionsEnum.UpdateCycleInfo)]
        //public async Task<IActionResult> UpdateCycleInfo([FromBody] UpdateCycleInfoDto updateCycleInfoDto, CancellationToken cancellationToken)
        //{
        //    var result = await _iCycleInfoService.UpdateCycleInfo(updateCycleInfoDto, cancellationToken);
        //    return Send(result);
        //}
    }
}
