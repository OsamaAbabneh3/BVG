﻿using BVG.Application.Common;
using BVG.Application.Services.BackgroundJobs;
using BVG.Application.Services.BVGExecute;
using Microsoft.AspNetCore.Mvc;
using SDK;

namespace BVG.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BackgroundJobsController : BaseApiController
    {
        private BVGBackgroundClient _bVGBackgroundClient;

        public BackgroundJobsController(BVGBackgroundClient bVGBackgroundClient)
        {
            _bVGBackgroundClient = bVGBackgroundClient;
        }

        [HttpPost("start-bvg")]
        public async Task<IActionResult> Enqueue(CancellationToken cancellationToken)
        {
            var result = await _bVGBackgroundClient.PostAsync<BVGResponse<object>>("api/BackgroundJobs/start-bvg", null!, cancellationToken);
            return Send(result);
        }
    }
}
