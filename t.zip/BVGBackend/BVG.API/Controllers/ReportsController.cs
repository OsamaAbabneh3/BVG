﻿using BVG.API.Authorization;
using BVG.Application.Services;
using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using BVG.Domain.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading;
using System.Threading.Tasks;
namespace BVG.API.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/reports")]
    public class ReportsController : BaseApiController
    {
        private readonly IReportsService _reportsService;
        public ReportsController(IReportsService reportsService)
        {
            _reportsService = reportsService;
        }
        [HttpPost("cycle-summary")]
        [Permission(PermissionsEnum.ExportCycleSummaryReport)]
        public async Task<IActionResult> DownloadCycleSummary([FromBody] CycleSummaryReportRequestDto dto,CancellationToken cancellationToken)
        {
            var result = await _reportsService.GetCycleSummaryAsync(dto,cancellationToken);

            if (result.Data == null)
            {
                return StatusCode((int)result.StatusCode,result);
            }

            var file = result.Data;

            return File(file.Content,file.ContentType,file.FileName);
        }
    }
}
