﻿using BVG.API.Authorization;
using BVG.Application.Services;
using BVG.Domain.DTOs;
using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;

namespace BVG.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("/api/fingerprint")]
    public class FingerprintController : BaseApiController
    {
        private readonly IFingerprintService _fingerprintService;
        public FingerprintController(IFingerprintService fingerprintService)
        {
            _fingerprintService = fingerprintService;
        }
        [HttpGet("id:long")]
        [Permission(PermissionsEnum.GetByIdFingerprint)]
        public async Task<IActionResult> GetByIdFingerprint(long id, CancellationToken cancellationToken)
        {
            var finger = await _fingerprintService.GetByIdFingerprint(id, cancellationToken);
            //exeption
            return Send(finger);
        }
        [HttpPost]
        [Permission(PermissionsEnum.AddFingerprint)]
        public async Task<IActionResult> AddFingerprint([FromBody] AddFingerprintDto addFingerprintDto, CancellationToken cancellationToken)
        {
            var finger = await _fingerprintService.AddFingerprint(addFingerprintDto, cancellationToken);
            return Send(finger);
        }
        [HttpPut]
        [Permission(PermissionsEnum.UpdateFingerprint)]
        public async Task<IActionResult> UpdateFingerprint([FromBody] UpdateFingerprintDto updateFingerprintDto, CancellationToken cancellationToken)
        {
            var finger = await _fingerprintService.UpdateFingerprint(updateFingerprintDto, cancellationToken);
            return Send(finger);
        }
        [HttpPost("pagination")]
        [Permission(PermissionsEnum.GetAllFingerprint)]
        public async Task<IActionResult> GetAllFingerprint([FromBody] DynamicPaginationDto fingerprint, CancellationToken cancellationToken)
        {
            var finger = await _fingerprintService.GetAllFingerprint(fingerprint, cancellationToken);
            return Send(finger);
        }
    }
}
