﻿using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;

namespace BVG.API.Authorization
{
    public class PermissionRequirement : IAuthorizationRequirement
    {

        public string Permission { get; }

        public PermissionRequirement(string permission)
        {
            Permission = permission;
        }
    }
}
