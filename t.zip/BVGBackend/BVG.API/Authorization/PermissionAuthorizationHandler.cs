﻿using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;

namespace BVG.API.Authorization
{
    public class PermissionAuthorizationHandler : AuthorizationHandler<PermissionRequirement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, PermissionRequirement requirement)
        {
            var permissionsClaim = context.User.FindFirst("permissions")?.Value;

            if (string.IsNullOrWhiteSpace(permissionsClaim))
            {
                return Task.CompletedTask;
            }

            var permissions = permissionsClaim.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            var requirementPermission = (int)Enum.Parse<PermissionsEnum>(requirement.Permission);

            var hasPermission = permissions.Contains(requirementPermission.ToString(), StringComparer.OrdinalIgnoreCase);

            if (hasPermission) 
            {
                context.Succeed(requirement); 
            }

            return Task.CompletedTask;
        }
    }
}
