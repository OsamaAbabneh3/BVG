﻿using BVG.Domain.Enums;
using Microsoft.AspNetCore.Authorization;

namespace BVG.API.Authorization
{
    public class PermissionAttribute : AuthorizeAttribute
    {
        public PermissionAttribute(PermissionsEnum permission)
        {
            Policy = $"Permission:{permission}";
        }
    }
}
