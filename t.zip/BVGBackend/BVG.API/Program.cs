
using BVG.API.Extensions;
using BVG.Domain.Interfaces;
using BVG.Infrastructure.RealTime;
using BVG.Infrastructure.Repositories;
using BVG.Infrastructure.Seeders;
using CommonResources.Middlewares;
using SDK;
using System.Transactions;
//using SDK.DependencyInjection;


var builder = WebApplication.CreateBuilder(args);
string configFolderPath = builder.Configuration["FolderConfigPath"] ?? AppContext.BaseDirectory;
string jsonFilePath = Path.Combine(configFolderPath);
builder.Configuration.AddJsonFile(path: jsonFilePath, optional: true, reloadOnChange: true);

builder.Services.AddDependencyInjection(builder.Configuration);
builder.Services.AddSignalR();
var corsOrigins = builder.Configuration.GetSection("CorsOrigins").Get<string[]>()
                  ?? new[] { "http://localhost:4200" };
builder.Services.AddHttpClient<BVGBackgroundClient>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["BVGBackground:BaseUrl"]!);
    client.DefaultRequestHeaders.Add("X-Api-Key", builder.Configuration["BVGBackground:ApiKey"]);
});
builder.Services.AddCors(options =>
{
    options.AddPolicy("AngularPolicy", policy =>
    {
        policy.WithOrigins(corsOrigins)
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials();
    });
});

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
        var seeder = services.GetRequiredService<DatabaseSeeder>();
        await seeder.SeedAsync();
    }
    catch (Exception ex)
    {
        var logger = services.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex.Message);
    }
}

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

var supportedCultures = new[] { "ar", "en" };
var localizationOptions = new RequestLocalizationOptions()
    .SetDefaultCulture("ar")
    .AddSupportedCultures(supportedCultures)
    .AddSupportedUICultures(supportedCultures);



app.UseRequestLocalization(localizationOptions);

app.UseMiddleware<ReadHeaderMiddleware>();

app.UseExceptionHandler();

app.UseWhen(
    ctx => !ctx.Request.Path.StartsWithSegments("/hubs/internal"),
    branch => branch.UseHttpsRedirection());

app.MapControllers();

app.UseRouting();
app.UseCors("AngularPolicy");


app.UseAuthentication();

app.UseAuthorization();
app.MapHub<NotificationHub>("/hubs/notifications");
app.MapHub<InternalHub>("/hubs/internal");
app.Run();
